/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAccessibleEventReceiver.idl
 */

#ifndef __gen_nsIAccessibleEventReceiver_h__
#define __gen_nsIAccessibleEventReceiver_h__


#ifndef __gen_nsIAccessibleEventListener_h__
#include "nsIAccessibleEventListener.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIAccessibleEventReceiver */
#define NS_IACCESSIBLEEVENTRECEIVER_IID_STR "ab331e47-4faa-4a12-9480-9b480dd78b39"

#define NS_IACCESSIBLEEVENTRECEIVER_IID \
  {0xab331e47, 0x4faa, 0x4a12, \
    { 0x94, 0x80, 0x9b, 0x48, 0x0d, 0xd7, 0x8b, 0x39 }}

class NS_NO_VTABLE nsIAccessibleEventReceiver : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IACCESSIBLEEVENTRECEIVER_IID)

  /* void addAccessibleEventListener (in nsIAccessibleEventListener aListener); */
  NS_IMETHOD AddAccessibleEventListener(nsIAccessibleEventListener *aListener) = 0;

  /* void removeAccessibleEventListener (in nsIAccessibleEventListener aListener); */
  NS_IMETHOD RemoveAccessibleEventListener(nsIAccessibleEventListener *aListener) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIACCESSIBLEEVENTRECEIVER \
  NS_IMETHOD AddAccessibleEventListener(nsIAccessibleEventListener *aListener); \
  NS_IMETHOD RemoveAccessibleEventListener(nsIAccessibleEventListener *aListener); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIACCESSIBLEEVENTRECEIVER(_to) \
  NS_IMETHOD AddAccessibleEventListener(nsIAccessibleEventListener *aListener) { return _to AddAccessibleEventListener(aListener); } \
  NS_IMETHOD RemoveAccessibleEventListener(nsIAccessibleEventListener *aListener) { return _to RemoveAccessibleEventListener(aListener); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIACCESSIBLEEVENTRECEIVER(_to) \
  NS_IMETHOD AddAccessibleEventListener(nsIAccessibleEventListener *aListener) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddAccessibleEventListener(aListener); } \
  NS_IMETHOD RemoveAccessibleEventListener(nsIAccessibleEventListener *aListener) { return !_to ? NS_ERROR_NULL_POINTER : _to->RemoveAccessibleEventListener(aListener); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAccessibleEventReceiver : public nsIAccessibleEventReceiver
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIACCESSIBLEEVENTRECEIVER

  nsAccessibleEventReceiver();
  virtual ~nsAccessibleEventReceiver();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAccessibleEventReceiver, nsIAccessibleEventReceiver)

nsAccessibleEventReceiver::nsAccessibleEventReceiver()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAccessibleEventReceiver::~nsAccessibleEventReceiver()
{
  /* destructor code */
}

/* void addAccessibleEventListener (in nsIAccessibleEventListener aListener); */
NS_IMETHODIMP nsAccessibleEventReceiver::AddAccessibleEventListener(nsIAccessibleEventListener *aListener)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void removeAccessibleEventListener (in nsIAccessibleEventListener aListener); */
NS_IMETHODIMP nsAccessibleEventReceiver::RemoveAccessibleEventListener(nsIAccessibleEventListener *aListener)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAccessibleEventReceiver_h__ */
