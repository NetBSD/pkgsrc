/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbSyncListener.idl
 */

#ifndef __gen_nsIAbSyncListener_h__
#define __gen_nsIAbSyncListener_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsrootidl_h__
#include "nsrootidl.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIAbSyncListener */
#define NS_IABSYNCLISTENER_IID_STR "e0ed29e0-098a-11d4-8fd6-00a024a7d144"

#define NS_IABSYNCLISTENER_IID \
  {0xe0ed29e0, 0x098a, 0x11d4, \
    { 0x8f, 0xd6, 0x00, 0xa0, 0x24, 0xa7, 0xd1, 0x44 }}

class NS_NO_VTABLE nsIAbSyncListener : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABSYNCLISTENER_IID)

  /**
     * Notify the observer that the AB Sync Authorization operation has begun. 
     *
     */
  /* void OnStartAuthOperation (); */
  NS_IMETHOD OnStartAuthOperation(void) = 0;

  /**
     * Notify the observer that the AB Sync operation has been completed.  
     * 
     * This method is called regardless of whether the the operation was 
     * successful.
     * 
     *  aTransactionID    - the ID for this particular request
     *  aStatus           - Status code for the sync request
     *  aMsg              - A text string describing the error (if any).
     *  aCookie           - hmmm...cooookies!
     */
  /* void OnStopAuthOperation (in nsresult aStatus, in wstring aMsg, in string aCookie); */
  NS_IMETHOD OnStopAuthOperation(nsresult aStatus, const PRUnichar *aMsg, const char *aCookie) = 0;

  /**
     * Notify the observer that the AB Sync operation has begun. This method is
     * called only once, at the beginning of a sync transaction
     *
     */
  /* void OnStartOperation (in PRInt32 aTransactionID, in PRUint32 aMsgSize); */
  NS_IMETHOD OnStartOperation(PRInt32 aTransactionID, PRUint32 aMsgSize) = 0;

  /**
     * Notify the observer that progress as occurred for the AB Sync operation
     */
  /* void OnProgress (in PRInt32 aTransactionID, in PRUint32 aProgress, in PRUint32 aProgressMax); */
  NS_IMETHOD OnProgress(PRInt32 aTransactionID, PRUint32 aProgress, PRUint32 aProgressMax) = 0;

  /**
     * Notify the observer with a status message for sync operation
     */
  /* void OnStatus (in PRInt32 aTransactionID, in wstring aMsg); */
  NS_IMETHOD OnStatus(PRInt32 aTransactionID, const PRUnichar *aMsg) = 0;

  /**
     * Notify the observer that the AB Sync operation has been completed.  
     * 
     * This method is called regardless of whether the the operation was 
     * successful.
     * 
     *  aTransactionID    - the ID for this particular request
     *  aStatus           - Status code for the sync request
     *  aMsg              - A text string describing the error (if any).
     */
  /* void OnStopOperation (in PRInt32 aTransactionID, in nsresult aStatus, in wstring aMsg); */
  NS_IMETHOD OnStopOperation(PRInt32 aTransactionID, nsresult aStatus, const PRUnichar *aMsg) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABSYNCLISTENER \
  NS_IMETHOD OnStartAuthOperation(void); \
  NS_IMETHOD OnStopAuthOperation(nsresult aStatus, const PRUnichar *aMsg, const char *aCookie); \
  NS_IMETHOD OnStartOperation(PRInt32 aTransactionID, PRUint32 aMsgSize); \
  NS_IMETHOD OnProgress(PRInt32 aTransactionID, PRUint32 aProgress, PRUint32 aProgressMax); \
  NS_IMETHOD OnStatus(PRInt32 aTransactionID, const PRUnichar *aMsg); \
  NS_IMETHOD OnStopOperation(PRInt32 aTransactionID, nsresult aStatus, const PRUnichar *aMsg); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABSYNCLISTENER(_to) \
  NS_IMETHOD OnStartAuthOperation(void) { return _to OnStartAuthOperation(); } \
  NS_IMETHOD OnStopAuthOperation(nsresult aStatus, const PRUnichar *aMsg, const char *aCookie) { return _to OnStopAuthOperation(aStatus, aMsg, aCookie); } \
  NS_IMETHOD OnStartOperation(PRInt32 aTransactionID, PRUint32 aMsgSize) { return _to OnStartOperation(aTransactionID, aMsgSize); } \
  NS_IMETHOD OnProgress(PRInt32 aTransactionID, PRUint32 aProgress, PRUint32 aProgressMax) { return _to OnProgress(aTransactionID, aProgress, aProgressMax); } \
  NS_IMETHOD OnStatus(PRInt32 aTransactionID, const PRUnichar *aMsg) { return _to OnStatus(aTransactionID, aMsg); } \
  NS_IMETHOD OnStopOperation(PRInt32 aTransactionID, nsresult aStatus, const PRUnichar *aMsg) { return _to OnStopOperation(aTransactionID, aStatus, aMsg); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABSYNCLISTENER(_to) \
  NS_IMETHOD OnStartAuthOperation(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnStartAuthOperation(); } \
  NS_IMETHOD OnStopAuthOperation(nsresult aStatus, const PRUnichar *aMsg, const char *aCookie) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnStopAuthOperation(aStatus, aMsg, aCookie); } \
  NS_IMETHOD OnStartOperation(PRInt32 aTransactionID, PRUint32 aMsgSize) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnStartOperation(aTransactionID, aMsgSize); } \
  NS_IMETHOD OnProgress(PRInt32 aTransactionID, PRUint32 aProgress, PRUint32 aProgressMax) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnProgress(aTransactionID, aProgress, aProgressMax); } \
  NS_IMETHOD OnStatus(PRInt32 aTransactionID, const PRUnichar *aMsg) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnStatus(aTransactionID, aMsg); } \
  NS_IMETHOD OnStopOperation(PRInt32 aTransactionID, nsresult aStatus, const PRUnichar *aMsg) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnStopOperation(aTransactionID, aStatus, aMsg); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbSyncListener : public nsIAbSyncListener
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABSYNCLISTENER

  nsAbSyncListener();
  virtual ~nsAbSyncListener();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbSyncListener, nsIAbSyncListener)

nsAbSyncListener::nsAbSyncListener()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAbSyncListener::~nsAbSyncListener()
{
  /* destructor code */
}

/* void OnStartAuthOperation (); */
NS_IMETHODIMP nsAbSyncListener::OnStartAuthOperation()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void OnStopAuthOperation (in nsresult aStatus, in wstring aMsg, in string aCookie); */
NS_IMETHODIMP nsAbSyncListener::OnStopAuthOperation(nsresult aStatus, const PRUnichar *aMsg, const char *aCookie)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void OnStartOperation (in PRInt32 aTransactionID, in PRUint32 aMsgSize); */
NS_IMETHODIMP nsAbSyncListener::OnStartOperation(PRInt32 aTransactionID, PRUint32 aMsgSize)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void OnProgress (in PRInt32 aTransactionID, in PRUint32 aProgress, in PRUint32 aProgressMax); */
NS_IMETHODIMP nsAbSyncListener::OnProgress(PRInt32 aTransactionID, PRUint32 aProgress, PRUint32 aProgressMax)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void OnStatus (in PRInt32 aTransactionID, in wstring aMsg); */
NS_IMETHODIMP nsAbSyncListener::OnStatus(PRInt32 aTransactionID, const PRUnichar *aMsg)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void OnStopOperation (in PRInt32 aTransactionID, in nsresult aStatus, in wstring aMsg); */
NS_IMETHODIMP nsAbSyncListener::OnStopOperation(PRInt32 aTransactionID, nsresult aStatus, const PRUnichar *aMsg)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbSyncListener_h__ */
