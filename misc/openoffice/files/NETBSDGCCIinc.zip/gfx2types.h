/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM gfx2types.idl
 */

#ifndef __gen_gfx2types_h__
#define __gen_gfx2types_h__


#ifndef __gen_nsrootidl_h__
#include "nsrootidl.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
#include "gfxcompat.h"
/**
 * gfx_dimension should be used for widths and heights
 * @var typedef float gfx_dimension
 */
typedef float gfx_dimension;

/**
 * gfx_coord should be used for x and y coordinates
 * @var typedef float gfx_coord
 */
typedef float gfx_coord;

/**
 * typedef that should be used for angles
 * @var typedef float gfx_angle
 */
typedef float gfx_angle;

/**
 * A color is a 32 bit unsigned integer with
 * four components: R, G, B and A.
 *
 * @var typedef PRUint32 gfx_color
 */
typedef PRUint32 gfx_color;

/**
 * typedef that should be used for bit depths
 * @var typedef unsigned short gfx_depth
 */
typedef PRUint16 gfx_depth;

/**
 * typedef that should be used for image formats
 * @var typedef long gfx_format
 * @see gfxIGFXFormat
 */
typedef PRInt32 gfx_format;

/**
 * typedef that should be used for gamma levels
 * @var typedef float gfx_gamma
 */
typedef float gfx_gamma;


#endif /* __gen_gfx2types_h__ */
