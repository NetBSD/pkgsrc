/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIBookmarksService.idl
 */

#ifndef __gen_nsIBookmarksService_h__
#define __gen_nsIBookmarksService_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIRDFResource; /* forward declaration */


/* starting interface:    nsIBookmarksService */
#define NS_IBOOKMARKSSERVICE_IID_STR "a82e9300-e4af-11d2-8fdf-0008c70adc7b"

#define NS_IBOOKMARKSSERVICE_IID \
  {0xa82e9300, 0xe4af, 0x11d2, \
    { 0x8f, 0xdf, 0x00, 0x08, 0xc7, 0x0a, 0xdc, 0x7b }}

class NS_NO_VTABLE nsIBookmarksService : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IBOOKMARKSSERVICE_IID)

  enum { BOOKMARK_DEFAULT_TYPE = 0U };

  enum { BOOKMARK_SEARCH_TYPE = 1U };

  enum { BOOKMARK_FIND_TYPE = 2U };

  /* void ReadBookmarks (); */
  NS_IMETHOD ReadBookmarks(void) = 0;

  /* boolean IsBookmarked (in string aURI); */
  NS_IMETHOD IsBookmarked(const char *aURI, PRBool *_retval) = 0;

  /* void AddBookmark (in string aURI, in wstring aTitle, in long bmType, in wstring docCharset); */
  NS_IMETHOD AddBookmark(const char *aURI, const PRUnichar *aTitle, PRInt32 bmType, const PRUnichar *docCharset) = 0;

  /* void AddBookmarkToFolder (in string aURI, in nsIRDFResource aFolder, in wstring aTitle, in wstring docCharSet); */
  NS_IMETHOD AddBookmarkToFolder(const char *aURI, nsIRDFResource *aFolder, const PRUnichar *aTitle, const PRUnichar *docCharSet) = 0;

  /* void insertBookmarkInFolder (in string aURI, in wstring aTitle, in wstring docCharSet, in nsIRDFResource aFolder, in long aIndex); */
  NS_IMETHOD InsertBookmarkInFolder(const char *aURI, const PRUnichar *aTitle, const PRUnichar *docCharSet, nsIRDFResource *aFolder, PRInt32 aIndex) = 0;

  /* void UpdateBookmarkLastVisitedDate (in string aURL, in wstring docCharset); */
  NS_IMETHOD UpdateBookmarkLastVisitedDate(const char *aURL, const PRUnichar *docCharset) = 0;

  /* string FindShortcut (in wstring aName); */
  NS_IMETHOD FindShortcut(const PRUnichar *aName, char **_retval) = 0;

  /* wstring GetLastCharset (in string aURI); */
  NS_IMETHOD GetLastCharset(const char *aURI, PRUnichar **_retval) = 0;

  /* nsIRDFResource GetAnonymousResource (); */
  NS_IMETHOD GetAnonymousResource(nsIRDFResource **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIBOOKMARKSSERVICE \
  NS_IMETHOD ReadBookmarks(void); \
  NS_IMETHOD IsBookmarked(const char *aURI, PRBool *_retval); \
  NS_IMETHOD AddBookmark(const char *aURI, const PRUnichar *aTitle, PRInt32 bmType, const PRUnichar *docCharset); \
  NS_IMETHOD AddBookmarkToFolder(const char *aURI, nsIRDFResource *aFolder, const PRUnichar *aTitle, const PRUnichar *docCharSet); \
  NS_IMETHOD InsertBookmarkInFolder(const char *aURI, const PRUnichar *aTitle, const PRUnichar *docCharSet, nsIRDFResource *aFolder, PRInt32 aIndex); \
  NS_IMETHOD UpdateBookmarkLastVisitedDate(const char *aURL, const PRUnichar *docCharset); \
  NS_IMETHOD FindShortcut(const PRUnichar *aName, char **_retval); \
  NS_IMETHOD GetLastCharset(const char *aURI, PRUnichar **_retval); \
  NS_IMETHOD GetAnonymousResource(nsIRDFResource **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIBOOKMARKSSERVICE(_to) \
  NS_IMETHOD ReadBookmarks(void) { return _to ReadBookmarks(); } \
  NS_IMETHOD IsBookmarked(const char *aURI, PRBool *_retval) { return _to IsBookmarked(aURI, _retval); } \
  NS_IMETHOD AddBookmark(const char *aURI, const PRUnichar *aTitle, PRInt32 bmType, const PRUnichar *docCharset) { return _to AddBookmark(aURI, aTitle, bmType, docCharset); } \
  NS_IMETHOD AddBookmarkToFolder(const char *aURI, nsIRDFResource *aFolder, const PRUnichar *aTitle, const PRUnichar *docCharSet) { return _to AddBookmarkToFolder(aURI, aFolder, aTitle, docCharSet); } \
  NS_IMETHOD InsertBookmarkInFolder(const char *aURI, const PRUnichar *aTitle, const PRUnichar *docCharSet, nsIRDFResource *aFolder, PRInt32 aIndex) { return _to InsertBookmarkInFolder(aURI, aTitle, docCharSet, aFolder, aIndex); } \
  NS_IMETHOD UpdateBookmarkLastVisitedDate(const char *aURL, const PRUnichar *docCharset) { return _to UpdateBookmarkLastVisitedDate(aURL, docCharset); } \
  NS_IMETHOD FindShortcut(const PRUnichar *aName, char **_retval) { return _to FindShortcut(aName, _retval); } \
  NS_IMETHOD GetLastCharset(const char *aURI, PRUnichar **_retval) { return _to GetLastCharset(aURI, _retval); } \
  NS_IMETHOD GetAnonymousResource(nsIRDFResource **_retval) { return _to GetAnonymousResource(_retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIBOOKMARKSSERVICE(_to) \
  NS_IMETHOD ReadBookmarks(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->ReadBookmarks(); } \
  NS_IMETHOD IsBookmarked(const char *aURI, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->IsBookmarked(aURI, _retval); } \
  NS_IMETHOD AddBookmark(const char *aURI, const PRUnichar *aTitle, PRInt32 bmType, const PRUnichar *docCharset) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddBookmark(aURI, aTitle, bmType, docCharset); } \
  NS_IMETHOD AddBookmarkToFolder(const char *aURI, nsIRDFResource *aFolder, const PRUnichar *aTitle, const PRUnichar *docCharSet) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddBookmarkToFolder(aURI, aFolder, aTitle, docCharSet); } \
  NS_IMETHOD InsertBookmarkInFolder(const char *aURI, const PRUnichar *aTitle, const PRUnichar *docCharSet, nsIRDFResource *aFolder, PRInt32 aIndex) { return !_to ? NS_ERROR_NULL_POINTER : _to->InsertBookmarkInFolder(aURI, aTitle, docCharSet, aFolder, aIndex); } \
  NS_IMETHOD UpdateBookmarkLastVisitedDate(const char *aURL, const PRUnichar *docCharset) { return !_to ? NS_ERROR_NULL_POINTER : _to->UpdateBookmarkLastVisitedDate(aURL, docCharset); } \
  NS_IMETHOD FindShortcut(const PRUnichar *aName, char **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->FindShortcut(aName, _retval); } \
  NS_IMETHOD GetLastCharset(const char *aURI, PRUnichar **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetLastCharset(aURI, _retval); } \
  NS_IMETHOD GetAnonymousResource(nsIRDFResource **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAnonymousResource(_retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsBookmarksService : public nsIBookmarksService
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIBOOKMARKSSERVICE

  nsBookmarksService();
  virtual ~nsBookmarksService();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsBookmarksService, nsIBookmarksService)

nsBookmarksService::nsBookmarksService()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsBookmarksService::~nsBookmarksService()
{
  /* destructor code */
}

/* void ReadBookmarks (); */
NS_IMETHODIMP nsBookmarksService::ReadBookmarks()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean IsBookmarked (in string aURI); */
NS_IMETHODIMP nsBookmarksService::IsBookmarked(const char *aURI, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void AddBookmark (in string aURI, in wstring aTitle, in long bmType, in wstring docCharset); */
NS_IMETHODIMP nsBookmarksService::AddBookmark(const char *aURI, const PRUnichar *aTitle, PRInt32 bmType, const PRUnichar *docCharset)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void AddBookmarkToFolder (in string aURI, in nsIRDFResource aFolder, in wstring aTitle, in wstring docCharSet); */
NS_IMETHODIMP nsBookmarksService::AddBookmarkToFolder(const char *aURI, nsIRDFResource *aFolder, const PRUnichar *aTitle, const PRUnichar *docCharSet)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void insertBookmarkInFolder (in string aURI, in wstring aTitle, in wstring docCharSet, in nsIRDFResource aFolder, in long aIndex); */
NS_IMETHODIMP nsBookmarksService::InsertBookmarkInFolder(const char *aURI, const PRUnichar *aTitle, const PRUnichar *docCharSet, nsIRDFResource *aFolder, PRInt32 aIndex)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void UpdateBookmarkLastVisitedDate (in string aURL, in wstring docCharset); */
NS_IMETHODIMP nsBookmarksService::UpdateBookmarkLastVisitedDate(const char *aURL, const PRUnichar *docCharset)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* string FindShortcut (in wstring aName); */
NS_IMETHODIMP nsBookmarksService::FindShortcut(const PRUnichar *aName, char **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* wstring GetLastCharset (in string aURI); */
NS_IMETHODIMP nsBookmarksService::GetLastCharset(const char *aURI, PRUnichar **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIRDFResource GetAnonymousResource (); */
NS_IMETHODIMP nsBookmarksService::GetAnonymousResource(nsIRDFResource **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif

// {E638D760-8687-11d2-B530-000000000000}
#define NS_BOOKMARKS_SERVICE_CID \
{ 0xe638d760, 0x8687, 0x11d2, { 0xb5, 0x30, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0 } }
#define NS_BOOKMARKS_SERVICE_CONTRACTID \
    "@mozilla.org/browser/bookmarks-service;1"
#define NS_BOOKMARKS_DATASOURCE_CONTRACTID \
    "@mozilla.org/rdf/datasource;1?name=bookmarks"

#endif /* __gen_nsIBookmarksService_h__ */
