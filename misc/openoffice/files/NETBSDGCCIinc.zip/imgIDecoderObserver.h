/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM imgIDecoderObserver.idl
 */

#ifndef __gen_imgIDecoderObserver_h__
#define __gen_imgIDecoderObserver_h__


#ifndef __gen_imgIContainerObserver_h__
#include "imgIContainerObserver.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class imgIRequest; /* forward declaration */

class imgIContainer; /* forward declaration */

class gfxIImageFrame; /* forward declaration */

#include "nsRect.h"

/* starting interface:    imgIDecoderObserver */
#define IMGIDECODEROBSERVER_IID_STR "350163d2-1dd2-11b2-9e69-89959ecec1f3"

#define IMGIDECODEROBSERVER_IID \
  {0x350163d2, 0x1dd2, 0x11b2, \
    { 0x9e, 0x69, 0x89, 0x95, 0x9e, 0xce, 0xc1, 0xf3 }}

/**
 * imgIDecoderObserver interface
 *
 * @author Stuart Parmenter <pavlov@netscape.com>
 * @version 0.1
 * @see imagelib2
 */
class NS_NO_VTABLE imgIDecoderObserver : public imgIContainerObserver {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(IMGIDECODEROBSERVER_IID)

  /**
   * called as soon as the image begins getting decoded
   */
  /* void onStartDecode (in imgIRequest aRequest, in nsISupports cx); */
  NS_IMETHOD OnStartDecode(imgIRequest *aRequest, nsISupports *cx) = 0;

  /**
   * called once the image has been inited and therefore has a width and height
   */
  /* void onStartContainer (in imgIRequest aRequest, in nsISupports cx, in imgIContainer aContainer); */
  NS_IMETHOD OnStartContainer(imgIRequest *aRequest, nsISupports *cx, imgIContainer *aContainer) = 0;

  /**
   * called when each frame is created
   */
  /* void onStartFrame (in imgIRequest aRequest, in nsISupports cx, in gfxIImageFrame aFrame); */
  NS_IMETHOD OnStartFrame(imgIRequest *aRequest, nsISupports *cx, gfxIImageFrame *aFrame) = 0;

  /**
   * called when some part of the frame has new data in it
   */
  /* [noscript] void onDataAvailable (in imgIRequest aRequest, in nsISupports cx, in gfxIImageFrame aFrame, [const] in nsRect aRect); */
  NS_IMETHOD OnDataAvailable(imgIRequest *aRequest, nsISupports *cx, gfxIImageFrame *aFrame, const nsRect * aRect) = 0;

  /**
   * called when a frame is finished decoding
   */
  /* void onStopFrame (in imgIRequest aRequest, in nsISupports cx, in gfxIImageFrame aFrame); */
  NS_IMETHOD OnStopFrame(imgIRequest *aRequest, nsISupports *cx, gfxIImageFrame *aFrame) = 0;

  /**
   * probably not needed.  called right before onStopDecode
   */
  /* void onStopContainer (in imgIRequest aRequest, in nsISupports cx, in imgIContainer aContainer); */
  NS_IMETHOD OnStopContainer(imgIRequest *aRequest, nsISupports *cx, imgIContainer *aContainer) = 0;

  /**
   * called when the decoder is dying off
   */
  /* void onStopDecode (in imgIRequest aRequest, in nsISupports cx, in nsresult status, in wstring statusArg); */
  NS_IMETHOD OnStopDecode(imgIRequest *aRequest, nsISupports *cx, nsresult status, const PRUnichar *statusArg) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_IMGIDECODEROBSERVER \
  NS_IMETHOD OnStartDecode(imgIRequest *aRequest, nsISupports *cx); \
  NS_IMETHOD OnStartContainer(imgIRequest *aRequest, nsISupports *cx, imgIContainer *aContainer); \
  NS_IMETHOD OnStartFrame(imgIRequest *aRequest, nsISupports *cx, gfxIImageFrame *aFrame); \
  NS_IMETHOD OnDataAvailable(imgIRequest *aRequest, nsISupports *cx, gfxIImageFrame *aFrame, const nsRect * aRect); \
  NS_IMETHOD OnStopFrame(imgIRequest *aRequest, nsISupports *cx, gfxIImageFrame *aFrame); \
  NS_IMETHOD OnStopContainer(imgIRequest *aRequest, nsISupports *cx, imgIContainer *aContainer); \
  NS_IMETHOD OnStopDecode(imgIRequest *aRequest, nsISupports *cx, nsresult status, const PRUnichar *statusArg); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_IMGIDECODEROBSERVER(_to) \
  NS_IMETHOD OnStartDecode(imgIRequest *aRequest, nsISupports *cx) { return _to OnStartDecode(aRequest, cx); } \
  NS_IMETHOD OnStartContainer(imgIRequest *aRequest, nsISupports *cx, imgIContainer *aContainer) { return _to OnStartContainer(aRequest, cx, aContainer); } \
  NS_IMETHOD OnStartFrame(imgIRequest *aRequest, nsISupports *cx, gfxIImageFrame *aFrame) { return _to OnStartFrame(aRequest, cx, aFrame); } \
  NS_IMETHOD OnDataAvailable(imgIRequest *aRequest, nsISupports *cx, gfxIImageFrame *aFrame, const nsRect * aRect) { return _to OnDataAvailable(aRequest, cx, aFrame, aRect); } \
  NS_IMETHOD OnStopFrame(imgIRequest *aRequest, nsISupports *cx, gfxIImageFrame *aFrame) { return _to OnStopFrame(aRequest, cx, aFrame); } \
  NS_IMETHOD OnStopContainer(imgIRequest *aRequest, nsISupports *cx, imgIContainer *aContainer) { return _to OnStopContainer(aRequest, cx, aContainer); } \
  NS_IMETHOD OnStopDecode(imgIRequest *aRequest, nsISupports *cx, nsresult status, const PRUnichar *statusArg) { return _to OnStopDecode(aRequest, cx, status, statusArg); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_IMGIDECODEROBSERVER(_to) \
  NS_IMETHOD OnStartDecode(imgIRequest *aRequest, nsISupports *cx) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnStartDecode(aRequest, cx); } \
  NS_IMETHOD OnStartContainer(imgIRequest *aRequest, nsISupports *cx, imgIContainer *aContainer) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnStartContainer(aRequest, cx, aContainer); } \
  NS_IMETHOD OnStartFrame(imgIRequest *aRequest, nsISupports *cx, gfxIImageFrame *aFrame) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnStartFrame(aRequest, cx, aFrame); } \
  NS_IMETHOD OnDataAvailable(imgIRequest *aRequest, nsISupports *cx, gfxIImageFrame *aFrame, const nsRect * aRect) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnDataAvailable(aRequest, cx, aFrame, aRect); } \
  NS_IMETHOD OnStopFrame(imgIRequest *aRequest, nsISupports *cx, gfxIImageFrame *aFrame) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnStopFrame(aRequest, cx, aFrame); } \
  NS_IMETHOD OnStopContainer(imgIRequest *aRequest, nsISupports *cx, imgIContainer *aContainer) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnStopContainer(aRequest, cx, aContainer); } \
  NS_IMETHOD OnStopDecode(imgIRequest *aRequest, nsISupports *cx, nsresult status, const PRUnichar *statusArg) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnStopDecode(aRequest, cx, status, statusArg); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class _MYCLASS_ : public imgIDecoderObserver
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_IMGIDECODEROBSERVER

  _MYCLASS_();
  virtual ~_MYCLASS_();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(_MYCLASS_, imgIDecoderObserver)

_MYCLASS_::_MYCLASS_()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

_MYCLASS_::~_MYCLASS_()
{
  /* destructor code */
}

/* void onStartDecode (in imgIRequest aRequest, in nsISupports cx); */
NS_IMETHODIMP _MYCLASS_::OnStartDecode(imgIRequest *aRequest, nsISupports *cx)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void onStartContainer (in imgIRequest aRequest, in nsISupports cx, in imgIContainer aContainer); */
NS_IMETHODIMP _MYCLASS_::OnStartContainer(imgIRequest *aRequest, nsISupports *cx, imgIContainer *aContainer)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void onStartFrame (in imgIRequest aRequest, in nsISupports cx, in gfxIImageFrame aFrame); */
NS_IMETHODIMP _MYCLASS_::OnStartFrame(imgIRequest *aRequest, nsISupports *cx, gfxIImageFrame *aFrame)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void onDataAvailable (in imgIRequest aRequest, in nsISupports cx, in gfxIImageFrame aFrame, [const] in nsRect aRect); */
NS_IMETHODIMP _MYCLASS_::OnDataAvailable(imgIRequest *aRequest, nsISupports *cx, gfxIImageFrame *aFrame, const nsRect * aRect)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void onStopFrame (in imgIRequest aRequest, in nsISupports cx, in gfxIImageFrame aFrame); */
NS_IMETHODIMP _MYCLASS_::OnStopFrame(imgIRequest *aRequest, nsISupports *cx, gfxIImageFrame *aFrame)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void onStopContainer (in imgIRequest aRequest, in nsISupports cx, in imgIContainer aContainer); */
NS_IMETHODIMP _MYCLASS_::OnStopContainer(imgIRequest *aRequest, nsISupports *cx, imgIContainer *aContainer)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void onStopDecode (in imgIRequest aRequest, in nsISupports cx, in nsresult status, in wstring statusArg); */
NS_IMETHODIMP _MYCLASS_::OnStopDecode(imgIRequest *aRequest, nsISupports *cx, nsresult status, const PRUnichar *statusArg)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_imgIDecoderObserver_h__ */
