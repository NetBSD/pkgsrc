/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM MailNewsTypes2.idl
 */

#ifndef __gen_MailNewsTypes2_h__
#define __gen_MailNewsTypes2_h__
/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
typedef PRUint32 nsMsgKey;

typedef PRUint32 nsMsgViewIndex;

typedef PRInt32 nsMsgSearchScopeValue;

typedef PRInt32 nsMsgPriorityValue;


/* starting interface:    nsMsgPriority */
#define NS_MSGPRIORITY_IID_STR "94c0d8d8-2045-11d3-8a8f-0060b0fc04d2"

#define NS_MSGPRIORITY_IID \
  {0x94c0d8d8, 0x2045, 0x11d3, \
    { 0x8a, 0x8f, 0x00, 0x60, 0xb0, 0xfc, 0x04, 0xd2 }}

class NS_NO_VTABLE nsMsgPriority {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_MSGPRIORITY_IID)

  enum { notSet = 0 };

  enum { none = 1 };

  enum { lowest = 2 };

  enum { low = 3 };

  enum { normal = 4 };

  enum { high = 5 };

  enum { highest = 6 };

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSMSGPRIORITY \

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSMSGPRIORITY(_to) \

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSMSGPRIORITY(_to) \

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class _MYCLASS_ : public nsMsgPriority
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSMSGPRIORITY

  _MYCLASS_();
  virtual ~_MYCLASS_();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(_MYCLASS_, nsMsgPriority)

_MYCLASS_::_MYCLASS_()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

_MYCLASS_::~_MYCLASS_()
{
  /* destructor code */
}

/* End of implementation class template. */
#endif

typedef PRInt32 nsMsgViewSortOrderValue;

typedef PRInt32 nsMsgViewSortTypeValue;

typedef PRInt32 nsMsgViewTypeValue;

typedef PRInt32 nsMsgViewFlagsTypeValue;


#endif /* __gen_MailNewsTypes2_h__ */
