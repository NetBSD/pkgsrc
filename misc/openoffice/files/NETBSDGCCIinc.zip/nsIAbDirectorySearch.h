/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbDirectorySearch.idl
 */

#ifndef __gen_nsIAbDirectorySearch_h__
#define __gen_nsIAbDirectorySearch_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIAbDirectorySearch */
#define NS_IABDIRECTORYSEARCH_IID_STR "abf26047-37e3-44fd-a28a-6d37a1b9ccb3"

#define NS_IABDIRECTORYSEARCH_IID \
  {0xabf26047, 0x37e3, 0x44fd, \
    { 0xa2, 0x8a, 0x6d, 0x37, 0xa1, 0xb9, 0xcc, 0xb3 }}

/**
 * Searching of cards on a directory.
 *
 * The search data is defined in the query
 * section of the directory URI, for example
 *
 * moz-abldapdirectory://ldap1.holland/dc=sun,dc=com?<query>
 *
 * If no search data is defined then the methods
 * will return immediately with no error. 
 */
class NS_NO_VTABLE nsIAbDirectorySearch : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABDIRECTORYSEARCH_IID)

  /**
     * Starts a search on the directory.
     *
     * If a search is already being performed
     * it is stopped.
     *
     * The results from a search, cards, will
     * returned by informing the address book
     * session that a new card has been added
     * to the directory.
     *
     * The nsIAbDirectoryQuery implementation
     * of the directory component (or a proxy)
     * may be used as an implementation for
     * this specialization of query.
     *
     * This method is semantically equivalent
     * to the nsIAbDirectory.getChildCards
     * method when there is search criteria
     * defined in the directory uri.
     *
     */
  /* void startSearch (); */
  NS_IMETHOD StartSearch(void) = 0;

  /**
     * Stops a search on the directory.
     *
     */
  /* void stopSearch (); */
  NS_IMETHOD StopSearch(void) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABDIRECTORYSEARCH \
  NS_IMETHOD StartSearch(void); \
  NS_IMETHOD StopSearch(void); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABDIRECTORYSEARCH(_to) \
  NS_IMETHOD StartSearch(void) { return _to StartSearch(); } \
  NS_IMETHOD StopSearch(void) { return _to StopSearch(); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABDIRECTORYSEARCH(_to) \
  NS_IMETHOD StartSearch(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->StartSearch(); } \
  NS_IMETHOD StopSearch(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->StopSearch(); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbDirectorySearch : public nsIAbDirectorySearch
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABDIRECTORYSEARCH

  nsAbDirectorySearch();
  virtual ~nsAbDirectorySearch();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbDirectorySearch, nsIAbDirectorySearch)

nsAbDirectorySearch::nsAbDirectorySearch()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAbDirectorySearch::~nsAbDirectorySearch()
{
  /* destructor code */
}

/* void startSearch (); */
NS_IMETHODIMP nsAbDirectorySearch::StartSearch()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void stopSearch (); */
NS_IMETHODIMP nsAbDirectorySearch::StopSearch()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbDirectorySearch_h__ */
