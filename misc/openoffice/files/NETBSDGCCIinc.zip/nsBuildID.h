/* Build ID file.
*
* If building MOZILLLA_OFFICIAL (release build) NS_BUILD_ID will be updated
* to a current build id. This will be used to determine if we need to 
* re-register components.
*
*/
#define NS_BUILD_ID 0000000000
