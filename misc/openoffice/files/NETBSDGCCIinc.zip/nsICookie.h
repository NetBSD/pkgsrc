/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsICookie.idl
 */

#ifndef __gen_nsICookie_h__
#define __gen_nsICookie_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsICookie */
#define NS_ICOOKIE_IID_STR "e9fcb9a4-d376-458f-b720-e65e7df593bc"

#define NS_ICOOKIE_IID \
  {0xe9fcb9a4, 0xd376, 0x458f, \
    { 0xb7, 0x20, 0xe6, 0x5e, 0x7d, 0xf5, 0x93, 0xbc }}

/**
  This interface represents a HTTP or Javascript "cookie" object.
*/
class NS_NO_VTABLE nsICookie : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ICOOKIE_IID)

  /* readonly attribute string name; */
  NS_IMETHOD GetName(char * *aName) = 0;

  /* readonly attribute string value; */
  NS_IMETHOD GetValue(char * *aValue) = 0;

  /* readonly attribute boolean isDomain; */
  NS_IMETHOD GetIsDomain(PRBool *aIsDomain) = 0;

  /* readonly attribute string host; */
  NS_IMETHOD GetHost(char * *aHost) = 0;

  /* readonly attribute string path; */
  NS_IMETHOD GetPath(char * *aPath) = 0;

  /* readonly attribute boolean isSecure; */
  NS_IMETHOD GetIsSecure(PRBool *aIsSecure) = 0;

  /* readonly attribute PRUint64 expires; */
  NS_IMETHOD GetExpires(PRUint64 *aExpires) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSICOOKIE \
  NS_IMETHOD GetName(char * *aName); \
  NS_IMETHOD GetValue(char * *aValue); \
  NS_IMETHOD GetIsDomain(PRBool *aIsDomain); \
  NS_IMETHOD GetHost(char * *aHost); \
  NS_IMETHOD GetPath(char * *aPath); \
  NS_IMETHOD GetIsSecure(PRBool *aIsSecure); \
  NS_IMETHOD GetExpires(PRUint64 *aExpires); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSICOOKIE(_to) \
  NS_IMETHOD GetName(char * *aName) { return _to GetName(aName); } \
  NS_IMETHOD GetValue(char * *aValue) { return _to GetValue(aValue); } \
  NS_IMETHOD GetIsDomain(PRBool *aIsDomain) { return _to GetIsDomain(aIsDomain); } \
  NS_IMETHOD GetHost(char * *aHost) { return _to GetHost(aHost); } \
  NS_IMETHOD GetPath(char * *aPath) { return _to GetPath(aPath); } \
  NS_IMETHOD GetIsSecure(PRBool *aIsSecure) { return _to GetIsSecure(aIsSecure); } \
  NS_IMETHOD GetExpires(PRUint64 *aExpires) { return _to GetExpires(aExpires); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSICOOKIE(_to) \
  NS_IMETHOD GetName(char * *aName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetName(aName); } \
  NS_IMETHOD GetValue(char * *aValue) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetValue(aValue); } \
  NS_IMETHOD GetIsDomain(PRBool *aIsDomain) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsDomain(aIsDomain); } \
  NS_IMETHOD GetHost(char * *aHost) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetHost(aHost); } \
  NS_IMETHOD GetPath(char * *aPath) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPath(aPath); } \
  NS_IMETHOD GetIsSecure(PRBool *aIsSecure) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsSecure(aIsSecure); } \
  NS_IMETHOD GetExpires(PRUint64 *aExpires) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetExpires(aExpires); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsCookie : public nsICookie
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSICOOKIE

  nsCookie();
  virtual ~nsCookie();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsCookie, nsICookie)

nsCookie::nsCookie()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsCookie::~nsCookie()
{
  /* destructor code */
}

/* readonly attribute string name; */
NS_IMETHODIMP nsCookie::GetName(char * *aName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute string value; */
NS_IMETHODIMP nsCookie::GetValue(char * *aValue)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute boolean isDomain; */
NS_IMETHODIMP nsCookie::GetIsDomain(PRBool *aIsDomain)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute string host; */
NS_IMETHODIMP nsCookie::GetHost(char * *aHost)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute string path; */
NS_IMETHODIMP nsCookie::GetPath(char * *aPath)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute boolean isSecure; */
NS_IMETHODIMP nsCookie::GetIsSecure(PRBool *aIsSecure)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute PRUint64 expires; */
NS_IMETHODIMP nsCookie::GetExpires(PRUint64 *aExpires)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif

// {E9FCB9A4-D376-458f-B720-E65E7DF593BC}
#define NS_COOKIE_CID \
{ 0xe9fcb9a4, 0xd376, 0x458f, { 0xb7, 0x20, 0xe6, 0x5e, 0x7d, 0xf5, 0x93, 0xbc } }
#define NS_COOKIE_CONTRACTID "@mozilla.org/cookie;1"

#endif /* __gen_nsICookie_h__ */
