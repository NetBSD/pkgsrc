/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIDNSListener.idl
 */

#ifndef __gen_nsIDNSListener_h__
#define __gen_nsIDNSListener_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
#include "prnetdb.h"
typedef struct nsHostEnt
{
    PRHostEnt	hostEnt;
    char        buffer[PR_NETDB_BUF_SIZE];
    PRIntn      bufLen;
    char *      bufPtr;
} nsHostEnt;

/* starting interface:    nsIDNSListener */
#define NS_IDNSLISTENER_IID_STR "7686cef0-206e-11d3-9348-00104ba0fd40"

#define NS_IDNSLISTENER_IID \
  {0x7686cef0, 0x206e, 0x11d3, \
    { 0x93, 0x48, 0x00, 0x10, 0x4b, 0xa0, 0xfd, 0x40 }}

class NS_NO_VTABLE nsIDNSListener : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IDNSLISTENER_IID)

  /**
     * Notify the listener that we are about to lookup the requested hostname.
     */
  /* void OnStartLookup (in nsISupports ctxt, in string hostname); */
  NS_IMETHOD OnStartLookup(nsISupports *ctxt, const char *hostname) = 0;

  /**
     * Notify the listener that we have found one or more addresses for the hostname.
     */
  /* [noscript] void OnFound (in nsISupports ctxt, in string hostname, in nsHostEntStar entry); */
  NS_IMETHOD OnFound(nsISupports *ctxt, const char *hostname, nsHostEnt * entry) = 0;

  /**
     * Notify the listener that the lookup has completed.
     */
  /* void OnStopLookup (in nsISupports ctxt, in string hostname, in nsresult status); */
  NS_IMETHOD OnStopLookup(nsISupports *ctxt, const char *hostname, nsresult status) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIDNSLISTENER \
  NS_IMETHOD OnStartLookup(nsISupports *ctxt, const char *hostname); \
  NS_IMETHOD OnFound(nsISupports *ctxt, const char *hostname, nsHostEnt * entry); \
  NS_IMETHOD OnStopLookup(nsISupports *ctxt, const char *hostname, nsresult status); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIDNSLISTENER(_to) \
  NS_IMETHOD OnStartLookup(nsISupports *ctxt, const char *hostname) { return _to OnStartLookup(ctxt, hostname); } \
  NS_IMETHOD OnFound(nsISupports *ctxt, const char *hostname, nsHostEnt * entry) { return _to OnFound(ctxt, hostname, entry); } \
  NS_IMETHOD OnStopLookup(nsISupports *ctxt, const char *hostname, nsresult status) { return _to OnStopLookup(ctxt, hostname, status); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIDNSLISTENER(_to) \
  NS_IMETHOD OnStartLookup(nsISupports *ctxt, const char *hostname) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnStartLookup(ctxt, hostname); } \
  NS_IMETHOD OnFound(nsISupports *ctxt, const char *hostname, nsHostEnt * entry) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnFound(ctxt, hostname, entry); } \
  NS_IMETHOD OnStopLookup(nsISupports *ctxt, const char *hostname, nsresult status) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnStopLookup(ctxt, hostname, status); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsDNSListener : public nsIDNSListener
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIDNSLISTENER

  nsDNSListener();
  virtual ~nsDNSListener();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsDNSListener, nsIDNSListener)

nsDNSListener::nsDNSListener()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsDNSListener::~nsDNSListener()
{
  /* destructor code */
}

/* void OnStartLookup (in nsISupports ctxt, in string hostname); */
NS_IMETHODIMP nsDNSListener::OnStartLookup(nsISupports *ctxt, const char *hostname)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void OnFound (in nsISupports ctxt, in string hostname, in nsHostEntStar entry); */
NS_IMETHODIMP nsDNSListener::OnFound(nsISupports *ctxt, const char *hostname, nsHostEnt * entry)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void OnStopLookup (in nsISupports ctxt, in string hostname, in nsresult status); */
NS_IMETHODIMP nsDNSListener::OnStopLookup(nsISupports *ctxt, const char *hostname, nsresult status)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIDNSListener_h__ */
