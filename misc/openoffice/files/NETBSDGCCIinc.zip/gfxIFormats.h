/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM gfxIFormats.idl
 */

#ifndef __gen_gfxIFormats_h__
#define __gen_gfxIFormats_h__


#ifndef __gen_gfxtypes_h__
#include "gfxtypes.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    gfxIFormats */
/**
 * gfxIFormats interface
 *
 * @author Tim Rowley <tor@cs.brown.edu>
 * @author Stuart Parmenter <pavlov@netscape.com>
 * @version 0.0
 * @see gfx_format
 */
class NS_NO_VTABLE gfxIFormats {
 public: 

  /**
   * RGB    - duh...
   */
  enum { RGB = 0 };

  /**
   * BGR    - same as RGB except byteswaped
   */
  enum { BGR = 1 };

  /**
   * RGB_A1 - RGB image and 1-bit alpha mask
   */
  enum { RGB_A1 = 2 };

  /**
   * BGR_A1 - same as RGB_A1 except byteswaped
   */
  enum { BGR_A1 = 3 };

  /**
   * RGB_A8 - RGB image and 8-bit alpha image
   */
  enum { RGB_A8 = 4 };

  /**
   * BGR_A8 - same as RGB_A8 except byteswaped
   */
  enum { BGR_A8 = 5 };

  /**
   * RGBA   - packed RGBA image
   */
  enum { RGBA = 6 };

  /**
   * BGRA   - packed RGBA image
   */
  enum { BGRA = 7 };

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_GFXIFORMATS \

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_GFXIFORMATS(_to) \

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_GFXIFORMATS(_to) \

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class _MYCLASS_ : public gfxIFormats
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_GFXIFORMATS

  _MYCLASS_();
  virtual ~_MYCLASS_();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(_MYCLASS_, gfxIFormats)

_MYCLASS_::_MYCLASS_()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

_MYCLASS_::~_MYCLASS_()
{
  /* destructor code */
}

/* End of implementation class template. */
#endif


#endif /* __gen_gfxIFormats_h__ */
