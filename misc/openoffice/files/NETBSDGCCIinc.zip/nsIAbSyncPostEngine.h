/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbSyncPostEngine.idl
 */

#ifndef __gen_nsIAbSyncPostEngine_h__
#define __gen_nsIAbSyncPostEngine_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIAbSyncPostListener_h__
#include "nsIAbSyncPostListener.h"
#endif

#ifndef __gen_nsIDocShell_h__
#include "nsIDocShell.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIAbSyncPostEngineState */
#define NS_IABSYNCPOSTENGINESTATE_IID_STR "e0ed29d3-beef-11d4-8fd6-00a024a7d144"

#define NS_IABSYNCPOSTENGINESTATE_IID \
  {0xe0ed29d3, 0xbeef, 0x11d4, \
    { 0x8f, 0xd6, 0x00, 0xa0, 0x24, 0xa7, 0xd1, 0x44 }}

class NS_NO_VTABLE nsIAbSyncPostEngineState {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABSYNCPOSTENGINESTATE_IID)

  enum { nsIAbSyncPostIdle = 0 };

  enum { nsIAbSyncPostRunning = 1 };

  enum { nsIAbSyncAuthenticationRunning = 2 };

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABSYNCPOSTENGINESTATE \

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABSYNCPOSTENGINESTATE(_to) \

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABSYNCPOSTENGINESTATE(_to) \

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbSyncPostEngineState : public nsIAbSyncPostEngineState
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABSYNCPOSTENGINESTATE

  nsAbSyncPostEngineState();
  virtual ~nsAbSyncPostEngineState();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbSyncPostEngineState, nsIAbSyncPostEngineState)

nsAbSyncPostEngineState::nsAbSyncPostEngineState()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAbSyncPostEngineState::~nsAbSyncPostEngineState()
{
  /* destructor code */
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIAbSyncPostEngine */
#define NS_IABSYNCPOSTENGINE_IID_STR "e0ed29d3-098a-11d4-8fd6-00a024a7d144"

#define NS_IABSYNCPOSTENGINE_IID \
  {0xe0ed29d3, 0x098a, 0x11d4, \
    { 0x8f, 0xd6, 0x00, 0xa0, 0x24, 0xa7, 0xd1, 0x44 }}

class NS_NO_VTABLE nsIAbSyncPostEngine : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABSYNCPOSTENGINE_IID)

  /* void AddPostListener (in nsIAbSyncPostListener aListener); */
  NS_IMETHOD AddPostListener(nsIAbSyncPostListener *aListener) = 0;

  /* void RemovePostListener (in nsIAbSyncPostListener aListener); */
  NS_IMETHOD RemovePostListener(nsIAbSyncPostListener *aListener) = 0;

  /* string BuildMojoString (in nsIDocShell aRootDocShell); */
  NS_IMETHOD BuildMojoString(nsIDocShell *aRootDocShell, char **_retval) = 0;

  /* PRInt32 GetCurrentState (); */
  NS_IMETHOD GetCurrentState(PRInt32 *_retval) = 0;

  /* void GetMojoUserAndSnack (out string aMojoUser, out string aMojoSnack); */
  NS_IMETHOD GetMojoUserAndSnack(char **aMojoUser, char **aMojoSnack) = 0;

  /* void SendAbRequest (in string aSpec, in PRInt32 aPort, in string aProtocolRequest, in PRInt32 aTransactionID, in nsIDocShell aDocShell, in string aUser); */
  NS_IMETHOD SendAbRequest(const char *aSpec, PRInt32 aPort, const char *aProtocolRequest, PRInt32 aTransactionID, nsIDocShell *aDocShell, const char *aUser) = 0;

  /* void CancelAbSync (); */
  NS_IMETHOD CancelAbSync(void) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABSYNCPOSTENGINE \
  NS_IMETHOD AddPostListener(nsIAbSyncPostListener *aListener); \
  NS_IMETHOD RemovePostListener(nsIAbSyncPostListener *aListener); \
  NS_IMETHOD BuildMojoString(nsIDocShell *aRootDocShell, char **_retval); \
  NS_IMETHOD GetCurrentState(PRInt32 *_retval); \
  NS_IMETHOD GetMojoUserAndSnack(char **aMojoUser, char **aMojoSnack); \
  NS_IMETHOD SendAbRequest(const char *aSpec, PRInt32 aPort, const char *aProtocolRequest, PRInt32 aTransactionID, nsIDocShell *aDocShell, const char *aUser); \
  NS_IMETHOD CancelAbSync(void); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABSYNCPOSTENGINE(_to) \
  NS_IMETHOD AddPostListener(nsIAbSyncPostListener *aListener) { return _to AddPostListener(aListener); } \
  NS_IMETHOD RemovePostListener(nsIAbSyncPostListener *aListener) { return _to RemovePostListener(aListener); } \
  NS_IMETHOD BuildMojoString(nsIDocShell *aRootDocShell, char **_retval) { return _to BuildMojoString(aRootDocShell, _retval); } \
  NS_IMETHOD GetCurrentState(PRInt32 *_retval) { return _to GetCurrentState(_retval); } \
  NS_IMETHOD GetMojoUserAndSnack(char **aMojoUser, char **aMojoSnack) { return _to GetMojoUserAndSnack(aMojoUser, aMojoSnack); } \
  NS_IMETHOD SendAbRequest(const char *aSpec, PRInt32 aPort, const char *aProtocolRequest, PRInt32 aTransactionID, nsIDocShell *aDocShell, const char *aUser) { return _to SendAbRequest(aSpec, aPort, aProtocolRequest, aTransactionID, aDocShell, aUser); } \
  NS_IMETHOD CancelAbSync(void) { return _to CancelAbSync(); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABSYNCPOSTENGINE(_to) \
  NS_IMETHOD AddPostListener(nsIAbSyncPostListener *aListener) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddPostListener(aListener); } \
  NS_IMETHOD RemovePostListener(nsIAbSyncPostListener *aListener) { return !_to ? NS_ERROR_NULL_POINTER : _to->RemovePostListener(aListener); } \
  NS_IMETHOD BuildMojoString(nsIDocShell *aRootDocShell, char **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->BuildMojoString(aRootDocShell, _retval); } \
  NS_IMETHOD GetCurrentState(PRInt32 *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCurrentState(_retval); } \
  NS_IMETHOD GetMojoUserAndSnack(char **aMojoUser, char **aMojoSnack) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetMojoUserAndSnack(aMojoUser, aMojoSnack); } \
  NS_IMETHOD SendAbRequest(const char *aSpec, PRInt32 aPort, const char *aProtocolRequest, PRInt32 aTransactionID, nsIDocShell *aDocShell, const char *aUser) { return !_to ? NS_ERROR_NULL_POINTER : _to->SendAbRequest(aSpec, aPort, aProtocolRequest, aTransactionID, aDocShell, aUser); } \
  NS_IMETHOD CancelAbSync(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->CancelAbSync(); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbSyncPostEngine : public nsIAbSyncPostEngine
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABSYNCPOSTENGINE

  nsAbSyncPostEngine();
  virtual ~nsAbSyncPostEngine();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbSyncPostEngine, nsIAbSyncPostEngine)

nsAbSyncPostEngine::nsAbSyncPostEngine()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAbSyncPostEngine::~nsAbSyncPostEngine()
{
  /* destructor code */
}

/* void AddPostListener (in nsIAbSyncPostListener aListener); */
NS_IMETHODIMP nsAbSyncPostEngine::AddPostListener(nsIAbSyncPostListener *aListener)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void RemovePostListener (in nsIAbSyncPostListener aListener); */
NS_IMETHODIMP nsAbSyncPostEngine::RemovePostListener(nsIAbSyncPostListener *aListener)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* string BuildMojoString (in nsIDocShell aRootDocShell); */
NS_IMETHODIMP nsAbSyncPostEngine::BuildMojoString(nsIDocShell *aRootDocShell, char **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* PRInt32 GetCurrentState (); */
NS_IMETHODIMP nsAbSyncPostEngine::GetCurrentState(PRInt32 *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void GetMojoUserAndSnack (out string aMojoUser, out string aMojoSnack); */
NS_IMETHODIMP nsAbSyncPostEngine::GetMojoUserAndSnack(char **aMojoUser, char **aMojoSnack)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void SendAbRequest (in string aSpec, in PRInt32 aPort, in string aProtocolRequest, in PRInt32 aTransactionID, in nsIDocShell aDocShell, in string aUser); */
NS_IMETHODIMP nsAbSyncPostEngine::SendAbRequest(const char *aSpec, PRInt32 aPort, const char *aProtocolRequest, PRInt32 aTransactionID, nsIDocShell *aDocShell, const char *aUser)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void CancelAbSync (); */
NS_IMETHODIMP nsAbSyncPostEngine::CancelAbSync()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbSyncPostEngine_h__ */
