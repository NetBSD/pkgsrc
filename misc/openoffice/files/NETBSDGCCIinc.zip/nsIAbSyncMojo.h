/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbSyncMojo.idl
 */

#ifndef __gen_nsIAbSyncMojo_h__
#define __gen_nsIAbSyncMojo_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIStreamListener_h__
#include "nsIStreamListener.h"
#endif

#ifndef __gen_nsIDocShell_h__
#include "nsIDocShell.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
#define NS_AB_SYNC_MOJO_CID \
  { 0x842cc263, 0x5255, 0x1144,   \
  { 0xcc, 0xb8, 0x44, 0x45, 0x53, 0xff, 0x0, 0x2 } }
  
#define NS_AB_SYNC_MOJO_CONTRACTID			\
  "@mozilla.org/absync/absyncmojo;1"

/* starting interface:    nsIAbSyncMojo */
#define NS_IABSYNCMOJO_IID_STR "74872d27-0a4e-11d4-8fd6-beef24a7d144"

#define NS_IABSYNCMOJO_IID \
  {0x74872d27, 0x0a4e, 0x11d4, \
    { 0x8f, 0xd6, 0xbe, 0xef, 0x24, 0xa7, 0xd1, 0x44 }}

class NS_NO_VTABLE nsIAbSyncMojo : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABSYNCMOJO_IID)

  /* string BuildMojoString (in nsIDocShell aRootDocShell); */
  NS_IMETHOD BuildMojoString(nsIDocShell *aRootDocShell, char **_retval) = 0;

  /* void StartAbSyncMojo (in nsIStreamListener aListener, in nsIDocShell aRootDocShell, in string aUser); */
  NS_IMETHOD StartAbSyncMojo(nsIStreamListener *aListener, nsIDocShell *aRootDocShell, const char *aUser) = 0;

  /* void GetAbSyncMojoResults (out string aMojoUser, out string aMojoString, out string aMojoSpec, out long aMojoPort); */
  NS_IMETHOD GetAbSyncMojoResults(char **aMojoUser, char **aMojoString, char **aMojoSpec, PRInt32 *aMojoPort) = 0;

  /* void CancelTheMojo (); */
  NS_IMETHOD CancelTheMojo(void) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABSYNCMOJO \
  NS_IMETHOD BuildMojoString(nsIDocShell *aRootDocShell, char **_retval); \
  NS_IMETHOD StartAbSyncMojo(nsIStreamListener *aListener, nsIDocShell *aRootDocShell, const char *aUser); \
  NS_IMETHOD GetAbSyncMojoResults(char **aMojoUser, char **aMojoString, char **aMojoSpec, PRInt32 *aMojoPort); \
  NS_IMETHOD CancelTheMojo(void); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABSYNCMOJO(_to) \
  NS_IMETHOD BuildMojoString(nsIDocShell *aRootDocShell, char **_retval) { return _to BuildMojoString(aRootDocShell, _retval); } \
  NS_IMETHOD StartAbSyncMojo(nsIStreamListener *aListener, nsIDocShell *aRootDocShell, const char *aUser) { return _to StartAbSyncMojo(aListener, aRootDocShell, aUser); } \
  NS_IMETHOD GetAbSyncMojoResults(char **aMojoUser, char **aMojoString, char **aMojoSpec, PRInt32 *aMojoPort) { return _to GetAbSyncMojoResults(aMojoUser, aMojoString, aMojoSpec, aMojoPort); } \
  NS_IMETHOD CancelTheMojo(void) { return _to CancelTheMojo(); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABSYNCMOJO(_to) \
  NS_IMETHOD BuildMojoString(nsIDocShell *aRootDocShell, char **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->BuildMojoString(aRootDocShell, _retval); } \
  NS_IMETHOD StartAbSyncMojo(nsIStreamListener *aListener, nsIDocShell *aRootDocShell, const char *aUser) { return !_to ? NS_ERROR_NULL_POINTER : _to->StartAbSyncMojo(aListener, aRootDocShell, aUser); } \
  NS_IMETHOD GetAbSyncMojoResults(char **aMojoUser, char **aMojoString, char **aMojoSpec, PRInt32 *aMojoPort) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAbSyncMojoResults(aMojoUser, aMojoString, aMojoSpec, aMojoPort); } \
  NS_IMETHOD CancelTheMojo(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->CancelTheMojo(); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbSyncMojo : public nsIAbSyncMojo
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABSYNCMOJO

  nsAbSyncMojo();
  virtual ~nsAbSyncMojo();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbSyncMojo, nsIAbSyncMojo)

nsAbSyncMojo::nsAbSyncMojo()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAbSyncMojo::~nsAbSyncMojo()
{
  /* destructor code */
}

/* string BuildMojoString (in nsIDocShell aRootDocShell); */
NS_IMETHODIMP nsAbSyncMojo::BuildMojoString(nsIDocShell *aRootDocShell, char **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void StartAbSyncMojo (in nsIStreamListener aListener, in nsIDocShell aRootDocShell, in string aUser); */
NS_IMETHODIMP nsAbSyncMojo::StartAbSyncMojo(nsIStreamListener *aListener, nsIDocShell *aRootDocShell, const char *aUser)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void GetAbSyncMojoResults (out string aMojoUser, out string aMojoString, out string aMojoSpec, out long aMojoPort); */
NS_IMETHODIMP nsAbSyncMojo::GetAbSyncMojoResults(char **aMojoUser, char **aMojoString, char **aMojoSpec, PRInt32 *aMojoPort)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void CancelTheMojo (); */
NS_IMETHODIMP nsAbSyncMojo::CancelTheMojo()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbSyncMojo_h__ */
