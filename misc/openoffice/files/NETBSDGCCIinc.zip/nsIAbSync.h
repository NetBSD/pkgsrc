/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbSync.idl
 */

#ifndef __gen_nsIAbSync_h__
#define __gen_nsIAbSync_h__


#ifndef __gen_nsrootidl_h__
#include "nsrootidl.h"
#endif

#ifndef __gen_nsIAbSyncListener_h__
#include "nsIAbSyncListener.h"
#endif

#ifndef __gen_nsIMsgStatusFeedback_h__
#include "nsIMsgStatusFeedback.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIAbSyncState */
class NS_NO_VTABLE nsIAbSyncState {
 public: 

  enum { nsIAbSyncIdle = 0 };

  enum { nsIAbSyncRunning = 1 };

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABSYNCSTATE \

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABSYNCSTATE(_to) \

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABSYNCSTATE(_to) \

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbSyncState : public nsIAbSyncState
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABSYNCSTATE

  nsAbSyncState();
  virtual ~nsAbSyncState();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbSyncState, nsIAbSyncState)

nsAbSyncState::nsAbSyncState()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAbSyncState::~nsAbSyncState()
{
  /* destructor code */
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIAbSync */
#define NS_IABSYNC_IID_STR "74872d27-0a4e-11d4-8fd6-00a024a7d144"

#define NS_IABSYNC_IID \
  {0x74872d27, 0x0a4e, 0x11d4, \
    { 0x8f, 0xd6, 0x00, 0xa0, 0x24, 0xa7, 0xd1, 0x44 }}

class NS_NO_VTABLE nsIAbSync : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABSYNC_IID)

  /* void AddSyncListener (in nsIAbSyncListener aListener); */
  NS_IMETHOD AddSyncListener(nsIAbSyncListener *aListener) = 0;

  /* void RemoveSyncListener (in nsIAbSyncListener aListener); */
  NS_IMETHOD RemoveSyncListener(nsIAbSyncListener *aListener) = 0;

  /* PRInt32 GetCurrentState (); */
  NS_IMETHOD GetCurrentState(PRInt32 *_retval) = 0;

  /* void PerformAbSync (in nsIDOMWindowInternal aDOMWindow, out PRInt32 aTransactionID); */
  NS_IMETHOD PerformAbSync(nsIDOMWindowInternal *aDOMWindow, PRInt32 *aTransactionID) = 0;

  /* void CancelAbSync (); */
  NS_IMETHOD CancelAbSync(void) = 0;

  /* void SetAbSyncUser (in string aUser); */
  NS_IMETHOD SetAbSyncUser(const char *aUser) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABSYNC \
  NS_IMETHOD AddSyncListener(nsIAbSyncListener *aListener); \
  NS_IMETHOD RemoveSyncListener(nsIAbSyncListener *aListener); \
  NS_IMETHOD GetCurrentState(PRInt32 *_retval); \
  NS_IMETHOD PerformAbSync(nsIDOMWindowInternal *aDOMWindow, PRInt32 *aTransactionID); \
  NS_IMETHOD CancelAbSync(void); \
  NS_IMETHOD SetAbSyncUser(const char *aUser); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABSYNC(_to) \
  NS_IMETHOD AddSyncListener(nsIAbSyncListener *aListener) { return _to AddSyncListener(aListener); } \
  NS_IMETHOD RemoveSyncListener(nsIAbSyncListener *aListener) { return _to RemoveSyncListener(aListener); } \
  NS_IMETHOD GetCurrentState(PRInt32 *_retval) { return _to GetCurrentState(_retval); } \
  NS_IMETHOD PerformAbSync(nsIDOMWindowInternal *aDOMWindow, PRInt32 *aTransactionID) { return _to PerformAbSync(aDOMWindow, aTransactionID); } \
  NS_IMETHOD CancelAbSync(void) { return _to CancelAbSync(); } \
  NS_IMETHOD SetAbSyncUser(const char *aUser) { return _to SetAbSyncUser(aUser); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABSYNC(_to) \
  NS_IMETHOD AddSyncListener(nsIAbSyncListener *aListener) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddSyncListener(aListener); } \
  NS_IMETHOD RemoveSyncListener(nsIAbSyncListener *aListener) { return !_to ? NS_ERROR_NULL_POINTER : _to->RemoveSyncListener(aListener); } \
  NS_IMETHOD GetCurrentState(PRInt32 *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCurrentState(_retval); } \
  NS_IMETHOD PerformAbSync(nsIDOMWindowInternal *aDOMWindow, PRInt32 *aTransactionID) { return !_to ? NS_ERROR_NULL_POINTER : _to->PerformAbSync(aDOMWindow, aTransactionID); } \
  NS_IMETHOD CancelAbSync(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->CancelAbSync(); } \
  NS_IMETHOD SetAbSyncUser(const char *aUser) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetAbSyncUser(aUser); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbSync : public nsIAbSync
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABSYNC

  nsAbSync();
  virtual ~nsAbSync();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbSync, nsIAbSync)

nsAbSync::nsAbSync()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAbSync::~nsAbSync()
{
  /* destructor code */
}

/* void AddSyncListener (in nsIAbSyncListener aListener); */
NS_IMETHODIMP nsAbSync::AddSyncListener(nsIAbSyncListener *aListener)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void RemoveSyncListener (in nsIAbSyncListener aListener); */
NS_IMETHODIMP nsAbSync::RemoveSyncListener(nsIAbSyncListener *aListener)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* PRInt32 GetCurrentState (); */
NS_IMETHODIMP nsAbSync::GetCurrentState(PRInt32 *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void PerformAbSync (in nsIDOMWindowInternal aDOMWindow, out PRInt32 aTransactionID); */
NS_IMETHODIMP nsAbSync::PerformAbSync(nsIDOMWindowInternal *aDOMWindow, PRInt32 *aTransactionID)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void CancelAbSync (); */
NS_IMETHODIMP nsAbSync::CancelAbSync()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void SetAbSyncUser (in string aUser); */
NS_IMETHODIMP nsAbSync::SetAbSyncUser(const char *aUser)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbSync_h__ */
