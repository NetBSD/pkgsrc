/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM imgIDecoder.idl
 */

#ifndef __gen_imgIDecoder_h__
#define __gen_imgIDecoder_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIOutputStream_h__
#include "nsIOutputStream.h"
#endif

#ifndef __gen_gfxtypes_h__
#include "gfxtypes.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class imgIRequest; /* forward declaration */


/* starting interface:    imgIDecoder */
#define IMGIDECODER_IID_STR "9eebf43a-1dd1-11b2-953e-f1782f4cbad3"

#define IMGIDECODER_IID \
  {0x9eebf43a, 0x1dd1, 0x11b2, \
    { 0x95, 0x3e, 0xf1, 0x78, 0x2f, 0x4c, 0xba, 0xd3 }}

/**
 * imgIDecoder interface
 *
 * @author Stuart Parmenter <pavlov@netscape.com>
 * @version 0.1
 * @see imagelib2
 */
class NS_NO_VTABLE imgIDecoder : public nsIOutputStream {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(IMGIDECODER_IID)

  /**
   * Initalize an image decoder.
   * @param aRequest the request that owns the decoder.
   *
   * @note The decode should QI \a aRequest to an imgIDecoderObserver
   * and should send decoder notifications to the request.
   * The decoder should always pass NULL as the first two parameters to
   * all of the imgIDecoderObserver APIs.
   */
  /* void init (in imgIRequest aRequest); */
  NS_IMETHOD Init(imgIRequest *aRequest) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_IMGIDECODER \
  NS_IMETHOD Init(imgIRequest *aRequest); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_IMGIDECODER(_to) \
  NS_IMETHOD Init(imgIRequest *aRequest) { return _to Init(aRequest); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_IMGIDECODER(_to) \
  NS_IMETHOD Init(imgIRequest *aRequest) { return !_to ? NS_ERROR_NULL_POINTER : _to->Init(aRequest); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class _MYCLASS_ : public imgIDecoder
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_IMGIDECODER

  _MYCLASS_();
  virtual ~_MYCLASS_();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(_MYCLASS_, imgIDecoder)

_MYCLASS_::_MYCLASS_()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

_MYCLASS_::~_MYCLASS_()
{
  /* destructor code */
}

/* void init (in imgIRequest aRequest); */
NS_IMETHODIMP _MYCLASS_::Init(imgIRequest *aRequest)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_imgIDecoder_h__ */
