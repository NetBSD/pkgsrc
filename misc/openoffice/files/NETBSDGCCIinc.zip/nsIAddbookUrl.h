/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAddbookUrl.idl
 */

#ifndef __gen_nsIAddbookUrl_h__
#define __gen_nsIAddbookUrl_h__


#ifndef __gen_nsIURI_h__
#include "nsIURI.h"
#endif

#ifndef __gen_nsIAbCard_h__
#include "nsIAbCard.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIAddbookUrlOperation */
#define NS_IADDBOOKURLOPERATION_IID_STR "6eb9d874-01aa-11d4-8fbe-000064657374"

#define NS_IADDBOOKURLOPERATION_IID \
  {0x6eb9d874, 0x01aa, 0x11d4, \
    { 0x8f, 0xbe, 0x00, 0x00, 0x64, 0x65, 0x73, 0x74 }}

class NS_NO_VTABLE nsIAddbookUrlOperation {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IADDBOOKURLOPERATION_IID)

  enum { InvalidUrl = 0 };

  enum { PrintIndividual = 1 };

  enum { PrintAddressBook = 2 };

  enum { ImportCards = 3 };

  enum { ImportMailingLists = 4 };

  enum { ExportCards = 5 };

  enum { AddToAddressBook = 6 };

  enum { ExportTitle = 7 };

  enum { ImportTitle = 8 };

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIADDBOOKURLOPERATION \

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIADDBOOKURLOPERATION(_to) \

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIADDBOOKURLOPERATION(_to) \

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAddbookUrlOperation : public nsIAddbookUrlOperation
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIADDBOOKURLOPERATION

  nsAddbookUrlOperation();
  virtual ~nsAddbookUrlOperation();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAddbookUrlOperation, nsIAddbookUrlOperation)

nsAddbookUrlOperation::nsAddbookUrlOperation()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAddbookUrlOperation::~nsAddbookUrlOperation()
{
  /* destructor code */
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIAddbookUrl */
class NS_NO_VTABLE nsIAddbookUrl : public nsIURI {
 public: 

  /* long GetAddbookOperation (); */
  NS_IMETHOD GetAddbookOperation(PRInt32 *_retval) = 0;

  /* nsIAbCard GetAbCard (); */
  NS_IMETHOD GetAbCard(nsIAbCard **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIADDBOOKURL \
  NS_IMETHOD GetAddbookOperation(PRInt32 *_retval); \
  NS_IMETHOD GetAbCard(nsIAbCard **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIADDBOOKURL(_to) \
  NS_IMETHOD GetAddbookOperation(PRInt32 *_retval) { return _to GetAddbookOperation(_retval); } \
  NS_IMETHOD GetAbCard(nsIAbCard **_retval) { return _to GetAbCard(_retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIADDBOOKURL(_to) \
  NS_IMETHOD GetAddbookOperation(PRInt32 *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAddbookOperation(_retval); } \
  NS_IMETHOD GetAbCard(nsIAbCard **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAbCard(_retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAddbookUrl : public nsIAddbookUrl
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIADDBOOKURL

  nsAddbookUrl();
  virtual ~nsAddbookUrl();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAddbookUrl, nsIAddbookUrl)

nsAddbookUrl::nsAddbookUrl()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAddbookUrl::~nsAddbookUrl()
{
  /* destructor code */
}

/* long GetAddbookOperation (); */
NS_IMETHODIMP nsAddbookUrl::GetAddbookOperation(PRInt32 *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAbCard GetAbCard (); */
NS_IMETHODIMP nsAddbookUrl::GetAbCard(nsIAbCard **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAddbookUrl_h__ */
