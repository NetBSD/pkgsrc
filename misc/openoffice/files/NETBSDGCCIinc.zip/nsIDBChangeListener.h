/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIDBChangeListener.idl
 */

#ifndef __gen_nsIDBChangeListener_h__
#define __gen_nsIDBChangeListener_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_MailNewsTypes2_h__
#include "MailNewsTypes2.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIDBChangeAnnouncer; /* forward declaration */


/* starting interface:    nsIDBChangeListener */
#define NS_IDBCHANGELISTENER_IID_STR "ad0f7f90-baff-11d2-8d67-00805f8a6617"

#define NS_IDBCHANGELISTENER_IID \
  {0xad0f7f90, 0xbaff, 0x11d2, \
    { 0x8d, 0x67, 0x00, 0x80, 0x5f, 0x8a, 0x66, 0x17 }}

class NS_NO_VTABLE nsIDBChangeListener : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IDBCHANGELISTENER_IID)

  /* void OnKeyChange (in nsMsgKey aKeyChanged, in unsigned long aOldFlags, in unsigned long aNewFlags, in nsIDBChangeListener aInstigator); */
  NS_IMETHOD OnKeyChange(nsMsgKey aKeyChanged, PRUint32 aOldFlags, PRUint32 aNewFlags, nsIDBChangeListener *aInstigator) = 0;

  /* void OnKeyDeleted (in nsMsgKey aKeyChanged, in nsMsgKey aParentKey, in long aFlags, in nsIDBChangeListener aInstigator); */
  NS_IMETHOD OnKeyDeleted(nsMsgKey aKeyChanged, nsMsgKey aParentKey, PRInt32 aFlags, nsIDBChangeListener *aInstigator) = 0;

  /* void OnKeyAdded (in nsMsgKey aKeyChanged, in nsMsgKey aParentKey, in long aFlags, in nsIDBChangeListener aInstigator); */
  NS_IMETHOD OnKeyAdded(nsMsgKey aKeyChanged, nsMsgKey aParentKey, PRInt32 aFlags, nsIDBChangeListener *aInstigator) = 0;

  /* void OnParentChanged (in nsMsgKey aKeyChanged, in nsMsgKey oldParent, in nsMsgKey newParent, in nsIDBChangeListener aInstigator); */
  NS_IMETHOD OnParentChanged(nsMsgKey aKeyChanged, nsMsgKey oldParent, nsMsgKey newParent, nsIDBChangeListener *aInstigator) = 0;

  /* void OnAnnouncerGoingAway (in nsIDBChangeAnnouncer instigator); */
  NS_IMETHOD OnAnnouncerGoingAway(nsIDBChangeAnnouncer *instigator) = 0;

  /* void OnReadChanged (in nsIDBChangeListener instigator); */
  NS_IMETHOD OnReadChanged(nsIDBChangeListener *instigator) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIDBCHANGELISTENER \
  NS_IMETHOD OnKeyChange(nsMsgKey aKeyChanged, PRUint32 aOldFlags, PRUint32 aNewFlags, nsIDBChangeListener *aInstigator); \
  NS_IMETHOD OnKeyDeleted(nsMsgKey aKeyChanged, nsMsgKey aParentKey, PRInt32 aFlags, nsIDBChangeListener *aInstigator); \
  NS_IMETHOD OnKeyAdded(nsMsgKey aKeyChanged, nsMsgKey aParentKey, PRInt32 aFlags, nsIDBChangeListener *aInstigator); \
  NS_IMETHOD OnParentChanged(nsMsgKey aKeyChanged, nsMsgKey oldParent, nsMsgKey newParent, nsIDBChangeListener *aInstigator); \
  NS_IMETHOD OnAnnouncerGoingAway(nsIDBChangeAnnouncer *instigator); \
  NS_IMETHOD OnReadChanged(nsIDBChangeListener *instigator); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIDBCHANGELISTENER(_to) \
  NS_IMETHOD OnKeyChange(nsMsgKey aKeyChanged, PRUint32 aOldFlags, PRUint32 aNewFlags, nsIDBChangeListener *aInstigator) { return _to OnKeyChange(aKeyChanged, aOldFlags, aNewFlags, aInstigator); } \
  NS_IMETHOD OnKeyDeleted(nsMsgKey aKeyChanged, nsMsgKey aParentKey, PRInt32 aFlags, nsIDBChangeListener *aInstigator) { return _to OnKeyDeleted(aKeyChanged, aParentKey, aFlags, aInstigator); } \
  NS_IMETHOD OnKeyAdded(nsMsgKey aKeyChanged, nsMsgKey aParentKey, PRInt32 aFlags, nsIDBChangeListener *aInstigator) { return _to OnKeyAdded(aKeyChanged, aParentKey, aFlags, aInstigator); } \
  NS_IMETHOD OnParentChanged(nsMsgKey aKeyChanged, nsMsgKey oldParent, nsMsgKey newParent, nsIDBChangeListener *aInstigator) { return _to OnParentChanged(aKeyChanged, oldParent, newParent, aInstigator); } \
  NS_IMETHOD OnAnnouncerGoingAway(nsIDBChangeAnnouncer *instigator) { return _to OnAnnouncerGoingAway(instigator); } \
  NS_IMETHOD OnReadChanged(nsIDBChangeListener *instigator) { return _to OnReadChanged(instigator); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIDBCHANGELISTENER(_to) \
  NS_IMETHOD OnKeyChange(nsMsgKey aKeyChanged, PRUint32 aOldFlags, PRUint32 aNewFlags, nsIDBChangeListener *aInstigator) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnKeyChange(aKeyChanged, aOldFlags, aNewFlags, aInstigator); } \
  NS_IMETHOD OnKeyDeleted(nsMsgKey aKeyChanged, nsMsgKey aParentKey, PRInt32 aFlags, nsIDBChangeListener *aInstigator) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnKeyDeleted(aKeyChanged, aParentKey, aFlags, aInstigator); } \
  NS_IMETHOD OnKeyAdded(nsMsgKey aKeyChanged, nsMsgKey aParentKey, PRInt32 aFlags, nsIDBChangeListener *aInstigator) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnKeyAdded(aKeyChanged, aParentKey, aFlags, aInstigator); } \
  NS_IMETHOD OnParentChanged(nsMsgKey aKeyChanged, nsMsgKey oldParent, nsMsgKey newParent, nsIDBChangeListener *aInstigator) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnParentChanged(aKeyChanged, oldParent, newParent, aInstigator); } \
  NS_IMETHOD OnAnnouncerGoingAway(nsIDBChangeAnnouncer *instigator) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnAnnouncerGoingAway(instigator); } \
  NS_IMETHOD OnReadChanged(nsIDBChangeListener *instigator) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnReadChanged(instigator); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsDBChangeListener : public nsIDBChangeListener
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIDBCHANGELISTENER

  nsDBChangeListener();
  virtual ~nsDBChangeListener();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsDBChangeListener, nsIDBChangeListener)

nsDBChangeListener::nsDBChangeListener()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsDBChangeListener::~nsDBChangeListener()
{
  /* destructor code */
}

/* void OnKeyChange (in nsMsgKey aKeyChanged, in unsigned long aOldFlags, in unsigned long aNewFlags, in nsIDBChangeListener aInstigator); */
NS_IMETHODIMP nsDBChangeListener::OnKeyChange(nsMsgKey aKeyChanged, PRUint32 aOldFlags, PRUint32 aNewFlags, nsIDBChangeListener *aInstigator)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void OnKeyDeleted (in nsMsgKey aKeyChanged, in nsMsgKey aParentKey, in long aFlags, in nsIDBChangeListener aInstigator); */
NS_IMETHODIMP nsDBChangeListener::OnKeyDeleted(nsMsgKey aKeyChanged, nsMsgKey aParentKey, PRInt32 aFlags, nsIDBChangeListener *aInstigator)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void OnKeyAdded (in nsMsgKey aKeyChanged, in nsMsgKey aParentKey, in long aFlags, in nsIDBChangeListener aInstigator); */
NS_IMETHODIMP nsDBChangeListener::OnKeyAdded(nsMsgKey aKeyChanged, nsMsgKey aParentKey, PRInt32 aFlags, nsIDBChangeListener *aInstigator)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void OnParentChanged (in nsMsgKey aKeyChanged, in nsMsgKey oldParent, in nsMsgKey newParent, in nsIDBChangeListener aInstigator); */
NS_IMETHODIMP nsDBChangeListener::OnParentChanged(nsMsgKey aKeyChanged, nsMsgKey oldParent, nsMsgKey newParent, nsIDBChangeListener *aInstigator)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void OnAnnouncerGoingAway (in nsIDBChangeAnnouncer instigator); */
NS_IMETHODIMP nsDBChangeListener::OnAnnouncerGoingAway(nsIDBChangeAnnouncer *instigator)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void OnReadChanged (in nsIDBChangeListener instigator); */
NS_IMETHODIMP nsDBChangeListener::OnReadChanged(nsIDBChangeListener *instigator)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIDBChangeListener_h__ */
