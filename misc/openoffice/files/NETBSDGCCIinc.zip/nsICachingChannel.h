/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsICachingChannel.idl
 */

#ifndef __gen_nsICachingChannel_h__
#define __gen_nsICachingChannel_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIFile; /* forward declaration */


/* starting interface:    nsICachingChannel */
#define NS_ICACHINGCHANNEL_IID_STR "b1f95f5e-ee05-4434-9d34-89a935d7feef"

#define NS_ICACHINGCHANNEL_IID \
  {0xb1f95f5e, 0xee05, 0x4434, \
    { 0x9d, 0x34, 0x89, 0xa9, 0x35, 0xd7, 0xfe, 0xef }}

/**
 * A channel may optionally implement this interface to allow clients
 * to effect its behavior with respect to how it uses the cache service.
 *
 * This interface provides:
 *   1) Support for "stream as file" semantics (for JAR and plugins).
 *   2) Support for "pinning" cached data in the cache (for printing and save-as).
 */
class NS_NO_VTABLE nsICachingChannel : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ICACHINGCHANNEL_IID)

  /**
     * Set/get the cache token... uniquely identifies the data in the cache.
     * Holding a reference to this token prevents the cached data from being
     * removed.  A cache token retrieved from a particular instance of 
     * nsICachingChannel could be set on another instance of nsICachingChannel
     * provided the underlying implementations are compatible.  The implemen-
     * tation of nsICachingChannel would be expected to only read from the
     * cache entry identified by the cache token and not try to validate it.
     *
     * The cache token can be treated as an opaque object; however, it can be
     * QI'd to a nsICacheEntryDescriptor if more detailed information about the
     * cache entry is needed.
     */
  /* attribute nsISupports cacheToken; */
  NS_IMETHOD GetCacheToken(nsISupports * *aCacheToken) = 0;
  NS_IMETHOD SetCacheToken(nsISupports * aCacheToken) = 0;

  /**
     * Set/get the cache key... uniquely identifies the data in the cache.
     * Holding a reference to this key DOES NOT prevent the cached data from
     * being removed.  It is otherwise similar to the cacheToken.
     *
     * The fromCacheOnly flag inhibits fetching from the net if the data in the
     * cache has been evicted.  An error of NS_ERROR_DOCUMENT_NOT_CACHED will
     * be sent to the listener's onStopRequest in this case.
     */
  /* nsISupports getCacheKey (); */
  NS_IMETHOD GetCacheKey(nsISupports **_retval) = 0;

  /* void setCacheKey (in nsISupports cacheKey, in boolean fromCacheOnly); */
  NS_IMETHOD SetCacheKey(nsISupports *cacheKey, PRBool fromCacheOnly) = 0;

  /**
     * Specifies whether or not the data should be cached to a file.  This
     * may fail if the disk cache is not present.  The value of this attribute
     * is usually only settable during the processing of a channel's
     * OnStartRequest.  The default value of this attribute depends on the
     * particular implementation of nsICachingChannel.
     */
  /* attribute boolean cacheAsFile; */
  NS_IMETHOD GetCacheAsFile(PRBool *aCacheAsFile) = 0;
  NS_IMETHOD SetCacheAsFile(PRBool aCacheAsFile) = 0;

  /**
     * Get the "file" where the cached data can be found.  This is valid for
     * as long as a reference to the cache token is held.  This may return
     * an error if cacheAsFile is false.
     */
  /* readonly attribute nsIFile cacheFile; */
  NS_IMETHOD GetCacheFile(nsIFile * *aCacheFile) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSICACHINGCHANNEL \
  NS_IMETHOD GetCacheToken(nsISupports * *aCacheToken); \
  NS_IMETHOD SetCacheToken(nsISupports * aCacheToken); \
  NS_IMETHOD GetCacheKey(nsISupports **_retval); \
  NS_IMETHOD SetCacheKey(nsISupports *cacheKey, PRBool fromCacheOnly); \
  NS_IMETHOD GetCacheAsFile(PRBool *aCacheAsFile); \
  NS_IMETHOD SetCacheAsFile(PRBool aCacheAsFile); \
  NS_IMETHOD GetCacheFile(nsIFile * *aCacheFile); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSICACHINGCHANNEL(_to) \
  NS_IMETHOD GetCacheToken(nsISupports * *aCacheToken) { return _to GetCacheToken(aCacheToken); } \
  NS_IMETHOD SetCacheToken(nsISupports * aCacheToken) { return _to SetCacheToken(aCacheToken); } \
  NS_IMETHOD GetCacheKey(nsISupports **_retval) { return _to GetCacheKey(_retval); } \
  NS_IMETHOD SetCacheKey(nsISupports *cacheKey, PRBool fromCacheOnly) { return _to SetCacheKey(cacheKey, fromCacheOnly); } \
  NS_IMETHOD GetCacheAsFile(PRBool *aCacheAsFile) { return _to GetCacheAsFile(aCacheAsFile); } \
  NS_IMETHOD SetCacheAsFile(PRBool aCacheAsFile) { return _to SetCacheAsFile(aCacheAsFile); } \
  NS_IMETHOD GetCacheFile(nsIFile * *aCacheFile) { return _to GetCacheFile(aCacheFile); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSICACHINGCHANNEL(_to) \
  NS_IMETHOD GetCacheToken(nsISupports * *aCacheToken) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCacheToken(aCacheToken); } \
  NS_IMETHOD SetCacheToken(nsISupports * aCacheToken) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCacheToken(aCacheToken); } \
  NS_IMETHOD GetCacheKey(nsISupports **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCacheKey(_retval); } \
  NS_IMETHOD SetCacheKey(nsISupports *cacheKey, PRBool fromCacheOnly) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCacheKey(cacheKey, fromCacheOnly); } \
  NS_IMETHOD GetCacheAsFile(PRBool *aCacheAsFile) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCacheAsFile(aCacheAsFile); } \
  NS_IMETHOD SetCacheAsFile(PRBool aCacheAsFile) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCacheAsFile(aCacheAsFile); } \
  NS_IMETHOD GetCacheFile(nsIFile * *aCacheFile) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCacheFile(aCacheFile); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsCachingChannel : public nsICachingChannel
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSICACHINGCHANNEL

  nsCachingChannel();
  virtual ~nsCachingChannel();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsCachingChannel, nsICachingChannel)

nsCachingChannel::nsCachingChannel()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsCachingChannel::~nsCachingChannel()
{
  /* destructor code */
}

/* attribute nsISupports cacheToken; */
NS_IMETHODIMP nsCachingChannel::GetCacheToken(nsISupports * *aCacheToken)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsCachingChannel::SetCacheToken(nsISupports * aCacheToken)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsISupports getCacheKey (); */
NS_IMETHODIMP nsCachingChannel::GetCacheKey(nsISupports **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setCacheKey (in nsISupports cacheKey, in boolean fromCacheOnly); */
NS_IMETHODIMP nsCachingChannel::SetCacheKey(nsISupports *cacheKey, PRBool fromCacheOnly)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute boolean cacheAsFile; */
NS_IMETHODIMP nsCachingChannel::GetCacheAsFile(PRBool *aCacheAsFile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsCachingChannel::SetCacheAsFile(PRBool aCacheAsFile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute nsIFile cacheFile; */
NS_IMETHODIMP nsCachingChannel::GetCacheFile(nsIFile * *aCacheFile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif

/**
 * nsresult passed through onStopRequest if the document could not be fetched from the cache.
 */
#define NS_ERROR_DOCUMENT_NOT_CACHED NS_ERROR_GENERATE_FAILURE(NS_ERROR_MODULE_NETWORK, 70)

#endif /* __gen_nsICachingChannel_h__ */
