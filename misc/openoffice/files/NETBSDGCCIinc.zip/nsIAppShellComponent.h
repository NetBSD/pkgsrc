/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAppShellComponent.idl
 */

#ifndef __gen_nsIAppShellComponent_h__
#define __gen_nsIAppShellComponent_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIAppShellService;
class nsICmdLineService;

/* starting interface:    nsIAppShellComponent */
#define NS_IAPPSHELLCOMPONENT_IID_STR "a6cf90ed-15b3-11d2-932e-00805f8add32"

#define NS_IAPPSHELLCOMPONENT_IID \
  {0xa6cf90ed, 0x15b3, 0x11d2, \
    { 0x93, 0x2e, 0x00, 0x80, 0x5f, 0x8a, 0xdd, 0x32 }}

class NS_NO_VTABLE nsIAppShellComponent : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IAPPSHELLCOMPONENT_IID)

  /* [noscript] void Initialize (in nsIAppShellService anAppShell, in nsICmdLineService args); */
  NS_IMETHOD Initialize( nsIAppShellService  * anAppShell,  nsICmdLineService  * args) = 0;

  /* void Shutdown (); */
  NS_IMETHOD Shutdown(void) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIAPPSHELLCOMPONENT \
  NS_IMETHOD Initialize( nsIAppShellService  * anAppShell,  nsICmdLineService  * args); \
  NS_IMETHOD Shutdown(void); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIAPPSHELLCOMPONENT(_to) \
  NS_IMETHOD Initialize( nsIAppShellService  * anAppShell,  nsICmdLineService  * args) { return _to Initialize(anAppShell, args); } \
  NS_IMETHOD Shutdown(void) { return _to Shutdown(); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIAPPSHELLCOMPONENT(_to) \
  NS_IMETHOD Initialize( nsIAppShellService  * anAppShell,  nsICmdLineService  * args) { return !_to ? NS_ERROR_NULL_POINTER : _to->Initialize(anAppShell, args); } \
  NS_IMETHOD Shutdown(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->Shutdown(); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAppShellComponent : public nsIAppShellComponent
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIAPPSHELLCOMPONENT

  nsAppShellComponent();
  virtual ~nsAppShellComponent();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAppShellComponent, nsIAppShellComponent)

nsAppShellComponent::nsAppShellComponent()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAppShellComponent::~nsAppShellComponent()
{
  /* destructor code */
}

/* [noscript] void Initialize (in nsIAppShellService anAppShell, in nsICmdLineService args); */
NS_IMETHODIMP nsAppShellComponent::Initialize( nsIAppShellService  * anAppShell,  nsICmdLineService  * args)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void Shutdown (); */
NS_IMETHODIMP nsAppShellComponent::Shutdown()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif

#define NS_IAPPSHELLCOMPONENT_CONTRACTID    "@mozilla.org/appshell/component"
#define NS_IAPPSHELLCOMPONENT_CLASSNAME "Mozilla AppShell Component"
#define NS_IAPPSHELLCOMPONENT_KEY       "software/netscape/appshell/components"

#endif /* __gen_nsIAppShellComponent_h__ */
