/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM imgICache.idl
 */

#ifndef __gen_imgICache_h__
#define __gen_imgICache_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIURI; /* forward declaration */


/* starting interface:    imgICache */
#define IMGICACHE_IID_STR "075e424c-1dd2-11b2-97bc-e5beb94b874e"

#define IMGICACHE_IID \
  {0x075e424c, 0x1dd2, 0x11b2, \
    { 0x97, 0xbc, 0xe5, 0xbe, 0xb9, 0x4b, 0x87, 0x4e }}

/**
 * imgICache interface
 *
 * @author Stuart Parmenter <pavlov@netscape.com>
 * @version 0.0
 * @see imagelib2
 */
class NS_NO_VTABLE imgICache : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(IMGICACHE_IID)

  /**
   * Evict images from the cache.
   *
   * @param chrome If TRUE,  evict only chrome images.
   *               If FALSE, evict everything except chrome images.
   */
  /* void clearCache (in boolean chrome); */
  NS_IMETHOD ClearCache(PRBool chrome) = 0;

  /**
   * Evict images from the cache.
   *
   * @param uri The URI to remove.
   * @return NS_OK if \a uri was removed from the cache.
   *         NS_ERROR_NOT_AVAILABLE if \a uri was unable to be removed from the cache.
   */
  /* void removeEntry (in nsIURI uri); */
  NS_IMETHOD RemoveEntry(nsIURI *uri) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_IMGICACHE \
  NS_IMETHOD ClearCache(PRBool chrome); \
  NS_IMETHOD RemoveEntry(nsIURI *uri); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_IMGICACHE(_to) \
  NS_IMETHOD ClearCache(PRBool chrome) { return _to ClearCache(chrome); } \
  NS_IMETHOD RemoveEntry(nsIURI *uri) { return _to RemoveEntry(uri); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_IMGICACHE(_to) \
  NS_IMETHOD ClearCache(PRBool chrome) { return !_to ? NS_ERROR_NULL_POINTER : _to->ClearCache(chrome); } \
  NS_IMETHOD RemoveEntry(nsIURI *uri) { return !_to ? NS_ERROR_NULL_POINTER : _to->RemoveEntry(uri); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class _MYCLASS_ : public imgICache
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_IMGICACHE

  _MYCLASS_();
  virtual ~_MYCLASS_();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(_MYCLASS_, imgICache)

_MYCLASS_::_MYCLASS_()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

_MYCLASS_::~_MYCLASS_()
{
  /* destructor code */
}

/* void clearCache (in boolean chrome); */
NS_IMETHODIMP _MYCLASS_::ClearCache(PRBool chrome)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void removeEntry (in nsIURI uri); */
NS_IMETHODIMP _MYCLASS_::RemoveEntry(nsIURI *uri)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_imgICache_h__ */
