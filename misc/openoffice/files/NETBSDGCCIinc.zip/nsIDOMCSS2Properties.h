/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIDOMCSS2Properties.idl
 */

#ifndef __gen_nsIDOMCSS2Properties_h__
#define __gen_nsIDOMCSS2Properties_h__


#ifndef __gen_domstubs_h__
#include "domstubs.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIDOMCSS2Properties */
#define NS_IDOMCSS2PROPERTIES_IID_STR "a6cf90d1-15b3-11d2-932e-00805f8add32"

#define NS_IDOMCSS2PROPERTIES_IID \
  {0xa6cf90d1, 0x15b3, 0x11d2, \
    { 0x93, 0x2e, 0x00, 0x80, 0x5f, 0x8a, 0xdd, 0x32 }}

class NS_NO_VTABLE nsIDOMCSS2Properties : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IDOMCSS2PROPERTIES_IID)

  /* attribute DOMString azimuth; */
  NS_IMETHOD GetAzimuth(nsAWritableString & aAzimuth) = 0;
  NS_IMETHOD SetAzimuth(const nsAReadableString & aAzimuth) = 0;

  /* attribute DOMString background; */
  NS_IMETHOD GetBackground(nsAWritableString & aBackground) = 0;
  NS_IMETHOD SetBackground(const nsAReadableString & aBackground) = 0;

  /* attribute DOMString backgroundAttachment; */
  NS_IMETHOD GetBackgroundAttachment(nsAWritableString & aBackgroundAttachment) = 0;
  NS_IMETHOD SetBackgroundAttachment(const nsAReadableString & aBackgroundAttachment) = 0;

  /* attribute DOMString backgroundColor; */
  NS_IMETHOD GetBackgroundColor(nsAWritableString & aBackgroundColor) = 0;
  NS_IMETHOD SetBackgroundColor(const nsAReadableString & aBackgroundColor) = 0;

  /* attribute DOMString backgroundImage; */
  NS_IMETHOD GetBackgroundImage(nsAWritableString & aBackgroundImage) = 0;
  NS_IMETHOD SetBackgroundImage(const nsAReadableString & aBackgroundImage) = 0;

  /* attribute DOMString backgroundPosition; */
  NS_IMETHOD GetBackgroundPosition(nsAWritableString & aBackgroundPosition) = 0;
  NS_IMETHOD SetBackgroundPosition(const nsAReadableString & aBackgroundPosition) = 0;

  /* attribute DOMString backgroundRepeat; */
  NS_IMETHOD GetBackgroundRepeat(nsAWritableString & aBackgroundRepeat) = 0;
  NS_IMETHOD SetBackgroundRepeat(const nsAReadableString & aBackgroundRepeat) = 0;

  /* attribute DOMString border; */
  NS_IMETHOD GetBorder(nsAWritableString & aBorder) = 0;
  NS_IMETHOD SetBorder(const nsAReadableString & aBorder) = 0;

  /* attribute DOMString borderCollapse; */
  NS_IMETHOD GetBorderCollapse(nsAWritableString & aBorderCollapse) = 0;
  NS_IMETHOD SetBorderCollapse(const nsAReadableString & aBorderCollapse) = 0;

  /* attribute DOMString borderColor; */
  NS_IMETHOD GetBorderColor(nsAWritableString & aBorderColor) = 0;
  NS_IMETHOD SetBorderColor(const nsAReadableString & aBorderColor) = 0;

  /* attribute DOMString borderSpacing; */
  NS_IMETHOD GetBorderSpacing(nsAWritableString & aBorderSpacing) = 0;
  NS_IMETHOD SetBorderSpacing(const nsAReadableString & aBorderSpacing) = 0;

  /* attribute DOMString borderStyle; */
  NS_IMETHOD GetBorderStyle(nsAWritableString & aBorderStyle) = 0;
  NS_IMETHOD SetBorderStyle(const nsAReadableString & aBorderStyle) = 0;

  /* attribute DOMString borderTop; */
  NS_IMETHOD GetBorderTop(nsAWritableString & aBorderTop) = 0;
  NS_IMETHOD SetBorderTop(const nsAReadableString & aBorderTop) = 0;

  /* attribute DOMString borderRight; */
  NS_IMETHOD GetBorderRight(nsAWritableString & aBorderRight) = 0;
  NS_IMETHOD SetBorderRight(const nsAReadableString & aBorderRight) = 0;

  /* attribute DOMString borderBottom; */
  NS_IMETHOD GetBorderBottom(nsAWritableString & aBorderBottom) = 0;
  NS_IMETHOD SetBorderBottom(const nsAReadableString & aBorderBottom) = 0;

  /* attribute DOMString borderLeft; */
  NS_IMETHOD GetBorderLeft(nsAWritableString & aBorderLeft) = 0;
  NS_IMETHOD SetBorderLeft(const nsAReadableString & aBorderLeft) = 0;

  /* attribute DOMString borderTopColor; */
  NS_IMETHOD GetBorderTopColor(nsAWritableString & aBorderTopColor) = 0;
  NS_IMETHOD SetBorderTopColor(const nsAReadableString & aBorderTopColor) = 0;

  /* attribute DOMString borderRightColor; */
  NS_IMETHOD GetBorderRightColor(nsAWritableString & aBorderRightColor) = 0;
  NS_IMETHOD SetBorderRightColor(const nsAReadableString & aBorderRightColor) = 0;

  /* attribute DOMString borderBottomColor; */
  NS_IMETHOD GetBorderBottomColor(nsAWritableString & aBorderBottomColor) = 0;
  NS_IMETHOD SetBorderBottomColor(const nsAReadableString & aBorderBottomColor) = 0;

  /* attribute DOMString borderLeftColor; */
  NS_IMETHOD GetBorderLeftColor(nsAWritableString & aBorderLeftColor) = 0;
  NS_IMETHOD SetBorderLeftColor(const nsAReadableString & aBorderLeftColor) = 0;

  /* attribute DOMString borderTopStyle; */
  NS_IMETHOD GetBorderTopStyle(nsAWritableString & aBorderTopStyle) = 0;
  NS_IMETHOD SetBorderTopStyle(const nsAReadableString & aBorderTopStyle) = 0;

  /* attribute DOMString borderRightStyle; */
  NS_IMETHOD GetBorderRightStyle(nsAWritableString & aBorderRightStyle) = 0;
  NS_IMETHOD SetBorderRightStyle(const nsAReadableString & aBorderRightStyle) = 0;

  /* attribute DOMString borderBottomStyle; */
  NS_IMETHOD GetBorderBottomStyle(nsAWritableString & aBorderBottomStyle) = 0;
  NS_IMETHOD SetBorderBottomStyle(const nsAReadableString & aBorderBottomStyle) = 0;

  /* attribute DOMString borderLeftStyle; */
  NS_IMETHOD GetBorderLeftStyle(nsAWritableString & aBorderLeftStyle) = 0;
  NS_IMETHOD SetBorderLeftStyle(const nsAReadableString & aBorderLeftStyle) = 0;

  /* attribute DOMString borderTopWidth; */
  NS_IMETHOD GetBorderTopWidth(nsAWritableString & aBorderTopWidth) = 0;
  NS_IMETHOD SetBorderTopWidth(const nsAReadableString & aBorderTopWidth) = 0;

  /* attribute DOMString borderRightWidth; */
  NS_IMETHOD GetBorderRightWidth(nsAWritableString & aBorderRightWidth) = 0;
  NS_IMETHOD SetBorderRightWidth(const nsAReadableString & aBorderRightWidth) = 0;

  /* attribute DOMString borderBottomWidth; */
  NS_IMETHOD GetBorderBottomWidth(nsAWritableString & aBorderBottomWidth) = 0;
  NS_IMETHOD SetBorderBottomWidth(const nsAReadableString & aBorderBottomWidth) = 0;

  /* attribute DOMString borderLeftWidth; */
  NS_IMETHOD GetBorderLeftWidth(nsAWritableString & aBorderLeftWidth) = 0;
  NS_IMETHOD SetBorderLeftWidth(const nsAReadableString & aBorderLeftWidth) = 0;

  /* attribute DOMString borderWidth; */
  NS_IMETHOD GetBorderWidth(nsAWritableString & aBorderWidth) = 0;
  NS_IMETHOD SetBorderWidth(const nsAReadableString & aBorderWidth) = 0;

  /* attribute DOMString bottom; */
  NS_IMETHOD GetBottom(nsAWritableString & aBottom) = 0;
  NS_IMETHOD SetBottom(const nsAReadableString & aBottom) = 0;

  /* attribute DOMString captionSide; */
  NS_IMETHOD GetCaptionSide(nsAWritableString & aCaptionSide) = 0;
  NS_IMETHOD SetCaptionSide(const nsAReadableString & aCaptionSide) = 0;

  /* attribute DOMString clear; */
  NS_IMETHOD GetClear(nsAWritableString & aClear) = 0;
  NS_IMETHOD SetClear(const nsAReadableString & aClear) = 0;

  /* attribute DOMString clip; */
  NS_IMETHOD GetClip(nsAWritableString & aClip) = 0;
  NS_IMETHOD SetClip(const nsAReadableString & aClip) = 0;

  /* attribute DOMString color; */
  NS_IMETHOD GetColor(nsAWritableString & aColor) = 0;
  NS_IMETHOD SetColor(const nsAReadableString & aColor) = 0;

  /* attribute DOMString content; */
  NS_IMETHOD GetContent(nsAWritableString & aContent) = 0;
  NS_IMETHOD SetContent(const nsAReadableString & aContent) = 0;

  /* attribute DOMString counterIncrement; */
  NS_IMETHOD GetCounterIncrement(nsAWritableString & aCounterIncrement) = 0;
  NS_IMETHOD SetCounterIncrement(const nsAReadableString & aCounterIncrement) = 0;

  /* attribute DOMString counterReset; */
  NS_IMETHOD GetCounterReset(nsAWritableString & aCounterReset) = 0;
  NS_IMETHOD SetCounterReset(const nsAReadableString & aCounterReset) = 0;

  /* attribute DOMString cue; */
  NS_IMETHOD GetCue(nsAWritableString & aCue) = 0;
  NS_IMETHOD SetCue(const nsAReadableString & aCue) = 0;

  /* attribute DOMString cueAfter; */
  NS_IMETHOD GetCueAfter(nsAWritableString & aCueAfter) = 0;
  NS_IMETHOD SetCueAfter(const nsAReadableString & aCueAfter) = 0;

  /* attribute DOMString cueBefore; */
  NS_IMETHOD GetCueBefore(nsAWritableString & aCueBefore) = 0;
  NS_IMETHOD SetCueBefore(const nsAReadableString & aCueBefore) = 0;

  /* attribute DOMString cursor; */
  NS_IMETHOD GetCursor(nsAWritableString & aCursor) = 0;
  NS_IMETHOD SetCursor(const nsAReadableString & aCursor) = 0;

  /* attribute DOMString direction; */
  NS_IMETHOD GetDirection(nsAWritableString & aDirection) = 0;
  NS_IMETHOD SetDirection(const nsAReadableString & aDirection) = 0;

  /* attribute DOMString display; */
  NS_IMETHOD GetDisplay(nsAWritableString & aDisplay) = 0;
  NS_IMETHOD SetDisplay(const nsAReadableString & aDisplay) = 0;

  /* attribute DOMString elevation; */
  NS_IMETHOD GetElevation(nsAWritableString & aElevation) = 0;
  NS_IMETHOD SetElevation(const nsAReadableString & aElevation) = 0;

  /* attribute DOMString emptyCells; */
  NS_IMETHOD GetEmptyCells(nsAWritableString & aEmptyCells) = 0;
  NS_IMETHOD SetEmptyCells(const nsAReadableString & aEmptyCells) = 0;

  /* attribute DOMString cssFloat; */
  NS_IMETHOD GetCssFloat(nsAWritableString & aCssFloat) = 0;
  NS_IMETHOD SetCssFloat(const nsAReadableString & aCssFloat) = 0;

  /* attribute DOMString font; */
  NS_IMETHOD GetFont(nsAWritableString & aFont) = 0;
  NS_IMETHOD SetFont(const nsAReadableString & aFont) = 0;

  /* attribute DOMString fontFamily; */
  NS_IMETHOD GetFontFamily(nsAWritableString & aFontFamily) = 0;
  NS_IMETHOD SetFontFamily(const nsAReadableString & aFontFamily) = 0;

  /* attribute DOMString fontSize; */
  NS_IMETHOD GetFontSize(nsAWritableString & aFontSize) = 0;
  NS_IMETHOD SetFontSize(const nsAReadableString & aFontSize) = 0;

  /* attribute DOMString fontSizeAdjust; */
  NS_IMETHOD GetFontSizeAdjust(nsAWritableString & aFontSizeAdjust) = 0;
  NS_IMETHOD SetFontSizeAdjust(const nsAReadableString & aFontSizeAdjust) = 0;

  /* attribute DOMString fontStretch; */
  NS_IMETHOD GetFontStretch(nsAWritableString & aFontStretch) = 0;
  NS_IMETHOD SetFontStretch(const nsAReadableString & aFontStretch) = 0;

  /* attribute DOMString fontStyle; */
  NS_IMETHOD GetFontStyle(nsAWritableString & aFontStyle) = 0;
  NS_IMETHOD SetFontStyle(const nsAReadableString & aFontStyle) = 0;

  /* attribute DOMString fontVariant; */
  NS_IMETHOD GetFontVariant(nsAWritableString & aFontVariant) = 0;
  NS_IMETHOD SetFontVariant(const nsAReadableString & aFontVariant) = 0;

  /* attribute DOMString fontWeight; */
  NS_IMETHOD GetFontWeight(nsAWritableString & aFontWeight) = 0;
  NS_IMETHOD SetFontWeight(const nsAReadableString & aFontWeight) = 0;

  /* attribute DOMString height; */
  NS_IMETHOD GetHeight(nsAWritableString & aHeight) = 0;
  NS_IMETHOD SetHeight(const nsAReadableString & aHeight) = 0;

  /* attribute DOMString left; */
  NS_IMETHOD GetLeft(nsAWritableString & aLeft) = 0;
  NS_IMETHOD SetLeft(const nsAReadableString & aLeft) = 0;

  /* attribute DOMString letterSpacing; */
  NS_IMETHOD GetLetterSpacing(nsAWritableString & aLetterSpacing) = 0;
  NS_IMETHOD SetLetterSpacing(const nsAReadableString & aLetterSpacing) = 0;

  /* attribute DOMString lineHeight; */
  NS_IMETHOD GetLineHeight(nsAWritableString & aLineHeight) = 0;
  NS_IMETHOD SetLineHeight(const nsAReadableString & aLineHeight) = 0;

  /* attribute DOMString listStyle; */
  NS_IMETHOD GetListStyle(nsAWritableString & aListStyle) = 0;
  NS_IMETHOD SetListStyle(const nsAReadableString & aListStyle) = 0;

  /* attribute DOMString listStyleImage; */
  NS_IMETHOD GetListStyleImage(nsAWritableString & aListStyleImage) = 0;
  NS_IMETHOD SetListStyleImage(const nsAReadableString & aListStyleImage) = 0;

  /* attribute DOMString listStylePosition; */
  NS_IMETHOD GetListStylePosition(nsAWritableString & aListStylePosition) = 0;
  NS_IMETHOD SetListStylePosition(const nsAReadableString & aListStylePosition) = 0;

  /* attribute DOMString listStyleType; */
  NS_IMETHOD GetListStyleType(nsAWritableString & aListStyleType) = 0;
  NS_IMETHOD SetListStyleType(const nsAReadableString & aListStyleType) = 0;

  /* attribute DOMString margin; */
  NS_IMETHOD GetMargin(nsAWritableString & aMargin) = 0;
  NS_IMETHOD SetMargin(const nsAReadableString & aMargin) = 0;

  /* attribute DOMString marginTop; */
  NS_IMETHOD GetMarginTop(nsAWritableString & aMarginTop) = 0;
  NS_IMETHOD SetMarginTop(const nsAReadableString & aMarginTop) = 0;

  /* attribute DOMString marginRight; */
  NS_IMETHOD GetMarginRight(nsAWritableString & aMarginRight) = 0;
  NS_IMETHOD SetMarginRight(const nsAReadableString & aMarginRight) = 0;

  /* attribute DOMString marginBottom; */
  NS_IMETHOD GetMarginBottom(nsAWritableString & aMarginBottom) = 0;
  NS_IMETHOD SetMarginBottom(const nsAReadableString & aMarginBottom) = 0;

  /* attribute DOMString marginLeft; */
  NS_IMETHOD GetMarginLeft(nsAWritableString & aMarginLeft) = 0;
  NS_IMETHOD SetMarginLeft(const nsAReadableString & aMarginLeft) = 0;

  /* attribute DOMString markerOffset; */
  NS_IMETHOD GetMarkerOffset(nsAWritableString & aMarkerOffset) = 0;
  NS_IMETHOD SetMarkerOffset(const nsAReadableString & aMarkerOffset) = 0;

  /* attribute DOMString marks; */
  NS_IMETHOD GetMarks(nsAWritableString & aMarks) = 0;
  NS_IMETHOD SetMarks(const nsAReadableString & aMarks) = 0;

  /* attribute DOMString maxHeight; */
  NS_IMETHOD GetMaxHeight(nsAWritableString & aMaxHeight) = 0;
  NS_IMETHOD SetMaxHeight(const nsAReadableString & aMaxHeight) = 0;

  /* attribute DOMString maxWidth; */
  NS_IMETHOD GetMaxWidth(nsAWritableString & aMaxWidth) = 0;
  NS_IMETHOD SetMaxWidth(const nsAReadableString & aMaxWidth) = 0;

  /* attribute DOMString minHeight; */
  NS_IMETHOD GetMinHeight(nsAWritableString & aMinHeight) = 0;
  NS_IMETHOD SetMinHeight(const nsAReadableString & aMinHeight) = 0;

  /* attribute DOMString minWidth; */
  NS_IMETHOD GetMinWidth(nsAWritableString & aMinWidth) = 0;
  NS_IMETHOD SetMinWidth(const nsAReadableString & aMinWidth) = 0;

  /* attribute DOMString orphans; */
  NS_IMETHOD GetOrphans(nsAWritableString & aOrphans) = 0;
  NS_IMETHOD SetOrphans(const nsAReadableString & aOrphans) = 0;

  /* attribute DOMString outline; */
  NS_IMETHOD GetOutline(nsAWritableString & aOutline) = 0;
  NS_IMETHOD SetOutline(const nsAReadableString & aOutline) = 0;

  /* attribute DOMString outlineColor; */
  NS_IMETHOD GetOutlineColor(nsAWritableString & aOutlineColor) = 0;
  NS_IMETHOD SetOutlineColor(const nsAReadableString & aOutlineColor) = 0;

  /* attribute DOMString outlineStyle; */
  NS_IMETHOD GetOutlineStyle(nsAWritableString & aOutlineStyle) = 0;
  NS_IMETHOD SetOutlineStyle(const nsAReadableString & aOutlineStyle) = 0;

  /* attribute DOMString outlineWidth; */
  NS_IMETHOD GetOutlineWidth(nsAWritableString & aOutlineWidth) = 0;
  NS_IMETHOD SetOutlineWidth(const nsAReadableString & aOutlineWidth) = 0;

  /* attribute DOMString overflow; */
  NS_IMETHOD GetOverflow(nsAWritableString & aOverflow) = 0;
  NS_IMETHOD SetOverflow(const nsAReadableString & aOverflow) = 0;

  /* attribute DOMString padding; */
  NS_IMETHOD GetPadding(nsAWritableString & aPadding) = 0;
  NS_IMETHOD SetPadding(const nsAReadableString & aPadding) = 0;

  /* attribute DOMString paddingTop; */
  NS_IMETHOD GetPaddingTop(nsAWritableString & aPaddingTop) = 0;
  NS_IMETHOD SetPaddingTop(const nsAReadableString & aPaddingTop) = 0;

  /* attribute DOMString paddingRight; */
  NS_IMETHOD GetPaddingRight(nsAWritableString & aPaddingRight) = 0;
  NS_IMETHOD SetPaddingRight(const nsAReadableString & aPaddingRight) = 0;

  /* attribute DOMString paddingBottom; */
  NS_IMETHOD GetPaddingBottom(nsAWritableString & aPaddingBottom) = 0;
  NS_IMETHOD SetPaddingBottom(const nsAReadableString & aPaddingBottom) = 0;

  /* attribute DOMString paddingLeft; */
  NS_IMETHOD GetPaddingLeft(nsAWritableString & aPaddingLeft) = 0;
  NS_IMETHOD SetPaddingLeft(const nsAReadableString & aPaddingLeft) = 0;

  /* attribute DOMString page; */
  NS_IMETHOD GetPage(nsAWritableString & aPage) = 0;
  NS_IMETHOD SetPage(const nsAReadableString & aPage) = 0;

  /* attribute DOMString pageBreakAfter; */
  NS_IMETHOD GetPageBreakAfter(nsAWritableString & aPageBreakAfter) = 0;
  NS_IMETHOD SetPageBreakAfter(const nsAReadableString & aPageBreakAfter) = 0;

  /* attribute DOMString pageBreakBefore; */
  NS_IMETHOD GetPageBreakBefore(nsAWritableString & aPageBreakBefore) = 0;
  NS_IMETHOD SetPageBreakBefore(const nsAReadableString & aPageBreakBefore) = 0;

  /* attribute DOMString pageBreakInside; */
  NS_IMETHOD GetPageBreakInside(nsAWritableString & aPageBreakInside) = 0;
  NS_IMETHOD SetPageBreakInside(const nsAReadableString & aPageBreakInside) = 0;

  /* attribute DOMString pause; */
  NS_IMETHOD GetPause(nsAWritableString & aPause) = 0;
  NS_IMETHOD SetPause(const nsAReadableString & aPause) = 0;

  /* attribute DOMString pauseAfter; */
  NS_IMETHOD GetPauseAfter(nsAWritableString & aPauseAfter) = 0;
  NS_IMETHOD SetPauseAfter(const nsAReadableString & aPauseAfter) = 0;

  /* attribute DOMString pauseBefore; */
  NS_IMETHOD GetPauseBefore(nsAWritableString & aPauseBefore) = 0;
  NS_IMETHOD SetPauseBefore(const nsAReadableString & aPauseBefore) = 0;

  /* attribute DOMString pitch; */
  NS_IMETHOD GetPitch(nsAWritableString & aPitch) = 0;
  NS_IMETHOD SetPitch(const nsAReadableString & aPitch) = 0;

  /* attribute DOMString pitchRange; */
  NS_IMETHOD GetPitchRange(nsAWritableString & aPitchRange) = 0;
  NS_IMETHOD SetPitchRange(const nsAReadableString & aPitchRange) = 0;

  /* attribute DOMString playDuring; */
  NS_IMETHOD GetPlayDuring(nsAWritableString & aPlayDuring) = 0;
  NS_IMETHOD SetPlayDuring(const nsAReadableString & aPlayDuring) = 0;

  /* attribute DOMString position; */
  NS_IMETHOD GetPosition(nsAWritableString & aPosition) = 0;
  NS_IMETHOD SetPosition(const nsAReadableString & aPosition) = 0;

  /* attribute DOMString quotes; */
  NS_IMETHOD GetQuotes(nsAWritableString & aQuotes) = 0;
  NS_IMETHOD SetQuotes(const nsAReadableString & aQuotes) = 0;

  /* attribute DOMString richness; */
  NS_IMETHOD GetRichness(nsAWritableString & aRichness) = 0;
  NS_IMETHOD SetRichness(const nsAReadableString & aRichness) = 0;

  /* attribute DOMString right; */
  NS_IMETHOD GetRight(nsAWritableString & aRight) = 0;
  NS_IMETHOD SetRight(const nsAReadableString & aRight) = 0;

  /* attribute DOMString size; */
  NS_IMETHOD GetSize(nsAWritableString & aSize) = 0;
  NS_IMETHOD SetSize(const nsAReadableString & aSize) = 0;

  /* attribute DOMString speak; */
  NS_IMETHOD GetSpeak(nsAWritableString & aSpeak) = 0;
  NS_IMETHOD SetSpeak(const nsAReadableString & aSpeak) = 0;

  /* attribute DOMString speakHeader; */
  NS_IMETHOD GetSpeakHeader(nsAWritableString & aSpeakHeader) = 0;
  NS_IMETHOD SetSpeakHeader(const nsAReadableString & aSpeakHeader) = 0;

  /* attribute DOMString speakNumeral; */
  NS_IMETHOD GetSpeakNumeral(nsAWritableString & aSpeakNumeral) = 0;
  NS_IMETHOD SetSpeakNumeral(const nsAReadableString & aSpeakNumeral) = 0;

  /* attribute DOMString speakPunctuation; */
  NS_IMETHOD GetSpeakPunctuation(nsAWritableString & aSpeakPunctuation) = 0;
  NS_IMETHOD SetSpeakPunctuation(const nsAReadableString & aSpeakPunctuation) = 0;

  /* attribute DOMString speechRate; */
  NS_IMETHOD GetSpeechRate(nsAWritableString & aSpeechRate) = 0;
  NS_IMETHOD SetSpeechRate(const nsAReadableString & aSpeechRate) = 0;

  /* attribute DOMString stress; */
  NS_IMETHOD GetStress(nsAWritableString & aStress) = 0;
  NS_IMETHOD SetStress(const nsAReadableString & aStress) = 0;

  /* attribute DOMString tableLayout; */
  NS_IMETHOD GetTableLayout(nsAWritableString & aTableLayout) = 0;
  NS_IMETHOD SetTableLayout(const nsAReadableString & aTableLayout) = 0;

  /* attribute DOMString textAlign; */
  NS_IMETHOD GetTextAlign(nsAWritableString & aTextAlign) = 0;
  NS_IMETHOD SetTextAlign(const nsAReadableString & aTextAlign) = 0;

  /* attribute DOMString textDecoration; */
  NS_IMETHOD GetTextDecoration(nsAWritableString & aTextDecoration) = 0;
  NS_IMETHOD SetTextDecoration(const nsAReadableString & aTextDecoration) = 0;

  /* attribute DOMString textIndent; */
  NS_IMETHOD GetTextIndent(nsAWritableString & aTextIndent) = 0;
  NS_IMETHOD SetTextIndent(const nsAReadableString & aTextIndent) = 0;

  /* attribute DOMString textShadow; */
  NS_IMETHOD GetTextShadow(nsAWritableString & aTextShadow) = 0;
  NS_IMETHOD SetTextShadow(const nsAReadableString & aTextShadow) = 0;

  /* attribute DOMString textTransform; */
  NS_IMETHOD GetTextTransform(nsAWritableString & aTextTransform) = 0;
  NS_IMETHOD SetTextTransform(const nsAReadableString & aTextTransform) = 0;

  /* attribute DOMString top; */
  NS_IMETHOD GetTop(nsAWritableString & aTop) = 0;
  NS_IMETHOD SetTop(const nsAReadableString & aTop) = 0;

  /* attribute DOMString unicodeBidi; */
  NS_IMETHOD GetUnicodeBidi(nsAWritableString & aUnicodeBidi) = 0;
  NS_IMETHOD SetUnicodeBidi(const nsAReadableString & aUnicodeBidi) = 0;

  /* attribute DOMString verticalAlign; */
  NS_IMETHOD GetVerticalAlign(nsAWritableString & aVerticalAlign) = 0;
  NS_IMETHOD SetVerticalAlign(const nsAReadableString & aVerticalAlign) = 0;

  /* attribute DOMString visibility; */
  NS_IMETHOD GetVisibility(nsAWritableString & aVisibility) = 0;
  NS_IMETHOD SetVisibility(const nsAReadableString & aVisibility) = 0;

  /* attribute DOMString voiceFamily; */
  NS_IMETHOD GetVoiceFamily(nsAWritableString & aVoiceFamily) = 0;
  NS_IMETHOD SetVoiceFamily(const nsAReadableString & aVoiceFamily) = 0;

  /* attribute DOMString volume; */
  NS_IMETHOD GetVolume(nsAWritableString & aVolume) = 0;
  NS_IMETHOD SetVolume(const nsAReadableString & aVolume) = 0;

  /* attribute DOMString whiteSpace; */
  NS_IMETHOD GetWhiteSpace(nsAWritableString & aWhiteSpace) = 0;
  NS_IMETHOD SetWhiteSpace(const nsAReadableString & aWhiteSpace) = 0;

  /* attribute DOMString widows; */
  NS_IMETHOD GetWidows(nsAWritableString & aWidows) = 0;
  NS_IMETHOD SetWidows(const nsAReadableString & aWidows) = 0;

  /* attribute DOMString width; */
  NS_IMETHOD GetWidth(nsAWritableString & aWidth) = 0;
  NS_IMETHOD SetWidth(const nsAReadableString & aWidth) = 0;

  /* attribute DOMString wordSpacing; */
  NS_IMETHOD GetWordSpacing(nsAWritableString & aWordSpacing) = 0;
  NS_IMETHOD SetWordSpacing(const nsAReadableString & aWordSpacing) = 0;

  /* attribute DOMString zIndex; */
  NS_IMETHOD GetZIndex(nsAWritableString & aZIndex) = 0;
  NS_IMETHOD SetZIndex(const nsAReadableString & aZIndex) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIDOMCSS2PROPERTIES \
  NS_IMETHOD GetAzimuth(nsAWritableString & aAzimuth); \
  NS_IMETHOD SetAzimuth(const nsAReadableString & aAzimuth); \
  NS_IMETHOD GetBackground(nsAWritableString & aBackground); \
  NS_IMETHOD SetBackground(const nsAReadableString & aBackground); \
  NS_IMETHOD GetBackgroundAttachment(nsAWritableString & aBackgroundAttachment); \
  NS_IMETHOD SetBackgroundAttachment(const nsAReadableString & aBackgroundAttachment); \
  NS_IMETHOD GetBackgroundColor(nsAWritableString & aBackgroundColor); \
  NS_IMETHOD SetBackgroundColor(const nsAReadableString & aBackgroundColor); \
  NS_IMETHOD GetBackgroundImage(nsAWritableString & aBackgroundImage); \
  NS_IMETHOD SetBackgroundImage(const nsAReadableString & aBackgroundImage); \
  NS_IMETHOD GetBackgroundPosition(nsAWritableString & aBackgroundPosition); \
  NS_IMETHOD SetBackgroundPosition(const nsAReadableString & aBackgroundPosition); \
  NS_IMETHOD GetBackgroundRepeat(nsAWritableString & aBackgroundRepeat); \
  NS_IMETHOD SetBackgroundRepeat(const nsAReadableString & aBackgroundRepeat); \
  NS_IMETHOD GetBorder(nsAWritableString & aBorder); \
  NS_IMETHOD SetBorder(const nsAReadableString & aBorder); \
  NS_IMETHOD GetBorderCollapse(nsAWritableString & aBorderCollapse); \
  NS_IMETHOD SetBorderCollapse(const nsAReadableString & aBorderCollapse); \
  NS_IMETHOD GetBorderColor(nsAWritableString & aBorderColor); \
  NS_IMETHOD SetBorderColor(const nsAReadableString & aBorderColor); \
  NS_IMETHOD GetBorderSpacing(nsAWritableString & aBorderSpacing); \
  NS_IMETHOD SetBorderSpacing(const nsAReadableString & aBorderSpacing); \
  NS_IMETHOD GetBorderStyle(nsAWritableString & aBorderStyle); \
  NS_IMETHOD SetBorderStyle(const nsAReadableString & aBorderStyle); \
  NS_IMETHOD GetBorderTop(nsAWritableString & aBorderTop); \
  NS_IMETHOD SetBorderTop(const nsAReadableString & aBorderTop); \
  NS_IMETHOD GetBorderRight(nsAWritableString & aBorderRight); \
  NS_IMETHOD SetBorderRight(const nsAReadableString & aBorderRight); \
  NS_IMETHOD GetBorderBottom(nsAWritableString & aBorderBottom); \
  NS_IMETHOD SetBorderBottom(const nsAReadableString & aBorderBottom); \
  NS_IMETHOD GetBorderLeft(nsAWritableString & aBorderLeft); \
  NS_IMETHOD SetBorderLeft(const nsAReadableString & aBorderLeft); \
  NS_IMETHOD GetBorderTopColor(nsAWritableString & aBorderTopColor); \
  NS_IMETHOD SetBorderTopColor(const nsAReadableString & aBorderTopColor); \
  NS_IMETHOD GetBorderRightColor(nsAWritableString & aBorderRightColor); \
  NS_IMETHOD SetBorderRightColor(const nsAReadableString & aBorderRightColor); \
  NS_IMETHOD GetBorderBottomColor(nsAWritableString & aBorderBottomColor); \
  NS_IMETHOD SetBorderBottomColor(const nsAReadableString & aBorderBottomColor); \
  NS_IMETHOD GetBorderLeftColor(nsAWritableString & aBorderLeftColor); \
  NS_IMETHOD SetBorderLeftColor(const nsAReadableString & aBorderLeftColor); \
  NS_IMETHOD GetBorderTopStyle(nsAWritableString & aBorderTopStyle); \
  NS_IMETHOD SetBorderTopStyle(const nsAReadableString & aBorderTopStyle); \
  NS_IMETHOD GetBorderRightStyle(nsAWritableString & aBorderRightStyle); \
  NS_IMETHOD SetBorderRightStyle(const nsAReadableString & aBorderRightStyle); \
  NS_IMETHOD GetBorderBottomStyle(nsAWritableString & aBorderBottomStyle); \
  NS_IMETHOD SetBorderBottomStyle(const nsAReadableString & aBorderBottomStyle); \
  NS_IMETHOD GetBorderLeftStyle(nsAWritableString & aBorderLeftStyle); \
  NS_IMETHOD SetBorderLeftStyle(const nsAReadableString & aBorderLeftStyle); \
  NS_IMETHOD GetBorderTopWidth(nsAWritableString & aBorderTopWidth); \
  NS_IMETHOD SetBorderTopWidth(const nsAReadableString & aBorderTopWidth); \
  NS_IMETHOD GetBorderRightWidth(nsAWritableString & aBorderRightWidth); \
  NS_IMETHOD SetBorderRightWidth(const nsAReadableString & aBorderRightWidth); \
  NS_IMETHOD GetBorderBottomWidth(nsAWritableString & aBorderBottomWidth); \
  NS_IMETHOD SetBorderBottomWidth(const nsAReadableString & aBorderBottomWidth); \
  NS_IMETHOD GetBorderLeftWidth(nsAWritableString & aBorderLeftWidth); \
  NS_IMETHOD SetBorderLeftWidth(const nsAReadableString & aBorderLeftWidth); \
  NS_IMETHOD GetBorderWidth(nsAWritableString & aBorderWidth); \
  NS_IMETHOD SetBorderWidth(const nsAReadableString & aBorderWidth); \
  NS_IMETHOD GetBottom(nsAWritableString & aBottom); \
  NS_IMETHOD SetBottom(const nsAReadableString & aBottom); \
  NS_IMETHOD GetCaptionSide(nsAWritableString & aCaptionSide); \
  NS_IMETHOD SetCaptionSide(const nsAReadableString & aCaptionSide); \
  NS_IMETHOD GetClear(nsAWritableString & aClear); \
  NS_IMETHOD SetClear(const nsAReadableString & aClear); \
  NS_IMETHOD GetClip(nsAWritableString & aClip); \
  NS_IMETHOD SetClip(const nsAReadableString & aClip); \
  NS_IMETHOD GetColor(nsAWritableString & aColor); \
  NS_IMETHOD SetColor(const nsAReadableString & aColor); \
  NS_IMETHOD GetContent(nsAWritableString & aContent); \
  NS_IMETHOD SetContent(const nsAReadableString & aContent); \
  NS_IMETHOD GetCounterIncrement(nsAWritableString & aCounterIncrement); \
  NS_IMETHOD SetCounterIncrement(const nsAReadableString & aCounterIncrement); \
  NS_IMETHOD GetCounterReset(nsAWritableString & aCounterReset); \
  NS_IMETHOD SetCounterReset(const nsAReadableString & aCounterReset); \
  NS_IMETHOD GetCue(nsAWritableString & aCue); \
  NS_IMETHOD SetCue(const nsAReadableString & aCue); \
  NS_IMETHOD GetCueAfter(nsAWritableString & aCueAfter); \
  NS_IMETHOD SetCueAfter(const nsAReadableString & aCueAfter); \
  NS_IMETHOD GetCueBefore(nsAWritableString & aCueBefore); \
  NS_IMETHOD SetCueBefore(const nsAReadableString & aCueBefore); \
  NS_IMETHOD GetCursor(nsAWritableString & aCursor); \
  NS_IMETHOD SetCursor(const nsAReadableString & aCursor); \
  NS_IMETHOD GetDirection(nsAWritableString & aDirection); \
  NS_IMETHOD SetDirection(const nsAReadableString & aDirection); \
  NS_IMETHOD GetDisplay(nsAWritableString & aDisplay); \
  NS_IMETHOD SetDisplay(const nsAReadableString & aDisplay); \
  NS_IMETHOD GetElevation(nsAWritableString & aElevation); \
  NS_IMETHOD SetElevation(const nsAReadableString & aElevation); \
  NS_IMETHOD GetEmptyCells(nsAWritableString & aEmptyCells); \
  NS_IMETHOD SetEmptyCells(const nsAReadableString & aEmptyCells); \
  NS_IMETHOD GetCssFloat(nsAWritableString & aCssFloat); \
  NS_IMETHOD SetCssFloat(const nsAReadableString & aCssFloat); \
  NS_IMETHOD GetFont(nsAWritableString & aFont); \
  NS_IMETHOD SetFont(const nsAReadableString & aFont); \
  NS_IMETHOD GetFontFamily(nsAWritableString & aFontFamily); \
  NS_IMETHOD SetFontFamily(const nsAReadableString & aFontFamily); \
  NS_IMETHOD GetFontSize(nsAWritableString & aFontSize); \
  NS_IMETHOD SetFontSize(const nsAReadableString & aFontSize); \
  NS_IMETHOD GetFontSizeAdjust(nsAWritableString & aFontSizeAdjust); \
  NS_IMETHOD SetFontSizeAdjust(const nsAReadableString & aFontSizeAdjust); \
  NS_IMETHOD GetFontStretch(nsAWritableString & aFontStretch); \
  NS_IMETHOD SetFontStretch(const nsAReadableString & aFontStretch); \
  NS_IMETHOD GetFontStyle(nsAWritableString & aFontStyle); \
  NS_IMETHOD SetFontStyle(const nsAReadableString & aFontStyle); \
  NS_IMETHOD GetFontVariant(nsAWritableString & aFontVariant); \
  NS_IMETHOD SetFontVariant(const nsAReadableString & aFontVariant); \
  NS_IMETHOD GetFontWeight(nsAWritableString & aFontWeight); \
  NS_IMETHOD SetFontWeight(const nsAReadableString & aFontWeight); \
  NS_IMETHOD GetHeight(nsAWritableString & aHeight); \
  NS_IMETHOD SetHeight(const nsAReadableString & aHeight); \
  NS_IMETHOD GetLeft(nsAWritableString & aLeft); \
  NS_IMETHOD SetLeft(const nsAReadableString & aLeft); \
  NS_IMETHOD GetLetterSpacing(nsAWritableString & aLetterSpacing); \
  NS_IMETHOD SetLetterSpacing(const nsAReadableString & aLetterSpacing); \
  NS_IMETHOD GetLineHeight(nsAWritableString & aLineHeight); \
  NS_IMETHOD SetLineHeight(const nsAReadableString & aLineHeight); \
  NS_IMETHOD GetListStyle(nsAWritableString & aListStyle); \
  NS_IMETHOD SetListStyle(const nsAReadableString & aListStyle); \
  NS_IMETHOD GetListStyleImage(nsAWritableString & aListStyleImage); \
  NS_IMETHOD SetListStyleImage(const nsAReadableString & aListStyleImage); \
  NS_IMETHOD GetListStylePosition(nsAWritableString & aListStylePosition); \
  NS_IMETHOD SetListStylePosition(const nsAReadableString & aListStylePosition); \
  NS_IMETHOD GetListStyleType(nsAWritableString & aListStyleType); \
  NS_IMETHOD SetListStyleType(const nsAReadableString & aListStyleType); \
  NS_IMETHOD GetMargin(nsAWritableString & aMargin); \
  NS_IMETHOD SetMargin(const nsAReadableString & aMargin); \
  NS_IMETHOD GetMarginTop(nsAWritableString & aMarginTop); \
  NS_IMETHOD SetMarginTop(const nsAReadableString & aMarginTop); \
  NS_IMETHOD GetMarginRight(nsAWritableString & aMarginRight); \
  NS_IMETHOD SetMarginRight(const nsAReadableString & aMarginRight); \
  NS_IMETHOD GetMarginBottom(nsAWritableString & aMarginBottom); \
  NS_IMETHOD SetMarginBottom(const nsAReadableString & aMarginBottom); \
  NS_IMETHOD GetMarginLeft(nsAWritableString & aMarginLeft); \
  NS_IMETHOD SetMarginLeft(const nsAReadableString & aMarginLeft); \
  NS_IMETHOD GetMarkerOffset(nsAWritableString & aMarkerOffset); \
  NS_IMETHOD SetMarkerOffset(const nsAReadableString & aMarkerOffset); \
  NS_IMETHOD GetMarks(nsAWritableString & aMarks); \
  NS_IMETHOD SetMarks(const nsAReadableString & aMarks); \
  NS_IMETHOD GetMaxHeight(nsAWritableString & aMaxHeight); \
  NS_IMETHOD SetMaxHeight(const nsAReadableString & aMaxHeight); \
  NS_IMETHOD GetMaxWidth(nsAWritableString & aMaxWidth); \
  NS_IMETHOD SetMaxWidth(const nsAReadableString & aMaxWidth); \
  NS_IMETHOD GetMinHeight(nsAWritableString & aMinHeight); \
  NS_IMETHOD SetMinHeight(const nsAReadableString & aMinHeight); \
  NS_IMETHOD GetMinWidth(nsAWritableString & aMinWidth); \
  NS_IMETHOD SetMinWidth(const nsAReadableString & aMinWidth); \
  NS_IMETHOD GetOrphans(nsAWritableString & aOrphans); \
  NS_IMETHOD SetOrphans(const nsAReadableString & aOrphans); \
  NS_IMETHOD GetOutline(nsAWritableString & aOutline); \
  NS_IMETHOD SetOutline(const nsAReadableString & aOutline); \
  NS_IMETHOD GetOutlineColor(nsAWritableString & aOutlineColor); \
  NS_IMETHOD SetOutlineColor(const nsAReadableString & aOutlineColor); \
  NS_IMETHOD GetOutlineStyle(nsAWritableString & aOutlineStyle); \
  NS_IMETHOD SetOutlineStyle(const nsAReadableString & aOutlineStyle); \
  NS_IMETHOD GetOutlineWidth(nsAWritableString & aOutlineWidth); \
  NS_IMETHOD SetOutlineWidth(const nsAReadableString & aOutlineWidth); \
  NS_IMETHOD GetOverflow(nsAWritableString & aOverflow); \
  NS_IMETHOD SetOverflow(const nsAReadableString & aOverflow); \
  NS_IMETHOD GetPadding(nsAWritableString & aPadding); \
  NS_IMETHOD SetPadding(const nsAReadableString & aPadding); \
  NS_IMETHOD GetPaddingTop(nsAWritableString & aPaddingTop); \
  NS_IMETHOD SetPaddingTop(const nsAReadableString & aPaddingTop); \
  NS_IMETHOD GetPaddingRight(nsAWritableString & aPaddingRight); \
  NS_IMETHOD SetPaddingRight(const nsAReadableString & aPaddingRight); \
  NS_IMETHOD GetPaddingBottom(nsAWritableString & aPaddingBottom); \
  NS_IMETHOD SetPaddingBottom(const nsAReadableString & aPaddingBottom); \
  NS_IMETHOD GetPaddingLeft(nsAWritableString & aPaddingLeft); \
  NS_IMETHOD SetPaddingLeft(const nsAReadableString & aPaddingLeft); \
  NS_IMETHOD GetPage(nsAWritableString & aPage); \
  NS_IMETHOD SetPage(const nsAReadableString & aPage); \
  NS_IMETHOD GetPageBreakAfter(nsAWritableString & aPageBreakAfter); \
  NS_IMETHOD SetPageBreakAfter(const nsAReadableString & aPageBreakAfter); \
  NS_IMETHOD GetPageBreakBefore(nsAWritableString & aPageBreakBefore); \
  NS_IMETHOD SetPageBreakBefore(const nsAReadableString & aPageBreakBefore); \
  NS_IMETHOD GetPageBreakInside(nsAWritableString & aPageBreakInside); \
  NS_IMETHOD SetPageBreakInside(const nsAReadableString & aPageBreakInside); \
  NS_IMETHOD GetPause(nsAWritableString & aPause); \
  NS_IMETHOD SetPause(const nsAReadableString & aPause); \
  NS_IMETHOD GetPauseAfter(nsAWritableString & aPauseAfter); \
  NS_IMETHOD SetPauseAfter(const nsAReadableString & aPauseAfter); \
  NS_IMETHOD GetPauseBefore(nsAWritableString & aPauseBefore); \
  NS_IMETHOD SetPauseBefore(const nsAReadableString & aPauseBefore); \
  NS_IMETHOD GetPitch(nsAWritableString & aPitch); \
  NS_IMETHOD SetPitch(const nsAReadableString & aPitch); \
  NS_IMETHOD GetPitchRange(nsAWritableString & aPitchRange); \
  NS_IMETHOD SetPitchRange(const nsAReadableString & aPitchRange); \
  NS_IMETHOD GetPlayDuring(nsAWritableString & aPlayDuring); \
  NS_IMETHOD SetPlayDuring(const nsAReadableString & aPlayDuring); \
  NS_IMETHOD GetPosition(nsAWritableString & aPosition); \
  NS_IMETHOD SetPosition(const nsAReadableString & aPosition); \
  NS_IMETHOD GetQuotes(nsAWritableString & aQuotes); \
  NS_IMETHOD SetQuotes(const nsAReadableString & aQuotes); \
  NS_IMETHOD GetRichness(nsAWritableString & aRichness); \
  NS_IMETHOD SetRichness(const nsAReadableString & aRichness); \
  NS_IMETHOD GetRight(nsAWritableString & aRight); \
  NS_IMETHOD SetRight(const nsAReadableString & aRight); \
  NS_IMETHOD GetSize(nsAWritableString & aSize); \
  NS_IMETHOD SetSize(const nsAReadableString & aSize); \
  NS_IMETHOD GetSpeak(nsAWritableString & aSpeak); \
  NS_IMETHOD SetSpeak(const nsAReadableString & aSpeak); \
  NS_IMETHOD GetSpeakHeader(nsAWritableString & aSpeakHeader); \
  NS_IMETHOD SetSpeakHeader(const nsAReadableString & aSpeakHeader); \
  NS_IMETHOD GetSpeakNumeral(nsAWritableString & aSpeakNumeral); \
  NS_IMETHOD SetSpeakNumeral(const nsAReadableString & aSpeakNumeral); \
  NS_IMETHOD GetSpeakPunctuation(nsAWritableString & aSpeakPunctuation); \
  NS_IMETHOD SetSpeakPunctuation(const nsAReadableString & aSpeakPunctuation); \
  NS_IMETHOD GetSpeechRate(nsAWritableString & aSpeechRate); \
  NS_IMETHOD SetSpeechRate(const nsAReadableString & aSpeechRate); \
  NS_IMETHOD GetStress(nsAWritableString & aStress); \
  NS_IMETHOD SetStress(const nsAReadableString & aStress); \
  NS_IMETHOD GetTableLayout(nsAWritableString & aTableLayout); \
  NS_IMETHOD SetTableLayout(const nsAReadableString & aTableLayout); \
  NS_IMETHOD GetTextAlign(nsAWritableString & aTextAlign); \
  NS_IMETHOD SetTextAlign(const nsAReadableString & aTextAlign); \
  NS_IMETHOD GetTextDecoration(nsAWritableString & aTextDecoration); \
  NS_IMETHOD SetTextDecoration(const nsAReadableString & aTextDecoration); \
  NS_IMETHOD GetTextIndent(nsAWritableString & aTextIndent); \
  NS_IMETHOD SetTextIndent(const nsAReadableString & aTextIndent); \
  NS_IMETHOD GetTextShadow(nsAWritableString & aTextShadow); \
  NS_IMETHOD SetTextShadow(const nsAReadableString & aTextShadow); \
  NS_IMETHOD GetTextTransform(nsAWritableString & aTextTransform); \
  NS_IMETHOD SetTextTransform(const nsAReadableString & aTextTransform); \
  NS_IMETHOD GetTop(nsAWritableString & aTop); \
  NS_IMETHOD SetTop(const nsAReadableString & aTop); \
  NS_IMETHOD GetUnicodeBidi(nsAWritableString & aUnicodeBidi); \
  NS_IMETHOD SetUnicodeBidi(const nsAReadableString & aUnicodeBidi); \
  NS_IMETHOD GetVerticalAlign(nsAWritableString & aVerticalAlign); \
  NS_IMETHOD SetVerticalAlign(const nsAReadableString & aVerticalAlign); \
  NS_IMETHOD GetVisibility(nsAWritableString & aVisibility); \
  NS_IMETHOD SetVisibility(const nsAReadableString & aVisibility); \
  NS_IMETHOD GetVoiceFamily(nsAWritableString & aVoiceFamily); \
  NS_IMETHOD SetVoiceFamily(const nsAReadableString & aVoiceFamily); \
  NS_IMETHOD GetVolume(nsAWritableString & aVolume); \
  NS_IMETHOD SetVolume(const nsAReadableString & aVolume); \
  NS_IMETHOD GetWhiteSpace(nsAWritableString & aWhiteSpace); \
  NS_IMETHOD SetWhiteSpace(const nsAReadableString & aWhiteSpace); \
  NS_IMETHOD GetWidows(nsAWritableString & aWidows); \
  NS_IMETHOD SetWidows(const nsAReadableString & aWidows); \
  NS_IMETHOD GetWidth(nsAWritableString & aWidth); \
  NS_IMETHOD SetWidth(const nsAReadableString & aWidth); \
  NS_IMETHOD GetWordSpacing(nsAWritableString & aWordSpacing); \
  NS_IMETHOD SetWordSpacing(const nsAReadableString & aWordSpacing); \
  NS_IMETHOD GetZIndex(nsAWritableString & aZIndex); \
  NS_IMETHOD SetZIndex(const nsAReadableString & aZIndex); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIDOMCSS2PROPERTIES(_to) \
  NS_IMETHOD GetAzimuth(nsAWritableString & aAzimuth) { return _to GetAzimuth(aAzimuth); } \
  NS_IMETHOD SetAzimuth(const nsAReadableString & aAzimuth) { return _to SetAzimuth(aAzimuth); } \
  NS_IMETHOD GetBackground(nsAWritableString & aBackground) { return _to GetBackground(aBackground); } \
  NS_IMETHOD SetBackground(const nsAReadableString & aBackground) { return _to SetBackground(aBackground); } \
  NS_IMETHOD GetBackgroundAttachment(nsAWritableString & aBackgroundAttachment) { return _to GetBackgroundAttachment(aBackgroundAttachment); } \
  NS_IMETHOD SetBackgroundAttachment(const nsAReadableString & aBackgroundAttachment) { return _to SetBackgroundAttachment(aBackgroundAttachment); } \
  NS_IMETHOD GetBackgroundColor(nsAWritableString & aBackgroundColor) { return _to GetBackgroundColor(aBackgroundColor); } \
  NS_IMETHOD SetBackgroundColor(const nsAReadableString & aBackgroundColor) { return _to SetBackgroundColor(aBackgroundColor); } \
  NS_IMETHOD GetBackgroundImage(nsAWritableString & aBackgroundImage) { return _to GetBackgroundImage(aBackgroundImage); } \
  NS_IMETHOD SetBackgroundImage(const nsAReadableString & aBackgroundImage) { return _to SetBackgroundImage(aBackgroundImage); } \
  NS_IMETHOD GetBackgroundPosition(nsAWritableString & aBackgroundPosition) { return _to GetBackgroundPosition(aBackgroundPosition); } \
  NS_IMETHOD SetBackgroundPosition(const nsAReadableString & aBackgroundPosition) { return _to SetBackgroundPosition(aBackgroundPosition); } \
  NS_IMETHOD GetBackgroundRepeat(nsAWritableString & aBackgroundRepeat) { return _to GetBackgroundRepeat(aBackgroundRepeat); } \
  NS_IMETHOD SetBackgroundRepeat(const nsAReadableString & aBackgroundRepeat) { return _to SetBackgroundRepeat(aBackgroundRepeat); } \
  NS_IMETHOD GetBorder(nsAWritableString & aBorder) { return _to GetBorder(aBorder); } \
  NS_IMETHOD SetBorder(const nsAReadableString & aBorder) { return _to SetBorder(aBorder); } \
  NS_IMETHOD GetBorderCollapse(nsAWritableString & aBorderCollapse) { return _to GetBorderCollapse(aBorderCollapse); } \
  NS_IMETHOD SetBorderCollapse(const nsAReadableString & aBorderCollapse) { return _to SetBorderCollapse(aBorderCollapse); } \
  NS_IMETHOD GetBorderColor(nsAWritableString & aBorderColor) { return _to GetBorderColor(aBorderColor); } \
  NS_IMETHOD SetBorderColor(const nsAReadableString & aBorderColor) { return _to SetBorderColor(aBorderColor); } \
  NS_IMETHOD GetBorderSpacing(nsAWritableString & aBorderSpacing) { return _to GetBorderSpacing(aBorderSpacing); } \
  NS_IMETHOD SetBorderSpacing(const nsAReadableString & aBorderSpacing) { return _to SetBorderSpacing(aBorderSpacing); } \
  NS_IMETHOD GetBorderStyle(nsAWritableString & aBorderStyle) { return _to GetBorderStyle(aBorderStyle); } \
  NS_IMETHOD SetBorderStyle(const nsAReadableString & aBorderStyle) { return _to SetBorderStyle(aBorderStyle); } \
  NS_IMETHOD GetBorderTop(nsAWritableString & aBorderTop) { return _to GetBorderTop(aBorderTop); } \
  NS_IMETHOD SetBorderTop(const nsAReadableString & aBorderTop) { return _to SetBorderTop(aBorderTop); } \
  NS_IMETHOD GetBorderRight(nsAWritableString & aBorderRight) { return _to GetBorderRight(aBorderRight); } \
  NS_IMETHOD SetBorderRight(const nsAReadableString & aBorderRight) { return _to SetBorderRight(aBorderRight); } \
  NS_IMETHOD GetBorderBottom(nsAWritableString & aBorderBottom) { return _to GetBorderBottom(aBorderBottom); } \
  NS_IMETHOD SetBorderBottom(const nsAReadableString & aBorderBottom) { return _to SetBorderBottom(aBorderBottom); } \
  NS_IMETHOD GetBorderLeft(nsAWritableString & aBorderLeft) { return _to GetBorderLeft(aBorderLeft); } \
  NS_IMETHOD SetBorderLeft(const nsAReadableString & aBorderLeft) { return _to SetBorderLeft(aBorderLeft); } \
  NS_IMETHOD GetBorderTopColor(nsAWritableString & aBorderTopColor) { return _to GetBorderTopColor(aBorderTopColor); } \
  NS_IMETHOD SetBorderTopColor(const nsAReadableString & aBorderTopColor) { return _to SetBorderTopColor(aBorderTopColor); } \
  NS_IMETHOD GetBorderRightColor(nsAWritableString & aBorderRightColor) { return _to GetBorderRightColor(aBorderRightColor); } \
  NS_IMETHOD SetBorderRightColor(const nsAReadableString & aBorderRightColor) { return _to SetBorderRightColor(aBorderRightColor); } \
  NS_IMETHOD GetBorderBottomColor(nsAWritableString & aBorderBottomColor) { return _to GetBorderBottomColor(aBorderBottomColor); } \
  NS_IMETHOD SetBorderBottomColor(const nsAReadableString & aBorderBottomColor) { return _to SetBorderBottomColor(aBorderBottomColor); } \
  NS_IMETHOD GetBorderLeftColor(nsAWritableString & aBorderLeftColor) { return _to GetBorderLeftColor(aBorderLeftColor); } \
  NS_IMETHOD SetBorderLeftColor(const nsAReadableString & aBorderLeftColor) { return _to SetBorderLeftColor(aBorderLeftColor); } \
  NS_IMETHOD GetBorderTopStyle(nsAWritableString & aBorderTopStyle) { return _to GetBorderTopStyle(aBorderTopStyle); } \
  NS_IMETHOD SetBorderTopStyle(const nsAReadableString & aBorderTopStyle) { return _to SetBorderTopStyle(aBorderTopStyle); } \
  NS_IMETHOD GetBorderRightStyle(nsAWritableString & aBorderRightStyle) { return _to GetBorderRightStyle(aBorderRightStyle); } \
  NS_IMETHOD SetBorderRightStyle(const nsAReadableString & aBorderRightStyle) { return _to SetBorderRightStyle(aBorderRightStyle); } \
  NS_IMETHOD GetBorderBottomStyle(nsAWritableString & aBorderBottomStyle) { return _to GetBorderBottomStyle(aBorderBottomStyle); } \
  NS_IMETHOD SetBorderBottomStyle(const nsAReadableString & aBorderBottomStyle) { return _to SetBorderBottomStyle(aBorderBottomStyle); } \
  NS_IMETHOD GetBorderLeftStyle(nsAWritableString & aBorderLeftStyle) { return _to GetBorderLeftStyle(aBorderLeftStyle); } \
  NS_IMETHOD SetBorderLeftStyle(const nsAReadableString & aBorderLeftStyle) { return _to SetBorderLeftStyle(aBorderLeftStyle); } \
  NS_IMETHOD GetBorderTopWidth(nsAWritableString & aBorderTopWidth) { return _to GetBorderTopWidth(aBorderTopWidth); } \
  NS_IMETHOD SetBorderTopWidth(const nsAReadableString & aBorderTopWidth) { return _to SetBorderTopWidth(aBorderTopWidth); } \
  NS_IMETHOD GetBorderRightWidth(nsAWritableString & aBorderRightWidth) { return _to GetBorderRightWidth(aBorderRightWidth); } \
  NS_IMETHOD SetBorderRightWidth(const nsAReadableString & aBorderRightWidth) { return _to SetBorderRightWidth(aBorderRightWidth); } \
  NS_IMETHOD GetBorderBottomWidth(nsAWritableString & aBorderBottomWidth) { return _to GetBorderBottomWidth(aBorderBottomWidth); } \
  NS_IMETHOD SetBorderBottomWidth(const nsAReadableString & aBorderBottomWidth) { return _to SetBorderBottomWidth(aBorderBottomWidth); } \
  NS_IMETHOD GetBorderLeftWidth(nsAWritableString & aBorderLeftWidth) { return _to GetBorderLeftWidth(aBorderLeftWidth); } \
  NS_IMETHOD SetBorderLeftWidth(const nsAReadableString & aBorderLeftWidth) { return _to SetBorderLeftWidth(aBorderLeftWidth); } \
  NS_IMETHOD GetBorderWidth(nsAWritableString & aBorderWidth) { return _to GetBorderWidth(aBorderWidth); } \
  NS_IMETHOD SetBorderWidth(const nsAReadableString & aBorderWidth) { return _to SetBorderWidth(aBorderWidth); } \
  NS_IMETHOD GetBottom(nsAWritableString & aBottom) { return _to GetBottom(aBottom); } \
  NS_IMETHOD SetBottom(const nsAReadableString & aBottom) { return _to SetBottom(aBottom); } \
  NS_IMETHOD GetCaptionSide(nsAWritableString & aCaptionSide) { return _to GetCaptionSide(aCaptionSide); } \
  NS_IMETHOD SetCaptionSide(const nsAReadableString & aCaptionSide) { return _to SetCaptionSide(aCaptionSide); } \
  NS_IMETHOD GetClear(nsAWritableString & aClear) { return _to GetClear(aClear); } \
  NS_IMETHOD SetClear(const nsAReadableString & aClear) { return _to SetClear(aClear); } \
  NS_IMETHOD GetClip(nsAWritableString & aClip) { return _to GetClip(aClip); } \
  NS_IMETHOD SetClip(const nsAReadableString & aClip) { return _to SetClip(aClip); } \
  NS_IMETHOD GetColor(nsAWritableString & aColor) { return _to GetColor(aColor); } \
  NS_IMETHOD SetColor(const nsAReadableString & aColor) { return _to SetColor(aColor); } \
  NS_IMETHOD GetContent(nsAWritableString & aContent) { return _to GetContent(aContent); } \
  NS_IMETHOD SetContent(const nsAReadableString & aContent) { return _to SetContent(aContent); } \
  NS_IMETHOD GetCounterIncrement(nsAWritableString & aCounterIncrement) { return _to GetCounterIncrement(aCounterIncrement); } \
  NS_IMETHOD SetCounterIncrement(const nsAReadableString & aCounterIncrement) { return _to SetCounterIncrement(aCounterIncrement); } \
  NS_IMETHOD GetCounterReset(nsAWritableString & aCounterReset) { return _to GetCounterReset(aCounterReset); } \
  NS_IMETHOD SetCounterReset(const nsAReadableString & aCounterReset) { return _to SetCounterReset(aCounterReset); } \
  NS_IMETHOD GetCue(nsAWritableString & aCue) { return _to GetCue(aCue); } \
  NS_IMETHOD SetCue(const nsAReadableString & aCue) { return _to SetCue(aCue); } \
  NS_IMETHOD GetCueAfter(nsAWritableString & aCueAfter) { return _to GetCueAfter(aCueAfter); } \
  NS_IMETHOD SetCueAfter(const nsAReadableString & aCueAfter) { return _to SetCueAfter(aCueAfter); } \
  NS_IMETHOD GetCueBefore(nsAWritableString & aCueBefore) { return _to GetCueBefore(aCueBefore); } \
  NS_IMETHOD SetCueBefore(const nsAReadableString & aCueBefore) { return _to SetCueBefore(aCueBefore); } \
  NS_IMETHOD GetCursor(nsAWritableString & aCursor) { return _to GetCursor(aCursor); } \
  NS_IMETHOD SetCursor(const nsAReadableString & aCursor) { return _to SetCursor(aCursor); } \
  NS_IMETHOD GetDirection(nsAWritableString & aDirection) { return _to GetDirection(aDirection); } \
  NS_IMETHOD SetDirection(const nsAReadableString & aDirection) { return _to SetDirection(aDirection); } \
  NS_IMETHOD GetDisplay(nsAWritableString & aDisplay) { return _to GetDisplay(aDisplay); } \
  NS_IMETHOD SetDisplay(const nsAReadableString & aDisplay) { return _to SetDisplay(aDisplay); } \
  NS_IMETHOD GetElevation(nsAWritableString & aElevation) { return _to GetElevation(aElevation); } \
  NS_IMETHOD SetElevation(const nsAReadableString & aElevation) { return _to SetElevation(aElevation); } \
  NS_IMETHOD GetEmptyCells(nsAWritableString & aEmptyCells) { return _to GetEmptyCells(aEmptyCells); } \
  NS_IMETHOD SetEmptyCells(const nsAReadableString & aEmptyCells) { return _to SetEmptyCells(aEmptyCells); } \
  NS_IMETHOD GetCssFloat(nsAWritableString & aCssFloat) { return _to GetCssFloat(aCssFloat); } \
  NS_IMETHOD SetCssFloat(const nsAReadableString & aCssFloat) { return _to SetCssFloat(aCssFloat); } \
  NS_IMETHOD GetFont(nsAWritableString & aFont) { return _to GetFont(aFont); } \
  NS_IMETHOD SetFont(const nsAReadableString & aFont) { return _to SetFont(aFont); } \
  NS_IMETHOD GetFontFamily(nsAWritableString & aFontFamily) { return _to GetFontFamily(aFontFamily); } \
  NS_IMETHOD SetFontFamily(const nsAReadableString & aFontFamily) { return _to SetFontFamily(aFontFamily); } \
  NS_IMETHOD GetFontSize(nsAWritableString & aFontSize) { return _to GetFontSize(aFontSize); } \
  NS_IMETHOD SetFontSize(const nsAReadableString & aFontSize) { return _to SetFontSize(aFontSize); } \
  NS_IMETHOD GetFontSizeAdjust(nsAWritableString & aFontSizeAdjust) { return _to GetFontSizeAdjust(aFontSizeAdjust); } \
  NS_IMETHOD SetFontSizeAdjust(const nsAReadableString & aFontSizeAdjust) { return _to SetFontSizeAdjust(aFontSizeAdjust); } \
  NS_IMETHOD GetFontStretch(nsAWritableString & aFontStretch) { return _to GetFontStretch(aFontStretch); } \
  NS_IMETHOD SetFontStretch(const nsAReadableString & aFontStretch) { return _to SetFontStretch(aFontStretch); } \
  NS_IMETHOD GetFontStyle(nsAWritableString & aFontStyle) { return _to GetFontStyle(aFontStyle); } \
  NS_IMETHOD SetFontStyle(const nsAReadableString & aFontStyle) { return _to SetFontStyle(aFontStyle); } \
  NS_IMETHOD GetFontVariant(nsAWritableString & aFontVariant) { return _to GetFontVariant(aFontVariant); } \
  NS_IMETHOD SetFontVariant(const nsAReadableString & aFontVariant) { return _to SetFontVariant(aFontVariant); } \
  NS_IMETHOD GetFontWeight(nsAWritableString & aFontWeight) { return _to GetFontWeight(aFontWeight); } \
  NS_IMETHOD SetFontWeight(const nsAReadableString & aFontWeight) { return _to SetFontWeight(aFontWeight); } \
  NS_IMETHOD GetHeight(nsAWritableString & aHeight) { return _to GetHeight(aHeight); } \
  NS_IMETHOD SetHeight(const nsAReadableString & aHeight) { return _to SetHeight(aHeight); } \
  NS_IMETHOD GetLeft(nsAWritableString & aLeft) { return _to GetLeft(aLeft); } \
  NS_IMETHOD SetLeft(const nsAReadableString & aLeft) { return _to SetLeft(aLeft); } \
  NS_IMETHOD GetLetterSpacing(nsAWritableString & aLetterSpacing) { return _to GetLetterSpacing(aLetterSpacing); } \
  NS_IMETHOD SetLetterSpacing(const nsAReadableString & aLetterSpacing) { return _to SetLetterSpacing(aLetterSpacing); } \
  NS_IMETHOD GetLineHeight(nsAWritableString & aLineHeight) { return _to GetLineHeight(aLineHeight); } \
  NS_IMETHOD SetLineHeight(const nsAReadableString & aLineHeight) { return _to SetLineHeight(aLineHeight); } \
  NS_IMETHOD GetListStyle(nsAWritableString & aListStyle) { return _to GetListStyle(aListStyle); } \
  NS_IMETHOD SetListStyle(const nsAReadableString & aListStyle) { return _to SetListStyle(aListStyle); } \
  NS_IMETHOD GetListStyleImage(nsAWritableString & aListStyleImage) { return _to GetListStyleImage(aListStyleImage); } \
  NS_IMETHOD SetListStyleImage(const nsAReadableString & aListStyleImage) { return _to SetListStyleImage(aListStyleImage); } \
  NS_IMETHOD GetListStylePosition(nsAWritableString & aListStylePosition) { return _to GetListStylePosition(aListStylePosition); } \
  NS_IMETHOD SetListStylePosition(const nsAReadableString & aListStylePosition) { return _to SetListStylePosition(aListStylePosition); } \
  NS_IMETHOD GetListStyleType(nsAWritableString & aListStyleType) { return _to GetListStyleType(aListStyleType); } \
  NS_IMETHOD SetListStyleType(const nsAReadableString & aListStyleType) { return _to SetListStyleType(aListStyleType); } \
  NS_IMETHOD GetMargin(nsAWritableString & aMargin) { return _to GetMargin(aMargin); } \
  NS_IMETHOD SetMargin(const nsAReadableString & aMargin) { return _to SetMargin(aMargin); } \
  NS_IMETHOD GetMarginTop(nsAWritableString & aMarginTop) { return _to GetMarginTop(aMarginTop); } \
  NS_IMETHOD SetMarginTop(const nsAReadableString & aMarginTop) { return _to SetMarginTop(aMarginTop); } \
  NS_IMETHOD GetMarginRight(nsAWritableString & aMarginRight) { return _to GetMarginRight(aMarginRight); } \
  NS_IMETHOD SetMarginRight(const nsAReadableString & aMarginRight) { return _to SetMarginRight(aMarginRight); } \
  NS_IMETHOD GetMarginBottom(nsAWritableString & aMarginBottom) { return _to GetMarginBottom(aMarginBottom); } \
  NS_IMETHOD SetMarginBottom(const nsAReadableString & aMarginBottom) { return _to SetMarginBottom(aMarginBottom); } \
  NS_IMETHOD GetMarginLeft(nsAWritableString & aMarginLeft) { return _to GetMarginLeft(aMarginLeft); } \
  NS_IMETHOD SetMarginLeft(const nsAReadableString & aMarginLeft) { return _to SetMarginLeft(aMarginLeft); } \
  NS_IMETHOD GetMarkerOffset(nsAWritableString & aMarkerOffset) { return _to GetMarkerOffset(aMarkerOffset); } \
  NS_IMETHOD SetMarkerOffset(const nsAReadableString & aMarkerOffset) { return _to SetMarkerOffset(aMarkerOffset); } \
  NS_IMETHOD GetMarks(nsAWritableString & aMarks) { return _to GetMarks(aMarks); } \
  NS_IMETHOD SetMarks(const nsAReadableString & aMarks) { return _to SetMarks(aMarks); } \
  NS_IMETHOD GetMaxHeight(nsAWritableString & aMaxHeight) { return _to GetMaxHeight(aMaxHeight); } \
  NS_IMETHOD SetMaxHeight(const nsAReadableString & aMaxHeight) { return _to SetMaxHeight(aMaxHeight); } \
  NS_IMETHOD GetMaxWidth(nsAWritableString & aMaxWidth) { return _to GetMaxWidth(aMaxWidth); } \
  NS_IMETHOD SetMaxWidth(const nsAReadableString & aMaxWidth) { return _to SetMaxWidth(aMaxWidth); } \
  NS_IMETHOD GetMinHeight(nsAWritableString & aMinHeight) { return _to GetMinHeight(aMinHeight); } \
  NS_IMETHOD SetMinHeight(const nsAReadableString & aMinHeight) { return _to SetMinHeight(aMinHeight); } \
  NS_IMETHOD GetMinWidth(nsAWritableString & aMinWidth) { return _to GetMinWidth(aMinWidth); } \
  NS_IMETHOD SetMinWidth(const nsAReadableString & aMinWidth) { return _to SetMinWidth(aMinWidth); } \
  NS_IMETHOD GetOrphans(nsAWritableString & aOrphans) { return _to GetOrphans(aOrphans); } \
  NS_IMETHOD SetOrphans(const nsAReadableString & aOrphans) { return _to SetOrphans(aOrphans); } \
  NS_IMETHOD GetOutline(nsAWritableString & aOutline) { return _to GetOutline(aOutline); } \
  NS_IMETHOD SetOutline(const nsAReadableString & aOutline) { return _to SetOutline(aOutline); } \
  NS_IMETHOD GetOutlineColor(nsAWritableString & aOutlineColor) { return _to GetOutlineColor(aOutlineColor); } \
  NS_IMETHOD SetOutlineColor(const nsAReadableString & aOutlineColor) { return _to SetOutlineColor(aOutlineColor); } \
  NS_IMETHOD GetOutlineStyle(nsAWritableString & aOutlineStyle) { return _to GetOutlineStyle(aOutlineStyle); } \
  NS_IMETHOD SetOutlineStyle(const nsAReadableString & aOutlineStyle) { return _to SetOutlineStyle(aOutlineStyle); } \
  NS_IMETHOD GetOutlineWidth(nsAWritableString & aOutlineWidth) { return _to GetOutlineWidth(aOutlineWidth); } \
  NS_IMETHOD SetOutlineWidth(const nsAReadableString & aOutlineWidth) { return _to SetOutlineWidth(aOutlineWidth); } \
  NS_IMETHOD GetOverflow(nsAWritableString & aOverflow) { return _to GetOverflow(aOverflow); } \
  NS_IMETHOD SetOverflow(const nsAReadableString & aOverflow) { return _to SetOverflow(aOverflow); } \
  NS_IMETHOD GetPadding(nsAWritableString & aPadding) { return _to GetPadding(aPadding); } \
  NS_IMETHOD SetPadding(const nsAReadableString & aPadding) { return _to SetPadding(aPadding); } \
  NS_IMETHOD GetPaddingTop(nsAWritableString & aPaddingTop) { return _to GetPaddingTop(aPaddingTop); } \
  NS_IMETHOD SetPaddingTop(const nsAReadableString & aPaddingTop) { return _to SetPaddingTop(aPaddingTop); } \
  NS_IMETHOD GetPaddingRight(nsAWritableString & aPaddingRight) { return _to GetPaddingRight(aPaddingRight); } \
  NS_IMETHOD SetPaddingRight(const nsAReadableString & aPaddingRight) { return _to SetPaddingRight(aPaddingRight); } \
  NS_IMETHOD GetPaddingBottom(nsAWritableString & aPaddingBottom) { return _to GetPaddingBottom(aPaddingBottom); } \
  NS_IMETHOD SetPaddingBottom(const nsAReadableString & aPaddingBottom) { return _to SetPaddingBottom(aPaddingBottom); } \
  NS_IMETHOD GetPaddingLeft(nsAWritableString & aPaddingLeft) { return _to GetPaddingLeft(aPaddingLeft); } \
  NS_IMETHOD SetPaddingLeft(const nsAReadableString & aPaddingLeft) { return _to SetPaddingLeft(aPaddingLeft); } \
  NS_IMETHOD GetPage(nsAWritableString & aPage) { return _to GetPage(aPage); } \
  NS_IMETHOD SetPage(const nsAReadableString & aPage) { return _to SetPage(aPage); } \
  NS_IMETHOD GetPageBreakAfter(nsAWritableString & aPageBreakAfter) { return _to GetPageBreakAfter(aPageBreakAfter); } \
  NS_IMETHOD SetPageBreakAfter(const nsAReadableString & aPageBreakAfter) { return _to SetPageBreakAfter(aPageBreakAfter); } \
  NS_IMETHOD GetPageBreakBefore(nsAWritableString & aPageBreakBefore) { return _to GetPageBreakBefore(aPageBreakBefore); } \
  NS_IMETHOD SetPageBreakBefore(const nsAReadableString & aPageBreakBefore) { return _to SetPageBreakBefore(aPageBreakBefore); } \
  NS_IMETHOD GetPageBreakInside(nsAWritableString & aPageBreakInside) { return _to GetPageBreakInside(aPageBreakInside); } \
  NS_IMETHOD SetPageBreakInside(const nsAReadableString & aPageBreakInside) { return _to SetPageBreakInside(aPageBreakInside); } \
  NS_IMETHOD GetPause(nsAWritableString & aPause) { return _to GetPause(aPause); } \
  NS_IMETHOD SetPause(const nsAReadableString & aPause) { return _to SetPause(aPause); } \
  NS_IMETHOD GetPauseAfter(nsAWritableString & aPauseAfter) { return _to GetPauseAfter(aPauseAfter); } \
  NS_IMETHOD SetPauseAfter(const nsAReadableString & aPauseAfter) { return _to SetPauseAfter(aPauseAfter); } \
  NS_IMETHOD GetPauseBefore(nsAWritableString & aPauseBefore) { return _to GetPauseBefore(aPauseBefore); } \
  NS_IMETHOD SetPauseBefore(const nsAReadableString & aPauseBefore) { return _to SetPauseBefore(aPauseBefore); } \
  NS_IMETHOD GetPitch(nsAWritableString & aPitch) { return _to GetPitch(aPitch); } \
  NS_IMETHOD SetPitch(const nsAReadableString & aPitch) { return _to SetPitch(aPitch); } \
  NS_IMETHOD GetPitchRange(nsAWritableString & aPitchRange) { return _to GetPitchRange(aPitchRange); } \
  NS_IMETHOD SetPitchRange(const nsAReadableString & aPitchRange) { return _to SetPitchRange(aPitchRange); } \
  NS_IMETHOD GetPlayDuring(nsAWritableString & aPlayDuring) { return _to GetPlayDuring(aPlayDuring); } \
  NS_IMETHOD SetPlayDuring(const nsAReadableString & aPlayDuring) { return _to SetPlayDuring(aPlayDuring); } \
  NS_IMETHOD GetPosition(nsAWritableString & aPosition) { return _to GetPosition(aPosition); } \
  NS_IMETHOD SetPosition(const nsAReadableString & aPosition) { return _to SetPosition(aPosition); } \
  NS_IMETHOD GetQuotes(nsAWritableString & aQuotes) { return _to GetQuotes(aQuotes); } \
  NS_IMETHOD SetQuotes(const nsAReadableString & aQuotes) { return _to SetQuotes(aQuotes); } \
  NS_IMETHOD GetRichness(nsAWritableString & aRichness) { return _to GetRichness(aRichness); } \
  NS_IMETHOD SetRichness(const nsAReadableString & aRichness) { return _to SetRichness(aRichness); } \
  NS_IMETHOD GetRight(nsAWritableString & aRight) { return _to GetRight(aRight); } \
  NS_IMETHOD SetRight(const nsAReadableString & aRight) { return _to SetRight(aRight); } \
  NS_IMETHOD GetSize(nsAWritableString & aSize) { return _to GetSize(aSize); } \
  NS_IMETHOD SetSize(const nsAReadableString & aSize) { return _to SetSize(aSize); } \
  NS_IMETHOD GetSpeak(nsAWritableString & aSpeak) { return _to GetSpeak(aSpeak); } \
  NS_IMETHOD SetSpeak(const nsAReadableString & aSpeak) { return _to SetSpeak(aSpeak); } \
  NS_IMETHOD GetSpeakHeader(nsAWritableString & aSpeakHeader) { return _to GetSpeakHeader(aSpeakHeader); } \
  NS_IMETHOD SetSpeakHeader(const nsAReadableString & aSpeakHeader) { return _to SetSpeakHeader(aSpeakHeader); } \
  NS_IMETHOD GetSpeakNumeral(nsAWritableString & aSpeakNumeral) { return _to GetSpeakNumeral(aSpeakNumeral); } \
  NS_IMETHOD SetSpeakNumeral(const nsAReadableString & aSpeakNumeral) { return _to SetSpeakNumeral(aSpeakNumeral); } \
  NS_IMETHOD GetSpeakPunctuation(nsAWritableString & aSpeakPunctuation) { return _to GetSpeakPunctuation(aSpeakPunctuation); } \
  NS_IMETHOD SetSpeakPunctuation(const nsAReadableString & aSpeakPunctuation) { return _to SetSpeakPunctuation(aSpeakPunctuation); } \
  NS_IMETHOD GetSpeechRate(nsAWritableString & aSpeechRate) { return _to GetSpeechRate(aSpeechRate); } \
  NS_IMETHOD SetSpeechRate(const nsAReadableString & aSpeechRate) { return _to SetSpeechRate(aSpeechRate); } \
  NS_IMETHOD GetStress(nsAWritableString & aStress) { return _to GetStress(aStress); } \
  NS_IMETHOD SetStress(const nsAReadableString & aStress) { return _to SetStress(aStress); } \
  NS_IMETHOD GetTableLayout(nsAWritableString & aTableLayout) { return _to GetTableLayout(aTableLayout); } \
  NS_IMETHOD SetTableLayout(const nsAReadableString & aTableLayout) { return _to SetTableLayout(aTableLayout); } \
  NS_IMETHOD GetTextAlign(nsAWritableString & aTextAlign) { return _to GetTextAlign(aTextAlign); } \
  NS_IMETHOD SetTextAlign(const nsAReadableString & aTextAlign) { return _to SetTextAlign(aTextAlign); } \
  NS_IMETHOD GetTextDecoration(nsAWritableString & aTextDecoration) { return _to GetTextDecoration(aTextDecoration); } \
  NS_IMETHOD SetTextDecoration(const nsAReadableString & aTextDecoration) { return _to SetTextDecoration(aTextDecoration); } \
  NS_IMETHOD GetTextIndent(nsAWritableString & aTextIndent) { return _to GetTextIndent(aTextIndent); } \
  NS_IMETHOD SetTextIndent(const nsAReadableString & aTextIndent) { return _to SetTextIndent(aTextIndent); } \
  NS_IMETHOD GetTextShadow(nsAWritableString & aTextShadow) { return _to GetTextShadow(aTextShadow); } \
  NS_IMETHOD SetTextShadow(const nsAReadableString & aTextShadow) { return _to SetTextShadow(aTextShadow); } \
  NS_IMETHOD GetTextTransform(nsAWritableString & aTextTransform) { return _to GetTextTransform(aTextTransform); } \
  NS_IMETHOD SetTextTransform(const nsAReadableString & aTextTransform) { return _to SetTextTransform(aTextTransform); } \
  NS_IMETHOD GetTop(nsAWritableString & aTop) { return _to GetTop(aTop); } \
  NS_IMETHOD SetTop(const nsAReadableString & aTop) { return _to SetTop(aTop); } \
  NS_IMETHOD GetUnicodeBidi(nsAWritableString & aUnicodeBidi) { return _to GetUnicodeBidi(aUnicodeBidi); } \
  NS_IMETHOD SetUnicodeBidi(const nsAReadableString & aUnicodeBidi) { return _to SetUnicodeBidi(aUnicodeBidi); } \
  NS_IMETHOD GetVerticalAlign(nsAWritableString & aVerticalAlign) { return _to GetVerticalAlign(aVerticalAlign); } \
  NS_IMETHOD SetVerticalAlign(const nsAReadableString & aVerticalAlign) { return _to SetVerticalAlign(aVerticalAlign); } \
  NS_IMETHOD GetVisibility(nsAWritableString & aVisibility) { return _to GetVisibility(aVisibility); } \
  NS_IMETHOD SetVisibility(const nsAReadableString & aVisibility) { return _to SetVisibility(aVisibility); } \
  NS_IMETHOD GetVoiceFamily(nsAWritableString & aVoiceFamily) { return _to GetVoiceFamily(aVoiceFamily); } \
  NS_IMETHOD SetVoiceFamily(const nsAReadableString & aVoiceFamily) { return _to SetVoiceFamily(aVoiceFamily); } \
  NS_IMETHOD GetVolume(nsAWritableString & aVolume) { return _to GetVolume(aVolume); } \
  NS_IMETHOD SetVolume(const nsAReadableString & aVolume) { return _to SetVolume(aVolume); } \
  NS_IMETHOD GetWhiteSpace(nsAWritableString & aWhiteSpace) { return _to GetWhiteSpace(aWhiteSpace); } \
  NS_IMETHOD SetWhiteSpace(const nsAReadableString & aWhiteSpace) { return _to SetWhiteSpace(aWhiteSpace); } \
  NS_IMETHOD GetWidows(nsAWritableString & aWidows) { return _to GetWidows(aWidows); } \
  NS_IMETHOD SetWidows(const nsAReadableString & aWidows) { return _to SetWidows(aWidows); } \
  NS_IMETHOD GetWidth(nsAWritableString & aWidth) { return _to GetWidth(aWidth); } \
  NS_IMETHOD SetWidth(const nsAReadableString & aWidth) { return _to SetWidth(aWidth); } \
  NS_IMETHOD GetWordSpacing(nsAWritableString & aWordSpacing) { return _to GetWordSpacing(aWordSpacing); } \
  NS_IMETHOD SetWordSpacing(const nsAReadableString & aWordSpacing) { return _to SetWordSpacing(aWordSpacing); } \
  NS_IMETHOD GetZIndex(nsAWritableString & aZIndex) { return _to GetZIndex(aZIndex); } \
  NS_IMETHOD SetZIndex(const nsAReadableString & aZIndex) { return _to SetZIndex(aZIndex); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIDOMCSS2PROPERTIES(_to) \
  NS_IMETHOD GetAzimuth(nsAWritableString & aAzimuth) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAzimuth(aAzimuth); } \
  NS_IMETHOD SetAzimuth(const nsAReadableString & aAzimuth) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetAzimuth(aAzimuth); } \
  NS_IMETHOD GetBackground(nsAWritableString & aBackground) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBackground(aBackground); } \
  NS_IMETHOD SetBackground(const nsAReadableString & aBackground) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBackground(aBackground); } \
  NS_IMETHOD GetBackgroundAttachment(nsAWritableString & aBackgroundAttachment) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBackgroundAttachment(aBackgroundAttachment); } \
  NS_IMETHOD SetBackgroundAttachment(const nsAReadableString & aBackgroundAttachment) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBackgroundAttachment(aBackgroundAttachment); } \
  NS_IMETHOD GetBackgroundColor(nsAWritableString & aBackgroundColor) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBackgroundColor(aBackgroundColor); } \
  NS_IMETHOD SetBackgroundColor(const nsAReadableString & aBackgroundColor) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBackgroundColor(aBackgroundColor); } \
  NS_IMETHOD GetBackgroundImage(nsAWritableString & aBackgroundImage) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBackgroundImage(aBackgroundImage); } \
  NS_IMETHOD SetBackgroundImage(const nsAReadableString & aBackgroundImage) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBackgroundImage(aBackgroundImage); } \
  NS_IMETHOD GetBackgroundPosition(nsAWritableString & aBackgroundPosition) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBackgroundPosition(aBackgroundPosition); } \
  NS_IMETHOD SetBackgroundPosition(const nsAReadableString & aBackgroundPosition) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBackgroundPosition(aBackgroundPosition); } \
  NS_IMETHOD GetBackgroundRepeat(nsAWritableString & aBackgroundRepeat) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBackgroundRepeat(aBackgroundRepeat); } \
  NS_IMETHOD SetBackgroundRepeat(const nsAReadableString & aBackgroundRepeat) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBackgroundRepeat(aBackgroundRepeat); } \
  NS_IMETHOD GetBorder(nsAWritableString & aBorder) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorder(aBorder); } \
  NS_IMETHOD SetBorder(const nsAReadableString & aBorder) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorder(aBorder); } \
  NS_IMETHOD GetBorderCollapse(nsAWritableString & aBorderCollapse) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorderCollapse(aBorderCollapse); } \
  NS_IMETHOD SetBorderCollapse(const nsAReadableString & aBorderCollapse) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorderCollapse(aBorderCollapse); } \
  NS_IMETHOD GetBorderColor(nsAWritableString & aBorderColor) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorderColor(aBorderColor); } \
  NS_IMETHOD SetBorderColor(const nsAReadableString & aBorderColor) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorderColor(aBorderColor); } \
  NS_IMETHOD GetBorderSpacing(nsAWritableString & aBorderSpacing) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorderSpacing(aBorderSpacing); } \
  NS_IMETHOD SetBorderSpacing(const nsAReadableString & aBorderSpacing) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorderSpacing(aBorderSpacing); } \
  NS_IMETHOD GetBorderStyle(nsAWritableString & aBorderStyle) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorderStyle(aBorderStyle); } \
  NS_IMETHOD SetBorderStyle(const nsAReadableString & aBorderStyle) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorderStyle(aBorderStyle); } \
  NS_IMETHOD GetBorderTop(nsAWritableString & aBorderTop) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorderTop(aBorderTop); } \
  NS_IMETHOD SetBorderTop(const nsAReadableString & aBorderTop) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorderTop(aBorderTop); } \
  NS_IMETHOD GetBorderRight(nsAWritableString & aBorderRight) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorderRight(aBorderRight); } \
  NS_IMETHOD SetBorderRight(const nsAReadableString & aBorderRight) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorderRight(aBorderRight); } \
  NS_IMETHOD GetBorderBottom(nsAWritableString & aBorderBottom) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorderBottom(aBorderBottom); } \
  NS_IMETHOD SetBorderBottom(const nsAReadableString & aBorderBottom) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorderBottom(aBorderBottom); } \
  NS_IMETHOD GetBorderLeft(nsAWritableString & aBorderLeft) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorderLeft(aBorderLeft); } \
  NS_IMETHOD SetBorderLeft(const nsAReadableString & aBorderLeft) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorderLeft(aBorderLeft); } \
  NS_IMETHOD GetBorderTopColor(nsAWritableString & aBorderTopColor) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorderTopColor(aBorderTopColor); } \
  NS_IMETHOD SetBorderTopColor(const nsAReadableString & aBorderTopColor) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorderTopColor(aBorderTopColor); } \
  NS_IMETHOD GetBorderRightColor(nsAWritableString & aBorderRightColor) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorderRightColor(aBorderRightColor); } \
  NS_IMETHOD SetBorderRightColor(const nsAReadableString & aBorderRightColor) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorderRightColor(aBorderRightColor); } \
  NS_IMETHOD GetBorderBottomColor(nsAWritableString & aBorderBottomColor) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorderBottomColor(aBorderBottomColor); } \
  NS_IMETHOD SetBorderBottomColor(const nsAReadableString & aBorderBottomColor) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorderBottomColor(aBorderBottomColor); } \
  NS_IMETHOD GetBorderLeftColor(nsAWritableString & aBorderLeftColor) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorderLeftColor(aBorderLeftColor); } \
  NS_IMETHOD SetBorderLeftColor(const nsAReadableString & aBorderLeftColor) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorderLeftColor(aBorderLeftColor); } \
  NS_IMETHOD GetBorderTopStyle(nsAWritableString & aBorderTopStyle) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorderTopStyle(aBorderTopStyle); } \
  NS_IMETHOD SetBorderTopStyle(const nsAReadableString & aBorderTopStyle) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorderTopStyle(aBorderTopStyle); } \
  NS_IMETHOD GetBorderRightStyle(nsAWritableString & aBorderRightStyle) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorderRightStyle(aBorderRightStyle); } \
  NS_IMETHOD SetBorderRightStyle(const nsAReadableString & aBorderRightStyle) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorderRightStyle(aBorderRightStyle); } \
  NS_IMETHOD GetBorderBottomStyle(nsAWritableString & aBorderBottomStyle) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorderBottomStyle(aBorderBottomStyle); } \
  NS_IMETHOD SetBorderBottomStyle(const nsAReadableString & aBorderBottomStyle) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorderBottomStyle(aBorderBottomStyle); } \
  NS_IMETHOD GetBorderLeftStyle(nsAWritableString & aBorderLeftStyle) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorderLeftStyle(aBorderLeftStyle); } \
  NS_IMETHOD SetBorderLeftStyle(const nsAReadableString & aBorderLeftStyle) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorderLeftStyle(aBorderLeftStyle); } \
  NS_IMETHOD GetBorderTopWidth(nsAWritableString & aBorderTopWidth) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorderTopWidth(aBorderTopWidth); } \
  NS_IMETHOD SetBorderTopWidth(const nsAReadableString & aBorderTopWidth) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorderTopWidth(aBorderTopWidth); } \
  NS_IMETHOD GetBorderRightWidth(nsAWritableString & aBorderRightWidth) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorderRightWidth(aBorderRightWidth); } \
  NS_IMETHOD SetBorderRightWidth(const nsAReadableString & aBorderRightWidth) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorderRightWidth(aBorderRightWidth); } \
  NS_IMETHOD GetBorderBottomWidth(nsAWritableString & aBorderBottomWidth) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorderBottomWidth(aBorderBottomWidth); } \
  NS_IMETHOD SetBorderBottomWidth(const nsAReadableString & aBorderBottomWidth) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorderBottomWidth(aBorderBottomWidth); } \
  NS_IMETHOD GetBorderLeftWidth(nsAWritableString & aBorderLeftWidth) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorderLeftWidth(aBorderLeftWidth); } \
  NS_IMETHOD SetBorderLeftWidth(const nsAReadableString & aBorderLeftWidth) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorderLeftWidth(aBorderLeftWidth); } \
  NS_IMETHOD GetBorderWidth(nsAWritableString & aBorderWidth) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBorderWidth(aBorderWidth); } \
  NS_IMETHOD SetBorderWidth(const nsAReadableString & aBorderWidth) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBorderWidth(aBorderWidth); } \
  NS_IMETHOD GetBottom(nsAWritableString & aBottom) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBottom(aBottom); } \
  NS_IMETHOD SetBottom(const nsAReadableString & aBottom) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBottom(aBottom); } \
  NS_IMETHOD GetCaptionSide(nsAWritableString & aCaptionSide) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCaptionSide(aCaptionSide); } \
  NS_IMETHOD SetCaptionSide(const nsAReadableString & aCaptionSide) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCaptionSide(aCaptionSide); } \
  NS_IMETHOD GetClear(nsAWritableString & aClear) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetClear(aClear); } \
  NS_IMETHOD SetClear(const nsAReadableString & aClear) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetClear(aClear); } \
  NS_IMETHOD GetClip(nsAWritableString & aClip) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetClip(aClip); } \
  NS_IMETHOD SetClip(const nsAReadableString & aClip) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetClip(aClip); } \
  NS_IMETHOD GetColor(nsAWritableString & aColor) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetColor(aColor); } \
  NS_IMETHOD SetColor(const nsAReadableString & aColor) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetColor(aColor); } \
  NS_IMETHOD GetContent(nsAWritableString & aContent) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetContent(aContent); } \
  NS_IMETHOD SetContent(const nsAReadableString & aContent) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetContent(aContent); } \
  NS_IMETHOD GetCounterIncrement(nsAWritableString & aCounterIncrement) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCounterIncrement(aCounterIncrement); } \
  NS_IMETHOD SetCounterIncrement(const nsAReadableString & aCounterIncrement) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCounterIncrement(aCounterIncrement); } \
  NS_IMETHOD GetCounterReset(nsAWritableString & aCounterReset) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCounterReset(aCounterReset); } \
  NS_IMETHOD SetCounterReset(const nsAReadableString & aCounterReset) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCounterReset(aCounterReset); } \
  NS_IMETHOD GetCue(nsAWritableString & aCue) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCue(aCue); } \
  NS_IMETHOD SetCue(const nsAReadableString & aCue) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCue(aCue); } \
  NS_IMETHOD GetCueAfter(nsAWritableString & aCueAfter) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCueAfter(aCueAfter); } \
  NS_IMETHOD SetCueAfter(const nsAReadableString & aCueAfter) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCueAfter(aCueAfter); } \
  NS_IMETHOD GetCueBefore(nsAWritableString & aCueBefore) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCueBefore(aCueBefore); } \
  NS_IMETHOD SetCueBefore(const nsAReadableString & aCueBefore) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCueBefore(aCueBefore); } \
  NS_IMETHOD GetCursor(nsAWritableString & aCursor) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCursor(aCursor); } \
  NS_IMETHOD SetCursor(const nsAReadableString & aCursor) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCursor(aCursor); } \
  NS_IMETHOD GetDirection(nsAWritableString & aDirection) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDirection(aDirection); } \
  NS_IMETHOD SetDirection(const nsAReadableString & aDirection) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDirection(aDirection); } \
  NS_IMETHOD GetDisplay(nsAWritableString & aDisplay) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDisplay(aDisplay); } \
  NS_IMETHOD SetDisplay(const nsAReadableString & aDisplay) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDisplay(aDisplay); } \
  NS_IMETHOD GetElevation(nsAWritableString & aElevation) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetElevation(aElevation); } \
  NS_IMETHOD SetElevation(const nsAReadableString & aElevation) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetElevation(aElevation); } \
  NS_IMETHOD GetEmptyCells(nsAWritableString & aEmptyCells) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetEmptyCells(aEmptyCells); } \
  NS_IMETHOD SetEmptyCells(const nsAReadableString & aEmptyCells) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetEmptyCells(aEmptyCells); } \
  NS_IMETHOD GetCssFloat(nsAWritableString & aCssFloat) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCssFloat(aCssFloat); } \
  NS_IMETHOD SetCssFloat(const nsAReadableString & aCssFloat) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCssFloat(aCssFloat); } \
  NS_IMETHOD GetFont(nsAWritableString & aFont) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetFont(aFont); } \
  NS_IMETHOD SetFont(const nsAReadableString & aFont) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetFont(aFont); } \
  NS_IMETHOD GetFontFamily(nsAWritableString & aFontFamily) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetFontFamily(aFontFamily); } \
  NS_IMETHOD SetFontFamily(const nsAReadableString & aFontFamily) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetFontFamily(aFontFamily); } \
  NS_IMETHOD GetFontSize(nsAWritableString & aFontSize) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetFontSize(aFontSize); } \
  NS_IMETHOD SetFontSize(const nsAReadableString & aFontSize) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetFontSize(aFontSize); } \
  NS_IMETHOD GetFontSizeAdjust(nsAWritableString & aFontSizeAdjust) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetFontSizeAdjust(aFontSizeAdjust); } \
  NS_IMETHOD SetFontSizeAdjust(const nsAReadableString & aFontSizeAdjust) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetFontSizeAdjust(aFontSizeAdjust); } \
  NS_IMETHOD GetFontStretch(nsAWritableString & aFontStretch) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetFontStretch(aFontStretch); } \
  NS_IMETHOD SetFontStretch(const nsAReadableString & aFontStretch) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetFontStretch(aFontStretch); } \
  NS_IMETHOD GetFontStyle(nsAWritableString & aFontStyle) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetFontStyle(aFontStyle); } \
  NS_IMETHOD SetFontStyle(const nsAReadableString & aFontStyle) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetFontStyle(aFontStyle); } \
  NS_IMETHOD GetFontVariant(nsAWritableString & aFontVariant) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetFontVariant(aFontVariant); } \
  NS_IMETHOD SetFontVariant(const nsAReadableString & aFontVariant) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetFontVariant(aFontVariant); } \
  NS_IMETHOD GetFontWeight(nsAWritableString & aFontWeight) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetFontWeight(aFontWeight); } \
  NS_IMETHOD SetFontWeight(const nsAReadableString & aFontWeight) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetFontWeight(aFontWeight); } \
  NS_IMETHOD GetHeight(nsAWritableString & aHeight) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetHeight(aHeight); } \
  NS_IMETHOD SetHeight(const nsAReadableString & aHeight) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetHeight(aHeight); } \
  NS_IMETHOD GetLeft(nsAWritableString & aLeft) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetLeft(aLeft); } \
  NS_IMETHOD SetLeft(const nsAReadableString & aLeft) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetLeft(aLeft); } \
  NS_IMETHOD GetLetterSpacing(nsAWritableString & aLetterSpacing) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetLetterSpacing(aLetterSpacing); } \
  NS_IMETHOD SetLetterSpacing(const nsAReadableString & aLetterSpacing) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetLetterSpacing(aLetterSpacing); } \
  NS_IMETHOD GetLineHeight(nsAWritableString & aLineHeight) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetLineHeight(aLineHeight); } \
  NS_IMETHOD SetLineHeight(const nsAReadableString & aLineHeight) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetLineHeight(aLineHeight); } \
  NS_IMETHOD GetListStyle(nsAWritableString & aListStyle) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetListStyle(aListStyle); } \
  NS_IMETHOD SetListStyle(const nsAReadableString & aListStyle) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetListStyle(aListStyle); } \
  NS_IMETHOD GetListStyleImage(nsAWritableString & aListStyleImage) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetListStyleImage(aListStyleImage); } \
  NS_IMETHOD SetListStyleImage(const nsAReadableString & aListStyleImage) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetListStyleImage(aListStyleImage); } \
  NS_IMETHOD GetListStylePosition(nsAWritableString & aListStylePosition) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetListStylePosition(aListStylePosition); } \
  NS_IMETHOD SetListStylePosition(const nsAReadableString & aListStylePosition) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetListStylePosition(aListStylePosition); } \
  NS_IMETHOD GetListStyleType(nsAWritableString & aListStyleType) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetListStyleType(aListStyleType); } \
  NS_IMETHOD SetListStyleType(const nsAReadableString & aListStyleType) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetListStyleType(aListStyleType); } \
  NS_IMETHOD GetMargin(nsAWritableString & aMargin) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetMargin(aMargin); } \
  NS_IMETHOD SetMargin(const nsAReadableString & aMargin) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetMargin(aMargin); } \
  NS_IMETHOD GetMarginTop(nsAWritableString & aMarginTop) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetMarginTop(aMarginTop); } \
  NS_IMETHOD SetMarginTop(const nsAReadableString & aMarginTop) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetMarginTop(aMarginTop); } \
  NS_IMETHOD GetMarginRight(nsAWritableString & aMarginRight) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetMarginRight(aMarginRight); } \
  NS_IMETHOD SetMarginRight(const nsAReadableString & aMarginRight) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetMarginRight(aMarginRight); } \
  NS_IMETHOD GetMarginBottom(nsAWritableString & aMarginBottom) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetMarginBottom(aMarginBottom); } \
  NS_IMETHOD SetMarginBottom(const nsAReadableString & aMarginBottom) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetMarginBottom(aMarginBottom); } \
  NS_IMETHOD GetMarginLeft(nsAWritableString & aMarginLeft) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetMarginLeft(aMarginLeft); } \
  NS_IMETHOD SetMarginLeft(const nsAReadableString & aMarginLeft) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetMarginLeft(aMarginLeft); } \
  NS_IMETHOD GetMarkerOffset(nsAWritableString & aMarkerOffset) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetMarkerOffset(aMarkerOffset); } \
  NS_IMETHOD SetMarkerOffset(const nsAReadableString & aMarkerOffset) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetMarkerOffset(aMarkerOffset); } \
  NS_IMETHOD GetMarks(nsAWritableString & aMarks) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetMarks(aMarks); } \
  NS_IMETHOD SetMarks(const nsAReadableString & aMarks) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetMarks(aMarks); } \
  NS_IMETHOD GetMaxHeight(nsAWritableString & aMaxHeight) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetMaxHeight(aMaxHeight); } \
  NS_IMETHOD SetMaxHeight(const nsAReadableString & aMaxHeight) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetMaxHeight(aMaxHeight); } \
  NS_IMETHOD GetMaxWidth(nsAWritableString & aMaxWidth) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetMaxWidth(aMaxWidth); } \
  NS_IMETHOD SetMaxWidth(const nsAReadableString & aMaxWidth) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetMaxWidth(aMaxWidth); } \
  NS_IMETHOD GetMinHeight(nsAWritableString & aMinHeight) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetMinHeight(aMinHeight); } \
  NS_IMETHOD SetMinHeight(const nsAReadableString & aMinHeight) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetMinHeight(aMinHeight); } \
  NS_IMETHOD GetMinWidth(nsAWritableString & aMinWidth) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetMinWidth(aMinWidth); } \
  NS_IMETHOD SetMinWidth(const nsAReadableString & aMinWidth) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetMinWidth(aMinWidth); } \
  NS_IMETHOD GetOrphans(nsAWritableString & aOrphans) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetOrphans(aOrphans); } \
  NS_IMETHOD SetOrphans(const nsAReadableString & aOrphans) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetOrphans(aOrphans); } \
  NS_IMETHOD GetOutline(nsAWritableString & aOutline) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetOutline(aOutline); } \
  NS_IMETHOD SetOutline(const nsAReadableString & aOutline) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetOutline(aOutline); } \
  NS_IMETHOD GetOutlineColor(nsAWritableString & aOutlineColor) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetOutlineColor(aOutlineColor); } \
  NS_IMETHOD SetOutlineColor(const nsAReadableString & aOutlineColor) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetOutlineColor(aOutlineColor); } \
  NS_IMETHOD GetOutlineStyle(nsAWritableString & aOutlineStyle) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetOutlineStyle(aOutlineStyle); } \
  NS_IMETHOD SetOutlineStyle(const nsAReadableString & aOutlineStyle) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetOutlineStyle(aOutlineStyle); } \
  NS_IMETHOD GetOutlineWidth(nsAWritableString & aOutlineWidth) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetOutlineWidth(aOutlineWidth); } \
  NS_IMETHOD SetOutlineWidth(const nsAReadableString & aOutlineWidth) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetOutlineWidth(aOutlineWidth); } \
  NS_IMETHOD GetOverflow(nsAWritableString & aOverflow) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetOverflow(aOverflow); } \
  NS_IMETHOD SetOverflow(const nsAReadableString & aOverflow) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetOverflow(aOverflow); } \
  NS_IMETHOD GetPadding(nsAWritableString & aPadding) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPadding(aPadding); } \
  NS_IMETHOD SetPadding(const nsAReadableString & aPadding) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPadding(aPadding); } \
  NS_IMETHOD GetPaddingTop(nsAWritableString & aPaddingTop) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPaddingTop(aPaddingTop); } \
  NS_IMETHOD SetPaddingTop(const nsAReadableString & aPaddingTop) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPaddingTop(aPaddingTop); } \
  NS_IMETHOD GetPaddingRight(nsAWritableString & aPaddingRight) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPaddingRight(aPaddingRight); } \
  NS_IMETHOD SetPaddingRight(const nsAReadableString & aPaddingRight) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPaddingRight(aPaddingRight); } \
  NS_IMETHOD GetPaddingBottom(nsAWritableString & aPaddingBottom) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPaddingBottom(aPaddingBottom); } \
  NS_IMETHOD SetPaddingBottom(const nsAReadableString & aPaddingBottom) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPaddingBottom(aPaddingBottom); } \
  NS_IMETHOD GetPaddingLeft(nsAWritableString & aPaddingLeft) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPaddingLeft(aPaddingLeft); } \
  NS_IMETHOD SetPaddingLeft(const nsAReadableString & aPaddingLeft) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPaddingLeft(aPaddingLeft); } \
  NS_IMETHOD GetPage(nsAWritableString & aPage) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPage(aPage); } \
  NS_IMETHOD SetPage(const nsAReadableString & aPage) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPage(aPage); } \
  NS_IMETHOD GetPageBreakAfter(nsAWritableString & aPageBreakAfter) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPageBreakAfter(aPageBreakAfter); } \
  NS_IMETHOD SetPageBreakAfter(const nsAReadableString & aPageBreakAfter) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPageBreakAfter(aPageBreakAfter); } \
  NS_IMETHOD GetPageBreakBefore(nsAWritableString & aPageBreakBefore) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPageBreakBefore(aPageBreakBefore); } \
  NS_IMETHOD SetPageBreakBefore(const nsAReadableString & aPageBreakBefore) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPageBreakBefore(aPageBreakBefore); } \
  NS_IMETHOD GetPageBreakInside(nsAWritableString & aPageBreakInside) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPageBreakInside(aPageBreakInside); } \
  NS_IMETHOD SetPageBreakInside(const nsAReadableString & aPageBreakInside) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPageBreakInside(aPageBreakInside); } \
  NS_IMETHOD GetPause(nsAWritableString & aPause) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPause(aPause); } \
  NS_IMETHOD SetPause(const nsAReadableString & aPause) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPause(aPause); } \
  NS_IMETHOD GetPauseAfter(nsAWritableString & aPauseAfter) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPauseAfter(aPauseAfter); } \
  NS_IMETHOD SetPauseAfter(const nsAReadableString & aPauseAfter) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPauseAfter(aPauseAfter); } \
  NS_IMETHOD GetPauseBefore(nsAWritableString & aPauseBefore) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPauseBefore(aPauseBefore); } \
  NS_IMETHOD SetPauseBefore(const nsAReadableString & aPauseBefore) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPauseBefore(aPauseBefore); } \
  NS_IMETHOD GetPitch(nsAWritableString & aPitch) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPitch(aPitch); } \
  NS_IMETHOD SetPitch(const nsAReadableString & aPitch) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPitch(aPitch); } \
  NS_IMETHOD GetPitchRange(nsAWritableString & aPitchRange) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPitchRange(aPitchRange); } \
  NS_IMETHOD SetPitchRange(const nsAReadableString & aPitchRange) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPitchRange(aPitchRange); } \
  NS_IMETHOD GetPlayDuring(nsAWritableString & aPlayDuring) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPlayDuring(aPlayDuring); } \
  NS_IMETHOD SetPlayDuring(const nsAReadableString & aPlayDuring) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPlayDuring(aPlayDuring); } \
  NS_IMETHOD GetPosition(nsAWritableString & aPosition) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPosition(aPosition); } \
  NS_IMETHOD SetPosition(const nsAReadableString & aPosition) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPosition(aPosition); } \
  NS_IMETHOD GetQuotes(nsAWritableString & aQuotes) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetQuotes(aQuotes); } \
  NS_IMETHOD SetQuotes(const nsAReadableString & aQuotes) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetQuotes(aQuotes); } \
  NS_IMETHOD GetRichness(nsAWritableString & aRichness) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetRichness(aRichness); } \
  NS_IMETHOD SetRichness(const nsAReadableString & aRichness) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetRichness(aRichness); } \
  NS_IMETHOD GetRight(nsAWritableString & aRight) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetRight(aRight); } \
  NS_IMETHOD SetRight(const nsAReadableString & aRight) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetRight(aRight); } \
  NS_IMETHOD GetSize(nsAWritableString & aSize) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSize(aSize); } \
  NS_IMETHOD SetSize(const nsAReadableString & aSize) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetSize(aSize); } \
  NS_IMETHOD GetSpeak(nsAWritableString & aSpeak) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSpeak(aSpeak); } \
  NS_IMETHOD SetSpeak(const nsAReadableString & aSpeak) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetSpeak(aSpeak); } \
  NS_IMETHOD GetSpeakHeader(nsAWritableString & aSpeakHeader) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSpeakHeader(aSpeakHeader); } \
  NS_IMETHOD SetSpeakHeader(const nsAReadableString & aSpeakHeader) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetSpeakHeader(aSpeakHeader); } \
  NS_IMETHOD GetSpeakNumeral(nsAWritableString & aSpeakNumeral) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSpeakNumeral(aSpeakNumeral); } \
  NS_IMETHOD SetSpeakNumeral(const nsAReadableString & aSpeakNumeral) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetSpeakNumeral(aSpeakNumeral); } \
  NS_IMETHOD GetSpeakPunctuation(nsAWritableString & aSpeakPunctuation) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSpeakPunctuation(aSpeakPunctuation); } \
  NS_IMETHOD SetSpeakPunctuation(const nsAReadableString & aSpeakPunctuation) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetSpeakPunctuation(aSpeakPunctuation); } \
  NS_IMETHOD GetSpeechRate(nsAWritableString & aSpeechRate) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSpeechRate(aSpeechRate); } \
  NS_IMETHOD SetSpeechRate(const nsAReadableString & aSpeechRate) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetSpeechRate(aSpeechRate); } \
  NS_IMETHOD GetStress(nsAWritableString & aStress) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetStress(aStress); } \
  NS_IMETHOD SetStress(const nsAReadableString & aStress) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetStress(aStress); } \
  NS_IMETHOD GetTableLayout(nsAWritableString & aTableLayout) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetTableLayout(aTableLayout); } \
  NS_IMETHOD SetTableLayout(const nsAReadableString & aTableLayout) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetTableLayout(aTableLayout); } \
  NS_IMETHOD GetTextAlign(nsAWritableString & aTextAlign) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetTextAlign(aTextAlign); } \
  NS_IMETHOD SetTextAlign(const nsAReadableString & aTextAlign) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetTextAlign(aTextAlign); } \
  NS_IMETHOD GetTextDecoration(nsAWritableString & aTextDecoration) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetTextDecoration(aTextDecoration); } \
  NS_IMETHOD SetTextDecoration(const nsAReadableString & aTextDecoration) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetTextDecoration(aTextDecoration); } \
  NS_IMETHOD GetTextIndent(nsAWritableString & aTextIndent) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetTextIndent(aTextIndent); } \
  NS_IMETHOD SetTextIndent(const nsAReadableString & aTextIndent) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetTextIndent(aTextIndent); } \
  NS_IMETHOD GetTextShadow(nsAWritableString & aTextShadow) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetTextShadow(aTextShadow); } \
  NS_IMETHOD SetTextShadow(const nsAReadableString & aTextShadow) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetTextShadow(aTextShadow); } \
  NS_IMETHOD GetTextTransform(nsAWritableString & aTextTransform) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetTextTransform(aTextTransform); } \
  NS_IMETHOD SetTextTransform(const nsAReadableString & aTextTransform) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetTextTransform(aTextTransform); } \
  NS_IMETHOD GetTop(nsAWritableString & aTop) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetTop(aTop); } \
  NS_IMETHOD SetTop(const nsAReadableString & aTop) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetTop(aTop); } \
  NS_IMETHOD GetUnicodeBidi(nsAWritableString & aUnicodeBidi) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetUnicodeBidi(aUnicodeBidi); } \
  NS_IMETHOD SetUnicodeBidi(const nsAReadableString & aUnicodeBidi) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetUnicodeBidi(aUnicodeBidi); } \
  NS_IMETHOD GetVerticalAlign(nsAWritableString & aVerticalAlign) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetVerticalAlign(aVerticalAlign); } \
  NS_IMETHOD SetVerticalAlign(const nsAReadableString & aVerticalAlign) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetVerticalAlign(aVerticalAlign); } \
  NS_IMETHOD GetVisibility(nsAWritableString & aVisibility) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetVisibility(aVisibility); } \
  NS_IMETHOD SetVisibility(const nsAReadableString & aVisibility) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetVisibility(aVisibility); } \
  NS_IMETHOD GetVoiceFamily(nsAWritableString & aVoiceFamily) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetVoiceFamily(aVoiceFamily); } \
  NS_IMETHOD SetVoiceFamily(const nsAReadableString & aVoiceFamily) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetVoiceFamily(aVoiceFamily); } \
  NS_IMETHOD GetVolume(nsAWritableString & aVolume) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetVolume(aVolume); } \
  NS_IMETHOD SetVolume(const nsAReadableString & aVolume) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetVolume(aVolume); } \
  NS_IMETHOD GetWhiteSpace(nsAWritableString & aWhiteSpace) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWhiteSpace(aWhiteSpace); } \
  NS_IMETHOD SetWhiteSpace(const nsAReadableString & aWhiteSpace) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWhiteSpace(aWhiteSpace); } \
  NS_IMETHOD GetWidows(nsAWritableString & aWidows) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWidows(aWidows); } \
  NS_IMETHOD SetWidows(const nsAReadableString & aWidows) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWidows(aWidows); } \
  NS_IMETHOD GetWidth(nsAWritableString & aWidth) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWidth(aWidth); } \
  NS_IMETHOD SetWidth(const nsAReadableString & aWidth) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWidth(aWidth); } \
  NS_IMETHOD GetWordSpacing(nsAWritableString & aWordSpacing) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWordSpacing(aWordSpacing); } \
  NS_IMETHOD SetWordSpacing(const nsAReadableString & aWordSpacing) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWordSpacing(aWordSpacing); } \
  NS_IMETHOD GetZIndex(nsAWritableString & aZIndex) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetZIndex(aZIndex); } \
  NS_IMETHOD SetZIndex(const nsAReadableString & aZIndex) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetZIndex(aZIndex); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsDOMCSS2Properties : public nsIDOMCSS2Properties
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIDOMCSS2PROPERTIES

  nsDOMCSS2Properties();
  virtual ~nsDOMCSS2Properties();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsDOMCSS2Properties, nsIDOMCSS2Properties)

nsDOMCSS2Properties::nsDOMCSS2Properties()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsDOMCSS2Properties::~nsDOMCSS2Properties()
{
  /* destructor code */
}

/* attribute DOMString azimuth; */
NS_IMETHODIMP nsDOMCSS2Properties::GetAzimuth(nsAWritableString & aAzimuth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetAzimuth(const nsAReadableString & aAzimuth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString background; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBackground(nsAWritableString & aBackground)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBackground(const nsAReadableString & aBackground)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString backgroundAttachment; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBackgroundAttachment(nsAWritableString & aBackgroundAttachment)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBackgroundAttachment(const nsAReadableString & aBackgroundAttachment)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString backgroundColor; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBackgroundColor(nsAWritableString & aBackgroundColor)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBackgroundColor(const nsAReadableString & aBackgroundColor)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString backgroundImage; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBackgroundImage(nsAWritableString & aBackgroundImage)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBackgroundImage(const nsAReadableString & aBackgroundImage)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString backgroundPosition; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBackgroundPosition(nsAWritableString & aBackgroundPosition)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBackgroundPosition(const nsAReadableString & aBackgroundPosition)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString backgroundRepeat; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBackgroundRepeat(nsAWritableString & aBackgroundRepeat)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBackgroundRepeat(const nsAReadableString & aBackgroundRepeat)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString border; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorder(nsAWritableString & aBorder)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorder(const nsAReadableString & aBorder)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString borderCollapse; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorderCollapse(nsAWritableString & aBorderCollapse)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorderCollapse(const nsAReadableString & aBorderCollapse)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString borderColor; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorderColor(nsAWritableString & aBorderColor)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorderColor(const nsAReadableString & aBorderColor)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString borderSpacing; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorderSpacing(nsAWritableString & aBorderSpacing)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorderSpacing(const nsAReadableString & aBorderSpacing)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString borderStyle; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorderStyle(nsAWritableString & aBorderStyle)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorderStyle(const nsAReadableString & aBorderStyle)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString borderTop; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorderTop(nsAWritableString & aBorderTop)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorderTop(const nsAReadableString & aBorderTop)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString borderRight; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorderRight(nsAWritableString & aBorderRight)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorderRight(const nsAReadableString & aBorderRight)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString borderBottom; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorderBottom(nsAWritableString & aBorderBottom)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorderBottom(const nsAReadableString & aBorderBottom)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString borderLeft; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorderLeft(nsAWritableString & aBorderLeft)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorderLeft(const nsAReadableString & aBorderLeft)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString borderTopColor; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorderTopColor(nsAWritableString & aBorderTopColor)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorderTopColor(const nsAReadableString & aBorderTopColor)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString borderRightColor; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorderRightColor(nsAWritableString & aBorderRightColor)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorderRightColor(const nsAReadableString & aBorderRightColor)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString borderBottomColor; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorderBottomColor(nsAWritableString & aBorderBottomColor)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorderBottomColor(const nsAReadableString & aBorderBottomColor)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString borderLeftColor; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorderLeftColor(nsAWritableString & aBorderLeftColor)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorderLeftColor(const nsAReadableString & aBorderLeftColor)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString borderTopStyle; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorderTopStyle(nsAWritableString & aBorderTopStyle)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorderTopStyle(const nsAReadableString & aBorderTopStyle)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString borderRightStyle; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorderRightStyle(nsAWritableString & aBorderRightStyle)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorderRightStyle(const nsAReadableString & aBorderRightStyle)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString borderBottomStyle; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorderBottomStyle(nsAWritableString & aBorderBottomStyle)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorderBottomStyle(const nsAReadableString & aBorderBottomStyle)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString borderLeftStyle; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorderLeftStyle(nsAWritableString & aBorderLeftStyle)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorderLeftStyle(const nsAReadableString & aBorderLeftStyle)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString borderTopWidth; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorderTopWidth(nsAWritableString & aBorderTopWidth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorderTopWidth(const nsAReadableString & aBorderTopWidth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString borderRightWidth; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorderRightWidth(nsAWritableString & aBorderRightWidth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorderRightWidth(const nsAReadableString & aBorderRightWidth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString borderBottomWidth; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorderBottomWidth(nsAWritableString & aBorderBottomWidth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorderBottomWidth(const nsAReadableString & aBorderBottomWidth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString borderLeftWidth; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorderLeftWidth(nsAWritableString & aBorderLeftWidth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorderLeftWidth(const nsAReadableString & aBorderLeftWidth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString borderWidth; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBorderWidth(nsAWritableString & aBorderWidth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBorderWidth(const nsAReadableString & aBorderWidth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString bottom; */
NS_IMETHODIMP nsDOMCSS2Properties::GetBottom(nsAWritableString & aBottom)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetBottom(const nsAReadableString & aBottom)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString captionSide; */
NS_IMETHODIMP nsDOMCSS2Properties::GetCaptionSide(nsAWritableString & aCaptionSide)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetCaptionSide(const nsAReadableString & aCaptionSide)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString clear; */
NS_IMETHODIMP nsDOMCSS2Properties::GetClear(nsAWritableString & aClear)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetClear(const nsAReadableString & aClear)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString clip; */
NS_IMETHODIMP nsDOMCSS2Properties::GetClip(nsAWritableString & aClip)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetClip(const nsAReadableString & aClip)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString color; */
NS_IMETHODIMP nsDOMCSS2Properties::GetColor(nsAWritableString & aColor)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetColor(const nsAReadableString & aColor)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString content; */
NS_IMETHODIMP nsDOMCSS2Properties::GetContent(nsAWritableString & aContent)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetContent(const nsAReadableString & aContent)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString counterIncrement; */
NS_IMETHODIMP nsDOMCSS2Properties::GetCounterIncrement(nsAWritableString & aCounterIncrement)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetCounterIncrement(const nsAReadableString & aCounterIncrement)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString counterReset; */
NS_IMETHODIMP nsDOMCSS2Properties::GetCounterReset(nsAWritableString & aCounterReset)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetCounterReset(const nsAReadableString & aCounterReset)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString cue; */
NS_IMETHODIMP nsDOMCSS2Properties::GetCue(nsAWritableString & aCue)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetCue(const nsAReadableString & aCue)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString cueAfter; */
NS_IMETHODIMP nsDOMCSS2Properties::GetCueAfter(nsAWritableString & aCueAfter)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetCueAfter(const nsAReadableString & aCueAfter)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString cueBefore; */
NS_IMETHODIMP nsDOMCSS2Properties::GetCueBefore(nsAWritableString & aCueBefore)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetCueBefore(const nsAReadableString & aCueBefore)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString cursor; */
NS_IMETHODIMP nsDOMCSS2Properties::GetCursor(nsAWritableString & aCursor)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetCursor(const nsAReadableString & aCursor)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString direction; */
NS_IMETHODIMP nsDOMCSS2Properties::GetDirection(nsAWritableString & aDirection)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetDirection(const nsAReadableString & aDirection)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString display; */
NS_IMETHODIMP nsDOMCSS2Properties::GetDisplay(nsAWritableString & aDisplay)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetDisplay(const nsAReadableString & aDisplay)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString elevation; */
NS_IMETHODIMP nsDOMCSS2Properties::GetElevation(nsAWritableString & aElevation)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetElevation(const nsAReadableString & aElevation)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString emptyCells; */
NS_IMETHODIMP nsDOMCSS2Properties::GetEmptyCells(nsAWritableString & aEmptyCells)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetEmptyCells(const nsAReadableString & aEmptyCells)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString cssFloat; */
NS_IMETHODIMP nsDOMCSS2Properties::GetCssFloat(nsAWritableString & aCssFloat)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetCssFloat(const nsAReadableString & aCssFloat)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString font; */
NS_IMETHODIMP nsDOMCSS2Properties::GetFont(nsAWritableString & aFont)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetFont(const nsAReadableString & aFont)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString fontFamily; */
NS_IMETHODIMP nsDOMCSS2Properties::GetFontFamily(nsAWritableString & aFontFamily)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetFontFamily(const nsAReadableString & aFontFamily)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString fontSize; */
NS_IMETHODIMP nsDOMCSS2Properties::GetFontSize(nsAWritableString & aFontSize)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetFontSize(const nsAReadableString & aFontSize)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString fontSizeAdjust; */
NS_IMETHODIMP nsDOMCSS2Properties::GetFontSizeAdjust(nsAWritableString & aFontSizeAdjust)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetFontSizeAdjust(const nsAReadableString & aFontSizeAdjust)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString fontStretch; */
NS_IMETHODIMP nsDOMCSS2Properties::GetFontStretch(nsAWritableString & aFontStretch)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetFontStretch(const nsAReadableString & aFontStretch)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString fontStyle; */
NS_IMETHODIMP nsDOMCSS2Properties::GetFontStyle(nsAWritableString & aFontStyle)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetFontStyle(const nsAReadableString & aFontStyle)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString fontVariant; */
NS_IMETHODIMP nsDOMCSS2Properties::GetFontVariant(nsAWritableString & aFontVariant)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetFontVariant(const nsAReadableString & aFontVariant)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString fontWeight; */
NS_IMETHODIMP nsDOMCSS2Properties::GetFontWeight(nsAWritableString & aFontWeight)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetFontWeight(const nsAReadableString & aFontWeight)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString height; */
NS_IMETHODIMP nsDOMCSS2Properties::GetHeight(nsAWritableString & aHeight)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetHeight(const nsAReadableString & aHeight)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString left; */
NS_IMETHODIMP nsDOMCSS2Properties::GetLeft(nsAWritableString & aLeft)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetLeft(const nsAReadableString & aLeft)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString letterSpacing; */
NS_IMETHODIMP nsDOMCSS2Properties::GetLetterSpacing(nsAWritableString & aLetterSpacing)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetLetterSpacing(const nsAReadableString & aLetterSpacing)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString lineHeight; */
NS_IMETHODIMP nsDOMCSS2Properties::GetLineHeight(nsAWritableString & aLineHeight)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetLineHeight(const nsAReadableString & aLineHeight)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString listStyle; */
NS_IMETHODIMP nsDOMCSS2Properties::GetListStyle(nsAWritableString & aListStyle)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetListStyle(const nsAReadableString & aListStyle)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString listStyleImage; */
NS_IMETHODIMP nsDOMCSS2Properties::GetListStyleImage(nsAWritableString & aListStyleImage)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetListStyleImage(const nsAReadableString & aListStyleImage)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString listStylePosition; */
NS_IMETHODIMP nsDOMCSS2Properties::GetListStylePosition(nsAWritableString & aListStylePosition)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetListStylePosition(const nsAReadableString & aListStylePosition)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString listStyleType; */
NS_IMETHODIMP nsDOMCSS2Properties::GetListStyleType(nsAWritableString & aListStyleType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetListStyleType(const nsAReadableString & aListStyleType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString margin; */
NS_IMETHODIMP nsDOMCSS2Properties::GetMargin(nsAWritableString & aMargin)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetMargin(const nsAReadableString & aMargin)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString marginTop; */
NS_IMETHODIMP nsDOMCSS2Properties::GetMarginTop(nsAWritableString & aMarginTop)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetMarginTop(const nsAReadableString & aMarginTop)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString marginRight; */
NS_IMETHODIMP nsDOMCSS2Properties::GetMarginRight(nsAWritableString & aMarginRight)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetMarginRight(const nsAReadableString & aMarginRight)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString marginBottom; */
NS_IMETHODIMP nsDOMCSS2Properties::GetMarginBottom(nsAWritableString & aMarginBottom)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetMarginBottom(const nsAReadableString & aMarginBottom)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString marginLeft; */
NS_IMETHODIMP nsDOMCSS2Properties::GetMarginLeft(nsAWritableString & aMarginLeft)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetMarginLeft(const nsAReadableString & aMarginLeft)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString markerOffset; */
NS_IMETHODIMP nsDOMCSS2Properties::GetMarkerOffset(nsAWritableString & aMarkerOffset)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetMarkerOffset(const nsAReadableString & aMarkerOffset)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString marks; */
NS_IMETHODIMP nsDOMCSS2Properties::GetMarks(nsAWritableString & aMarks)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetMarks(const nsAReadableString & aMarks)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString maxHeight; */
NS_IMETHODIMP nsDOMCSS2Properties::GetMaxHeight(nsAWritableString & aMaxHeight)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetMaxHeight(const nsAReadableString & aMaxHeight)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString maxWidth; */
NS_IMETHODIMP nsDOMCSS2Properties::GetMaxWidth(nsAWritableString & aMaxWidth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetMaxWidth(const nsAReadableString & aMaxWidth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString minHeight; */
NS_IMETHODIMP nsDOMCSS2Properties::GetMinHeight(nsAWritableString & aMinHeight)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetMinHeight(const nsAReadableString & aMinHeight)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString minWidth; */
NS_IMETHODIMP nsDOMCSS2Properties::GetMinWidth(nsAWritableString & aMinWidth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetMinWidth(const nsAReadableString & aMinWidth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString orphans; */
NS_IMETHODIMP nsDOMCSS2Properties::GetOrphans(nsAWritableString & aOrphans)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetOrphans(const nsAReadableString & aOrphans)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString outline; */
NS_IMETHODIMP nsDOMCSS2Properties::GetOutline(nsAWritableString & aOutline)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetOutline(const nsAReadableString & aOutline)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString outlineColor; */
NS_IMETHODIMP nsDOMCSS2Properties::GetOutlineColor(nsAWritableString & aOutlineColor)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetOutlineColor(const nsAReadableString & aOutlineColor)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString outlineStyle; */
NS_IMETHODIMP nsDOMCSS2Properties::GetOutlineStyle(nsAWritableString & aOutlineStyle)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetOutlineStyle(const nsAReadableString & aOutlineStyle)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString outlineWidth; */
NS_IMETHODIMP nsDOMCSS2Properties::GetOutlineWidth(nsAWritableString & aOutlineWidth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetOutlineWidth(const nsAReadableString & aOutlineWidth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString overflow; */
NS_IMETHODIMP nsDOMCSS2Properties::GetOverflow(nsAWritableString & aOverflow)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetOverflow(const nsAReadableString & aOverflow)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString padding; */
NS_IMETHODIMP nsDOMCSS2Properties::GetPadding(nsAWritableString & aPadding)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetPadding(const nsAReadableString & aPadding)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString paddingTop; */
NS_IMETHODIMP nsDOMCSS2Properties::GetPaddingTop(nsAWritableString & aPaddingTop)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetPaddingTop(const nsAReadableString & aPaddingTop)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString paddingRight; */
NS_IMETHODIMP nsDOMCSS2Properties::GetPaddingRight(nsAWritableString & aPaddingRight)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetPaddingRight(const nsAReadableString & aPaddingRight)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString paddingBottom; */
NS_IMETHODIMP nsDOMCSS2Properties::GetPaddingBottom(nsAWritableString & aPaddingBottom)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetPaddingBottom(const nsAReadableString & aPaddingBottom)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString paddingLeft; */
NS_IMETHODIMP nsDOMCSS2Properties::GetPaddingLeft(nsAWritableString & aPaddingLeft)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetPaddingLeft(const nsAReadableString & aPaddingLeft)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString page; */
NS_IMETHODIMP nsDOMCSS2Properties::GetPage(nsAWritableString & aPage)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetPage(const nsAReadableString & aPage)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString pageBreakAfter; */
NS_IMETHODIMP nsDOMCSS2Properties::GetPageBreakAfter(nsAWritableString & aPageBreakAfter)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetPageBreakAfter(const nsAReadableString & aPageBreakAfter)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString pageBreakBefore; */
NS_IMETHODIMP nsDOMCSS2Properties::GetPageBreakBefore(nsAWritableString & aPageBreakBefore)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetPageBreakBefore(const nsAReadableString & aPageBreakBefore)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString pageBreakInside; */
NS_IMETHODIMP nsDOMCSS2Properties::GetPageBreakInside(nsAWritableString & aPageBreakInside)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetPageBreakInside(const nsAReadableString & aPageBreakInside)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString pause; */
NS_IMETHODIMP nsDOMCSS2Properties::GetPause(nsAWritableString & aPause)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetPause(const nsAReadableString & aPause)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString pauseAfter; */
NS_IMETHODIMP nsDOMCSS2Properties::GetPauseAfter(nsAWritableString & aPauseAfter)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetPauseAfter(const nsAReadableString & aPauseAfter)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString pauseBefore; */
NS_IMETHODIMP nsDOMCSS2Properties::GetPauseBefore(nsAWritableString & aPauseBefore)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetPauseBefore(const nsAReadableString & aPauseBefore)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString pitch; */
NS_IMETHODIMP nsDOMCSS2Properties::GetPitch(nsAWritableString & aPitch)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetPitch(const nsAReadableString & aPitch)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString pitchRange; */
NS_IMETHODIMP nsDOMCSS2Properties::GetPitchRange(nsAWritableString & aPitchRange)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetPitchRange(const nsAReadableString & aPitchRange)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString playDuring; */
NS_IMETHODIMP nsDOMCSS2Properties::GetPlayDuring(nsAWritableString & aPlayDuring)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetPlayDuring(const nsAReadableString & aPlayDuring)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString position; */
NS_IMETHODIMP nsDOMCSS2Properties::GetPosition(nsAWritableString & aPosition)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetPosition(const nsAReadableString & aPosition)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString quotes; */
NS_IMETHODIMP nsDOMCSS2Properties::GetQuotes(nsAWritableString & aQuotes)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetQuotes(const nsAReadableString & aQuotes)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString richness; */
NS_IMETHODIMP nsDOMCSS2Properties::GetRichness(nsAWritableString & aRichness)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetRichness(const nsAReadableString & aRichness)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString right; */
NS_IMETHODIMP nsDOMCSS2Properties::GetRight(nsAWritableString & aRight)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetRight(const nsAReadableString & aRight)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString size; */
NS_IMETHODIMP nsDOMCSS2Properties::GetSize(nsAWritableString & aSize)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetSize(const nsAReadableString & aSize)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString speak; */
NS_IMETHODIMP nsDOMCSS2Properties::GetSpeak(nsAWritableString & aSpeak)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetSpeak(const nsAReadableString & aSpeak)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString speakHeader; */
NS_IMETHODIMP nsDOMCSS2Properties::GetSpeakHeader(nsAWritableString & aSpeakHeader)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetSpeakHeader(const nsAReadableString & aSpeakHeader)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString speakNumeral; */
NS_IMETHODIMP nsDOMCSS2Properties::GetSpeakNumeral(nsAWritableString & aSpeakNumeral)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetSpeakNumeral(const nsAReadableString & aSpeakNumeral)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString speakPunctuation; */
NS_IMETHODIMP nsDOMCSS2Properties::GetSpeakPunctuation(nsAWritableString & aSpeakPunctuation)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetSpeakPunctuation(const nsAReadableString & aSpeakPunctuation)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString speechRate; */
NS_IMETHODIMP nsDOMCSS2Properties::GetSpeechRate(nsAWritableString & aSpeechRate)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetSpeechRate(const nsAReadableString & aSpeechRate)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString stress; */
NS_IMETHODIMP nsDOMCSS2Properties::GetStress(nsAWritableString & aStress)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetStress(const nsAReadableString & aStress)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString tableLayout; */
NS_IMETHODIMP nsDOMCSS2Properties::GetTableLayout(nsAWritableString & aTableLayout)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetTableLayout(const nsAReadableString & aTableLayout)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString textAlign; */
NS_IMETHODIMP nsDOMCSS2Properties::GetTextAlign(nsAWritableString & aTextAlign)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetTextAlign(const nsAReadableString & aTextAlign)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString textDecoration; */
NS_IMETHODIMP nsDOMCSS2Properties::GetTextDecoration(nsAWritableString & aTextDecoration)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetTextDecoration(const nsAReadableString & aTextDecoration)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString textIndent; */
NS_IMETHODIMP nsDOMCSS2Properties::GetTextIndent(nsAWritableString & aTextIndent)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetTextIndent(const nsAReadableString & aTextIndent)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString textShadow; */
NS_IMETHODIMP nsDOMCSS2Properties::GetTextShadow(nsAWritableString & aTextShadow)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetTextShadow(const nsAReadableString & aTextShadow)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString textTransform; */
NS_IMETHODIMP nsDOMCSS2Properties::GetTextTransform(nsAWritableString & aTextTransform)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetTextTransform(const nsAReadableString & aTextTransform)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString top; */
NS_IMETHODIMP nsDOMCSS2Properties::GetTop(nsAWritableString & aTop)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetTop(const nsAReadableString & aTop)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString unicodeBidi; */
NS_IMETHODIMP nsDOMCSS2Properties::GetUnicodeBidi(nsAWritableString & aUnicodeBidi)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetUnicodeBidi(const nsAReadableString & aUnicodeBidi)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString verticalAlign; */
NS_IMETHODIMP nsDOMCSS2Properties::GetVerticalAlign(nsAWritableString & aVerticalAlign)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetVerticalAlign(const nsAReadableString & aVerticalAlign)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString visibility; */
NS_IMETHODIMP nsDOMCSS2Properties::GetVisibility(nsAWritableString & aVisibility)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetVisibility(const nsAReadableString & aVisibility)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString voiceFamily; */
NS_IMETHODIMP nsDOMCSS2Properties::GetVoiceFamily(nsAWritableString & aVoiceFamily)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetVoiceFamily(const nsAReadableString & aVoiceFamily)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString volume; */
NS_IMETHODIMP nsDOMCSS2Properties::GetVolume(nsAWritableString & aVolume)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetVolume(const nsAReadableString & aVolume)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString whiteSpace; */
NS_IMETHODIMP nsDOMCSS2Properties::GetWhiteSpace(nsAWritableString & aWhiteSpace)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetWhiteSpace(const nsAReadableString & aWhiteSpace)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString widows; */
NS_IMETHODIMP nsDOMCSS2Properties::GetWidows(nsAWritableString & aWidows)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetWidows(const nsAReadableString & aWidows)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString width; */
NS_IMETHODIMP nsDOMCSS2Properties::GetWidth(nsAWritableString & aWidth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetWidth(const nsAReadableString & aWidth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString wordSpacing; */
NS_IMETHODIMP nsDOMCSS2Properties::GetWordSpacing(nsAWritableString & aWordSpacing)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetWordSpacing(const nsAReadableString & aWordSpacing)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString zIndex; */
NS_IMETHODIMP nsDOMCSS2Properties::GetZIndex(nsAWritableString & aZIndex)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMCSS2Properties::SetZIndex(const nsAReadableString & aZIndex)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIDOMNSCSS2Properties */
#define NS_IDOMNSCSS2PROPERTIES_IID_STR "88354c1a-d623-44a9-a894-4ee01ba29615"

#define NS_IDOMNSCSS2PROPERTIES_IID \
  {0x88354c1a, 0xd623, 0x44a9, \
    { 0xa8, 0x94, 0x4e, 0xe0, 0x1b, 0xa2, 0x96, 0x15 }}

class NS_NO_VTABLE nsIDOMNSCSS2Properties : public nsIDOMCSS2Properties {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IDOMNSCSS2PROPERTIES_IID)

  /* attribute DOMString MozBinding; */
  NS_IMETHOD GetMozBinding(nsAWritableString & aMozBinding) = 0;
  NS_IMETHOD SetMozBinding(const nsAReadableString & aMozBinding) = 0;

  /* attribute DOMString MozOpacity; */
  NS_IMETHOD GetMozOpacity(nsAWritableString & aMozOpacity) = 0;
  NS_IMETHOD SetMozOpacity(const nsAReadableString & aMozOpacity) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIDOMNSCSS2PROPERTIES \
  NS_IMETHOD GetMozBinding(nsAWritableString & aMozBinding); \
  NS_IMETHOD SetMozBinding(const nsAReadableString & aMozBinding); \
  NS_IMETHOD GetMozOpacity(nsAWritableString & aMozOpacity); \
  NS_IMETHOD SetMozOpacity(const nsAReadableString & aMozOpacity); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIDOMNSCSS2PROPERTIES(_to) \
  NS_IMETHOD GetMozBinding(nsAWritableString & aMozBinding) { return _to GetMozBinding(aMozBinding); } \
  NS_IMETHOD SetMozBinding(const nsAReadableString & aMozBinding) { return _to SetMozBinding(aMozBinding); } \
  NS_IMETHOD GetMozOpacity(nsAWritableString & aMozOpacity) { return _to GetMozOpacity(aMozOpacity); } \
  NS_IMETHOD SetMozOpacity(const nsAReadableString & aMozOpacity) { return _to SetMozOpacity(aMozOpacity); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIDOMNSCSS2PROPERTIES(_to) \
  NS_IMETHOD GetMozBinding(nsAWritableString & aMozBinding) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetMozBinding(aMozBinding); } \
  NS_IMETHOD SetMozBinding(const nsAReadableString & aMozBinding) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetMozBinding(aMozBinding); } \
  NS_IMETHOD GetMozOpacity(nsAWritableString & aMozOpacity) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetMozOpacity(aMozOpacity); } \
  NS_IMETHOD SetMozOpacity(const nsAReadableString & aMozOpacity) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetMozOpacity(aMozOpacity); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsDOMNSCSS2Properties : public nsIDOMNSCSS2Properties
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIDOMNSCSS2PROPERTIES

  nsDOMNSCSS2Properties();
  virtual ~nsDOMNSCSS2Properties();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsDOMNSCSS2Properties, nsIDOMNSCSS2Properties)

nsDOMNSCSS2Properties::nsDOMNSCSS2Properties()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsDOMNSCSS2Properties::~nsDOMNSCSS2Properties()
{
  /* destructor code */
}

/* attribute DOMString MozBinding; */
NS_IMETHODIMP nsDOMNSCSS2Properties::GetMozBinding(nsAWritableString & aMozBinding)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMNSCSS2Properties::SetMozBinding(const nsAReadableString & aMozBinding)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute DOMString MozOpacity; */
NS_IMETHODIMP nsDOMNSCSS2Properties::GetMozOpacity(nsAWritableString & aMozOpacity)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDOMNSCSS2Properties::SetMozOpacity(const nsAReadableString & aMozOpacity)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIDOMCSS2Properties_h__ */
