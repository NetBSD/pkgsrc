/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAccessibilityService.idl
 */

#ifndef __gen_nsIAccessibilityService_h__
#define __gen_nsIAccessibilityService_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_domstubs_h__
#include "domstubs.h"
#endif

#ifndef __gen_nsIAtom_h__
#include "nsIAtom.h"
#endif

#ifndef __gen_domstubs_h__
#include "domstubs.h"
#endif

#ifndef __gen_nsIAccessible_h__
#include "nsIAccessible.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIWeakReference; /* forward declaration */


/* starting interface:    nsIAccessibilityService */
#define NS_IACCESSIBILITYSERVICE_IID_STR "68d9720a-0984-42b6-a3f5-8237ed925727"

#define NS_IACCESSIBILITYSERVICE_IID \
  {0x68d9720a, 0x0984, 0x42b6, \
    { 0xa3, 0xf5, 0x82, 0x37, 0xed, 0x92, 0x57, 0x27 }}

class NS_NO_VTABLE nsIAccessibilityService : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IACCESSIBILITYSERVICE_IID)

  /* nsIAccessible createRootAccessible (in nsISupports aPresContext, in nsISupports aFrame); */
  NS_IMETHOD CreateRootAccessible(nsISupports *aPresContext, nsISupports *aFrame, nsIAccessible **_retval) = 0;

  /* nsIAccessible createHTMLComboboxAccessible (in nsIDOMNode aNode, in nsISupports aPresShell); */
  NS_IMETHOD CreateHTMLComboboxAccessible(nsIDOMNode *aNode, nsISupports *aPresShell, nsIAccessible **_retval) = 0;

  /* nsIAccessible createHTMLListboxAccessible (in nsIDOMNode aNode, in nsISupports aPresShell); */
  NS_IMETHOD CreateHTMLListboxAccessible(nsIDOMNode *aNode, nsISupports *aPresShell, nsIAccessible **_retval) = 0;

  /* nsIAccessible createHTMLSelectOptionAccessible (in nsIDOMNode aNode, in nsIAccessible aAccParent, in nsISupports aPresShell); */
  NS_IMETHOD CreateHTMLSelectOptionAccessible(nsIDOMNode *aNode, nsIAccessible *aAccParent, nsISupports *aPresShell, nsIAccessible **_retval) = 0;

  /* nsIAccessible createHTMLCheckboxAccessible (in nsISupports aFrame); */
  NS_IMETHOD CreateHTMLCheckboxAccessible(nsISupports *aFrame, nsIAccessible **_retval) = 0;

  /* nsIAccessible createHTMLRadioButtonAccessible (in nsISupports aFrame); */
  NS_IMETHOD CreateHTMLRadioButtonAccessible(nsISupports *aFrame, nsIAccessible **_retval) = 0;

  /* nsIAccessible createHTMLButtonAccessible (in nsISupports aFrame); */
  NS_IMETHOD CreateHTMLButtonAccessible(nsISupports *aFrame, nsIAccessible **_retval) = 0;

  /* nsIAccessible createHTML4ButtonAccessible (in nsISupports aFrame); */
  NS_IMETHOD CreateHTML4ButtonAccessible(nsISupports *aFrame, nsIAccessible **_retval) = 0;

  /* nsIAccessible createHTMLTextAccessible (in nsISupports aFrame); */
  NS_IMETHOD CreateHTMLTextAccessible(nsISupports *aFrame, nsIAccessible **_retval) = 0;

  /* nsIAccessible createHTMLImageAccessible (in nsISupports aFrame); */
  NS_IMETHOD CreateHTMLImageAccessible(nsISupports *aFrame, nsIAccessible **_retval) = 0;

  /* nsIAccessible createHTMLAreaAccessible (in nsIWeakReference aPresShell, in nsIDOMNode aDOMNode, in nsIAccessible aAccParent); */
  NS_IMETHOD CreateHTMLAreaAccessible(nsIWeakReference *aPresShell, nsIDOMNode *aDOMNode, nsIAccessible *aAccParent, nsIAccessible **_retval) = 0;

  /* nsIAccessible createHTMLTableAccessible (in nsISupports aFrame); */
  NS_IMETHOD CreateHTMLTableAccessible(nsISupports *aFrame, nsIAccessible **_retval) = 0;

  /* nsIAccessible createHTMLTableCellAccessible (in nsISupports aFrame); */
  NS_IMETHOD CreateHTMLTableCellAccessible(nsISupports *aFrame, nsIAccessible **_retval) = 0;

  /* nsIAccessible createHTMLTextFieldAccessible (in nsISupports aFrame); */
  NS_IMETHOD CreateHTMLTextFieldAccessible(nsISupports *aFrame, nsIAccessible **_retval) = 0;

  /* nsIAccessible createHTMLIFrameAccessible (in nsIDOMNode aNode, in nsISupports aPresContext); */
  NS_IMETHOD CreateHTMLIFrameAccessible(nsIDOMNode *aNode, nsISupports *aPresContext, nsIAccessible **_retval) = 0;

  /* nsIAccessible createHTMLBlockAccessible (in nsIDOMNode aNode, in nsISupports aDocument); */
  NS_IMETHOD CreateHTMLBlockAccessible(nsIDOMNode *aNode, nsISupports *aDocument, nsIAccessible **_retval) = 0;

  /* nsIAccessible createAccessible (in nsIDOMNode aNode, in nsISupports aDocument); */
  NS_IMETHOD CreateAccessible(nsIDOMNode *aNode, nsISupports *aDocument, nsIAccessible **_retval) = 0;

  /* nsIAccessible getAccessibleFor (in nsIDOMNode aNode); */
  NS_IMETHOD GetAccessibleFor(nsIDOMNode *aNode, nsIAccessible **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIACCESSIBILITYSERVICE \
  NS_IMETHOD CreateRootAccessible(nsISupports *aPresContext, nsISupports *aFrame, nsIAccessible **_retval); \
  NS_IMETHOD CreateHTMLComboboxAccessible(nsIDOMNode *aNode, nsISupports *aPresShell, nsIAccessible **_retval); \
  NS_IMETHOD CreateHTMLListboxAccessible(nsIDOMNode *aNode, nsISupports *aPresShell, nsIAccessible **_retval); \
  NS_IMETHOD CreateHTMLSelectOptionAccessible(nsIDOMNode *aNode, nsIAccessible *aAccParent, nsISupports *aPresShell, nsIAccessible **_retval); \
  NS_IMETHOD CreateHTMLCheckboxAccessible(nsISupports *aFrame, nsIAccessible **_retval); \
  NS_IMETHOD CreateHTMLRadioButtonAccessible(nsISupports *aFrame, nsIAccessible **_retval); \
  NS_IMETHOD CreateHTMLButtonAccessible(nsISupports *aFrame, nsIAccessible **_retval); \
  NS_IMETHOD CreateHTML4ButtonAccessible(nsISupports *aFrame, nsIAccessible **_retval); \
  NS_IMETHOD CreateHTMLTextAccessible(nsISupports *aFrame, nsIAccessible **_retval); \
  NS_IMETHOD CreateHTMLImageAccessible(nsISupports *aFrame, nsIAccessible **_retval); \
  NS_IMETHOD CreateHTMLAreaAccessible(nsIWeakReference *aPresShell, nsIDOMNode *aDOMNode, nsIAccessible *aAccParent, nsIAccessible **_retval); \
  NS_IMETHOD CreateHTMLTableAccessible(nsISupports *aFrame, nsIAccessible **_retval); \
  NS_IMETHOD CreateHTMLTableCellAccessible(nsISupports *aFrame, nsIAccessible **_retval); \
  NS_IMETHOD CreateHTMLTextFieldAccessible(nsISupports *aFrame, nsIAccessible **_retval); \
  NS_IMETHOD CreateHTMLIFrameAccessible(nsIDOMNode *aNode, nsISupports *aPresContext, nsIAccessible **_retval); \
  NS_IMETHOD CreateHTMLBlockAccessible(nsIDOMNode *aNode, nsISupports *aDocument, nsIAccessible **_retval); \
  NS_IMETHOD CreateAccessible(nsIDOMNode *aNode, nsISupports *aDocument, nsIAccessible **_retval); \
  NS_IMETHOD GetAccessibleFor(nsIDOMNode *aNode, nsIAccessible **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIACCESSIBILITYSERVICE(_to) \
  NS_IMETHOD CreateRootAccessible(nsISupports *aPresContext, nsISupports *aFrame, nsIAccessible **_retval) { return _to CreateRootAccessible(aPresContext, aFrame, _retval); } \
  NS_IMETHOD CreateHTMLComboboxAccessible(nsIDOMNode *aNode, nsISupports *aPresShell, nsIAccessible **_retval) { return _to CreateHTMLComboboxAccessible(aNode, aPresShell, _retval); } \
  NS_IMETHOD CreateHTMLListboxAccessible(nsIDOMNode *aNode, nsISupports *aPresShell, nsIAccessible **_retval) { return _to CreateHTMLListboxAccessible(aNode, aPresShell, _retval); } \
  NS_IMETHOD CreateHTMLSelectOptionAccessible(nsIDOMNode *aNode, nsIAccessible *aAccParent, nsISupports *aPresShell, nsIAccessible **_retval) { return _to CreateHTMLSelectOptionAccessible(aNode, aAccParent, aPresShell, _retval); } \
  NS_IMETHOD CreateHTMLCheckboxAccessible(nsISupports *aFrame, nsIAccessible **_retval) { return _to CreateHTMLCheckboxAccessible(aFrame, _retval); } \
  NS_IMETHOD CreateHTMLRadioButtonAccessible(nsISupports *aFrame, nsIAccessible **_retval) { return _to CreateHTMLRadioButtonAccessible(aFrame, _retval); } \
  NS_IMETHOD CreateHTMLButtonAccessible(nsISupports *aFrame, nsIAccessible **_retval) { return _to CreateHTMLButtonAccessible(aFrame, _retval); } \
  NS_IMETHOD CreateHTML4ButtonAccessible(nsISupports *aFrame, nsIAccessible **_retval) { return _to CreateHTML4ButtonAccessible(aFrame, _retval); } \
  NS_IMETHOD CreateHTMLTextAccessible(nsISupports *aFrame, nsIAccessible **_retval) { return _to CreateHTMLTextAccessible(aFrame, _retval); } \
  NS_IMETHOD CreateHTMLImageAccessible(nsISupports *aFrame, nsIAccessible **_retval) { return _to CreateHTMLImageAccessible(aFrame, _retval); } \
  NS_IMETHOD CreateHTMLAreaAccessible(nsIWeakReference *aPresShell, nsIDOMNode *aDOMNode, nsIAccessible *aAccParent, nsIAccessible **_retval) { return _to CreateHTMLAreaAccessible(aPresShell, aDOMNode, aAccParent, _retval); } \
  NS_IMETHOD CreateHTMLTableAccessible(nsISupports *aFrame, nsIAccessible **_retval) { return _to CreateHTMLTableAccessible(aFrame, _retval); } \
  NS_IMETHOD CreateHTMLTableCellAccessible(nsISupports *aFrame, nsIAccessible **_retval) { return _to CreateHTMLTableCellAccessible(aFrame, _retval); } \
  NS_IMETHOD CreateHTMLTextFieldAccessible(nsISupports *aFrame, nsIAccessible **_retval) { return _to CreateHTMLTextFieldAccessible(aFrame, _retval); } \
  NS_IMETHOD CreateHTMLIFrameAccessible(nsIDOMNode *aNode, nsISupports *aPresContext, nsIAccessible **_retval) { return _to CreateHTMLIFrameAccessible(aNode, aPresContext, _retval); } \
  NS_IMETHOD CreateHTMLBlockAccessible(nsIDOMNode *aNode, nsISupports *aDocument, nsIAccessible **_retval) { return _to CreateHTMLBlockAccessible(aNode, aDocument, _retval); } \
  NS_IMETHOD CreateAccessible(nsIDOMNode *aNode, nsISupports *aDocument, nsIAccessible **_retval) { return _to CreateAccessible(aNode, aDocument, _retval); } \
  NS_IMETHOD GetAccessibleFor(nsIDOMNode *aNode, nsIAccessible **_retval) { return _to GetAccessibleFor(aNode, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIACCESSIBILITYSERVICE(_to) \
  NS_IMETHOD CreateRootAccessible(nsISupports *aPresContext, nsISupports *aFrame, nsIAccessible **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateRootAccessible(aPresContext, aFrame, _retval); } \
  NS_IMETHOD CreateHTMLComboboxAccessible(nsIDOMNode *aNode, nsISupports *aPresShell, nsIAccessible **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateHTMLComboboxAccessible(aNode, aPresShell, _retval); } \
  NS_IMETHOD CreateHTMLListboxAccessible(nsIDOMNode *aNode, nsISupports *aPresShell, nsIAccessible **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateHTMLListboxAccessible(aNode, aPresShell, _retval); } \
  NS_IMETHOD CreateHTMLSelectOptionAccessible(nsIDOMNode *aNode, nsIAccessible *aAccParent, nsISupports *aPresShell, nsIAccessible **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateHTMLSelectOptionAccessible(aNode, aAccParent, aPresShell, _retval); } \
  NS_IMETHOD CreateHTMLCheckboxAccessible(nsISupports *aFrame, nsIAccessible **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateHTMLCheckboxAccessible(aFrame, _retval); } \
  NS_IMETHOD CreateHTMLRadioButtonAccessible(nsISupports *aFrame, nsIAccessible **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateHTMLRadioButtonAccessible(aFrame, _retval); } \
  NS_IMETHOD CreateHTMLButtonAccessible(nsISupports *aFrame, nsIAccessible **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateHTMLButtonAccessible(aFrame, _retval); } \
  NS_IMETHOD CreateHTML4ButtonAccessible(nsISupports *aFrame, nsIAccessible **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateHTML4ButtonAccessible(aFrame, _retval); } \
  NS_IMETHOD CreateHTMLTextAccessible(nsISupports *aFrame, nsIAccessible **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateHTMLTextAccessible(aFrame, _retval); } \
  NS_IMETHOD CreateHTMLImageAccessible(nsISupports *aFrame, nsIAccessible **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateHTMLImageAccessible(aFrame, _retval); } \
  NS_IMETHOD CreateHTMLAreaAccessible(nsIWeakReference *aPresShell, nsIDOMNode *aDOMNode, nsIAccessible *aAccParent, nsIAccessible **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateHTMLAreaAccessible(aPresShell, aDOMNode, aAccParent, _retval); } \
  NS_IMETHOD CreateHTMLTableAccessible(nsISupports *aFrame, nsIAccessible **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateHTMLTableAccessible(aFrame, _retval); } \
  NS_IMETHOD CreateHTMLTableCellAccessible(nsISupports *aFrame, nsIAccessible **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateHTMLTableCellAccessible(aFrame, _retval); } \
  NS_IMETHOD CreateHTMLTextFieldAccessible(nsISupports *aFrame, nsIAccessible **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateHTMLTextFieldAccessible(aFrame, _retval); } \
  NS_IMETHOD CreateHTMLIFrameAccessible(nsIDOMNode *aNode, nsISupports *aPresContext, nsIAccessible **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateHTMLIFrameAccessible(aNode, aPresContext, _retval); } \
  NS_IMETHOD CreateHTMLBlockAccessible(nsIDOMNode *aNode, nsISupports *aDocument, nsIAccessible **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateHTMLBlockAccessible(aNode, aDocument, _retval); } \
  NS_IMETHOD CreateAccessible(nsIDOMNode *aNode, nsISupports *aDocument, nsIAccessible **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateAccessible(aNode, aDocument, _retval); } \
  NS_IMETHOD GetAccessibleFor(nsIDOMNode *aNode, nsIAccessible **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAccessibleFor(aNode, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAccessibilityService : public nsIAccessibilityService
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIACCESSIBILITYSERVICE

  nsAccessibilityService();
  virtual ~nsAccessibilityService();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAccessibilityService, nsIAccessibilityService)

nsAccessibilityService::nsAccessibilityService()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAccessibilityService::~nsAccessibilityService()
{
  /* destructor code */
}

/* nsIAccessible createRootAccessible (in nsISupports aPresContext, in nsISupports aFrame); */
NS_IMETHODIMP nsAccessibilityService::CreateRootAccessible(nsISupports *aPresContext, nsISupports *aFrame, nsIAccessible **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAccessible createHTMLComboboxAccessible (in nsIDOMNode aNode, in nsISupports aPresShell); */
NS_IMETHODIMP nsAccessibilityService::CreateHTMLComboboxAccessible(nsIDOMNode *aNode, nsISupports *aPresShell, nsIAccessible **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAccessible createHTMLListboxAccessible (in nsIDOMNode aNode, in nsISupports aPresShell); */
NS_IMETHODIMP nsAccessibilityService::CreateHTMLListboxAccessible(nsIDOMNode *aNode, nsISupports *aPresShell, nsIAccessible **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAccessible createHTMLSelectOptionAccessible (in nsIDOMNode aNode, in nsIAccessible aAccParent, in nsISupports aPresShell); */
NS_IMETHODIMP nsAccessibilityService::CreateHTMLSelectOptionAccessible(nsIDOMNode *aNode, nsIAccessible *aAccParent, nsISupports *aPresShell, nsIAccessible **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAccessible createHTMLCheckboxAccessible (in nsISupports aFrame); */
NS_IMETHODIMP nsAccessibilityService::CreateHTMLCheckboxAccessible(nsISupports *aFrame, nsIAccessible **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAccessible createHTMLRadioButtonAccessible (in nsISupports aFrame); */
NS_IMETHODIMP nsAccessibilityService::CreateHTMLRadioButtonAccessible(nsISupports *aFrame, nsIAccessible **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAccessible createHTMLButtonAccessible (in nsISupports aFrame); */
NS_IMETHODIMP nsAccessibilityService::CreateHTMLButtonAccessible(nsISupports *aFrame, nsIAccessible **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAccessible createHTML4ButtonAccessible (in nsISupports aFrame); */
NS_IMETHODIMP nsAccessibilityService::CreateHTML4ButtonAccessible(nsISupports *aFrame, nsIAccessible **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAccessible createHTMLTextAccessible (in nsISupports aFrame); */
NS_IMETHODIMP nsAccessibilityService::CreateHTMLTextAccessible(nsISupports *aFrame, nsIAccessible **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAccessible createHTMLImageAccessible (in nsISupports aFrame); */
NS_IMETHODIMP nsAccessibilityService::CreateHTMLImageAccessible(nsISupports *aFrame, nsIAccessible **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAccessible createHTMLAreaAccessible (in nsIWeakReference aPresShell, in nsIDOMNode aDOMNode, in nsIAccessible aAccParent); */
NS_IMETHODIMP nsAccessibilityService::CreateHTMLAreaAccessible(nsIWeakReference *aPresShell, nsIDOMNode *aDOMNode, nsIAccessible *aAccParent, nsIAccessible **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAccessible createHTMLTableAccessible (in nsISupports aFrame); */
NS_IMETHODIMP nsAccessibilityService::CreateHTMLTableAccessible(nsISupports *aFrame, nsIAccessible **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAccessible createHTMLTableCellAccessible (in nsISupports aFrame); */
NS_IMETHODIMP nsAccessibilityService::CreateHTMLTableCellAccessible(nsISupports *aFrame, nsIAccessible **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAccessible createHTMLTextFieldAccessible (in nsISupports aFrame); */
NS_IMETHODIMP nsAccessibilityService::CreateHTMLTextFieldAccessible(nsISupports *aFrame, nsIAccessible **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAccessible createHTMLIFrameAccessible (in nsIDOMNode aNode, in nsISupports aPresContext); */
NS_IMETHODIMP nsAccessibilityService::CreateHTMLIFrameAccessible(nsIDOMNode *aNode, nsISupports *aPresContext, nsIAccessible **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAccessible createHTMLBlockAccessible (in nsIDOMNode aNode, in nsISupports aDocument); */
NS_IMETHODIMP nsAccessibilityService::CreateHTMLBlockAccessible(nsIDOMNode *aNode, nsISupports *aDocument, nsIAccessible **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAccessible createAccessible (in nsIDOMNode aNode, in nsISupports aDocument); */
NS_IMETHODIMP nsAccessibilityService::CreateAccessible(nsIDOMNode *aNode, nsISupports *aDocument, nsIAccessible **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAccessible getAccessibleFor (in nsIDOMNode aNode); */
NS_IMETHODIMP nsAccessibilityService::GetAccessibleFor(nsIDOMNode *aNode, nsIAccessible **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif

// for component registration
// {DE401C37-9A7F-4278-A6F8-3DE2833989EF}
#define NS_ACCESSIBILITY_SERVICE_CID \
{ 0xde401c37, 0x9a7f, 0x4278, { 0xa6, 0xf8, 0x3d, 0xe2, 0x83, 0x39, 0x89, 0xef } }
extern nsresult
NS_NewAccessibilityService(nsIAccessibilityService** aResult);

#endif /* __gen_nsIAccessibilityService_h__ */
