/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbCard.idl
 */

#ifndef __gen_nsIAbCard_h__
#define __gen_nsIAbCard_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIAddrDatabase; /* forward declaration */

#include "nsVoidArray.h"

/* starting interface:    nsIAbPreferMailFormat */
#define NS_IABPREFERMAILFORMAT_IID_STR "97448252-f189-11d4-a422-001083003d0c"

#define NS_IABPREFERMAILFORMAT_IID \
  {0x97448252, 0xf189, 0x11d4, \
    { 0xa4, 0x22, 0x00, 0x10, 0x83, 0x00, 0x3d, 0x0c }}

class NS_NO_VTABLE nsIAbPreferMailFormat {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABPREFERMAILFORMAT_IID)

  enum { unknown = 0U };

  enum { plaintext = 1U };

  enum { html = 2U };

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABPREFERMAILFORMAT \

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABPREFERMAILFORMAT(_to) \

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABPREFERMAILFORMAT(_to) \

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbPreferMailFormat : public nsIAbPreferMailFormat
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABPREFERMAILFORMAT

  nsAbPreferMailFormat();
  virtual ~nsAbPreferMailFormat();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbPreferMailFormat, nsIAbPreferMailFormat)

nsAbPreferMailFormat::nsAbPreferMailFormat()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAbPreferMailFormat::~nsAbPreferMailFormat()
{
  /* destructor code */
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIAbCard */
#define NS_IABCARD_IID_STR "fa5c977f-04c8-11d3-a2eb-001083003d0c"

#define NS_IABCARD_IID \
  {0xfa5c977f, 0x04c8, 0x11d3, \
    { 0xa2, 0xeb, 0x00, 0x10, 0x83, 0x00, 0x3d, 0x0c }}

class NS_NO_VTABLE nsIAbCard : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABCARD_IID)

  /* attribute wstring firstName; */
  NS_IMETHOD GetFirstName(PRUnichar * *aFirstName) = 0;
  NS_IMETHOD SetFirstName(const PRUnichar * aFirstName) = 0;

  /* attribute wstring lastName; */
  NS_IMETHOD GetLastName(PRUnichar * *aLastName) = 0;
  NS_IMETHOD SetLastName(const PRUnichar * aLastName) = 0;

  /* attribute wstring displayName; */
  NS_IMETHOD GetDisplayName(PRUnichar * *aDisplayName) = 0;
  NS_IMETHOD SetDisplayName(const PRUnichar * aDisplayName) = 0;

  /* attribute wstring nickName; */
  NS_IMETHOD GetNickName(PRUnichar * *aNickName) = 0;
  NS_IMETHOD SetNickName(const PRUnichar * aNickName) = 0;

  /* attribute wstring primaryEmail; */
  NS_IMETHOD GetPrimaryEmail(PRUnichar * *aPrimaryEmail) = 0;
  NS_IMETHOD SetPrimaryEmail(const PRUnichar * aPrimaryEmail) = 0;

  /* attribute wstring secondEmail; */
  NS_IMETHOD GetSecondEmail(PRUnichar * *aSecondEmail) = 0;
  NS_IMETHOD SetSecondEmail(const PRUnichar * aSecondEmail) = 0;

  /* attribute wstring workPhone; */
  NS_IMETHOD GetWorkPhone(PRUnichar * *aWorkPhone) = 0;
  NS_IMETHOD SetWorkPhone(const PRUnichar * aWorkPhone) = 0;

  /* attribute wstring homePhone; */
  NS_IMETHOD GetHomePhone(PRUnichar * *aHomePhone) = 0;
  NS_IMETHOD SetHomePhone(const PRUnichar * aHomePhone) = 0;

  /* attribute wstring faxNumber; */
  NS_IMETHOD GetFaxNumber(PRUnichar * *aFaxNumber) = 0;
  NS_IMETHOD SetFaxNumber(const PRUnichar * aFaxNumber) = 0;

  /* attribute wstring pagerNumber; */
  NS_IMETHOD GetPagerNumber(PRUnichar * *aPagerNumber) = 0;
  NS_IMETHOD SetPagerNumber(const PRUnichar * aPagerNumber) = 0;

  /* attribute wstring cellularNumber; */
  NS_IMETHOD GetCellularNumber(PRUnichar * *aCellularNumber) = 0;
  NS_IMETHOD SetCellularNumber(const PRUnichar * aCellularNumber) = 0;

  /* attribute wstring homeAddress; */
  NS_IMETHOD GetHomeAddress(PRUnichar * *aHomeAddress) = 0;
  NS_IMETHOD SetHomeAddress(const PRUnichar * aHomeAddress) = 0;

  /* attribute wstring homeAddress2; */
  NS_IMETHOD GetHomeAddress2(PRUnichar * *aHomeAddress2) = 0;
  NS_IMETHOD SetHomeAddress2(const PRUnichar * aHomeAddress2) = 0;

  /* attribute wstring homeCity; */
  NS_IMETHOD GetHomeCity(PRUnichar * *aHomeCity) = 0;
  NS_IMETHOD SetHomeCity(const PRUnichar * aHomeCity) = 0;

  /* attribute wstring homeState; */
  NS_IMETHOD GetHomeState(PRUnichar * *aHomeState) = 0;
  NS_IMETHOD SetHomeState(const PRUnichar * aHomeState) = 0;

  /* attribute wstring homeZipCode; */
  NS_IMETHOD GetHomeZipCode(PRUnichar * *aHomeZipCode) = 0;
  NS_IMETHOD SetHomeZipCode(const PRUnichar * aHomeZipCode) = 0;

  /* attribute wstring homeCountry; */
  NS_IMETHOD GetHomeCountry(PRUnichar * *aHomeCountry) = 0;
  NS_IMETHOD SetHomeCountry(const PRUnichar * aHomeCountry) = 0;

  /* attribute wstring workAddress; */
  NS_IMETHOD GetWorkAddress(PRUnichar * *aWorkAddress) = 0;
  NS_IMETHOD SetWorkAddress(const PRUnichar * aWorkAddress) = 0;

  /* attribute wstring workAddress2; */
  NS_IMETHOD GetWorkAddress2(PRUnichar * *aWorkAddress2) = 0;
  NS_IMETHOD SetWorkAddress2(const PRUnichar * aWorkAddress2) = 0;

  /* attribute wstring workCity; */
  NS_IMETHOD GetWorkCity(PRUnichar * *aWorkCity) = 0;
  NS_IMETHOD SetWorkCity(const PRUnichar * aWorkCity) = 0;

  /* attribute wstring workState; */
  NS_IMETHOD GetWorkState(PRUnichar * *aWorkState) = 0;
  NS_IMETHOD SetWorkState(const PRUnichar * aWorkState) = 0;

  /* attribute wstring workZipCode; */
  NS_IMETHOD GetWorkZipCode(PRUnichar * *aWorkZipCode) = 0;
  NS_IMETHOD SetWorkZipCode(const PRUnichar * aWorkZipCode) = 0;

  /* attribute wstring workCountry; */
  NS_IMETHOD GetWorkCountry(PRUnichar * *aWorkCountry) = 0;
  NS_IMETHOD SetWorkCountry(const PRUnichar * aWorkCountry) = 0;

  /* attribute wstring jobTitle; */
  NS_IMETHOD GetJobTitle(PRUnichar * *aJobTitle) = 0;
  NS_IMETHOD SetJobTitle(const PRUnichar * aJobTitle) = 0;

  /* attribute wstring department; */
  NS_IMETHOD GetDepartment(PRUnichar * *aDepartment) = 0;
  NS_IMETHOD SetDepartment(const PRUnichar * aDepartment) = 0;

  /* attribute wstring company; */
  NS_IMETHOD GetCompany(PRUnichar * *aCompany) = 0;
  NS_IMETHOD SetCompany(const PRUnichar * aCompany) = 0;

  /* attribute wstring webPage1; */
  NS_IMETHOD GetWebPage1(PRUnichar * *aWebPage1) = 0;
  NS_IMETHOD SetWebPage1(const PRUnichar * aWebPage1) = 0;

  /* attribute wstring webPage2; */
  NS_IMETHOD GetWebPage2(PRUnichar * *aWebPage2) = 0;
  NS_IMETHOD SetWebPage2(const PRUnichar * aWebPage2) = 0;

  /* attribute wstring birthYear; */
  NS_IMETHOD GetBirthYear(PRUnichar * *aBirthYear) = 0;
  NS_IMETHOD SetBirthYear(const PRUnichar * aBirthYear) = 0;

  /* attribute wstring birthMonth; */
  NS_IMETHOD GetBirthMonth(PRUnichar * *aBirthMonth) = 0;
  NS_IMETHOD SetBirthMonth(const PRUnichar * aBirthMonth) = 0;

  /* attribute wstring birthDay; */
  NS_IMETHOD GetBirthDay(PRUnichar * *aBirthDay) = 0;
  NS_IMETHOD SetBirthDay(const PRUnichar * aBirthDay) = 0;

  /* attribute wstring custom1; */
  NS_IMETHOD GetCustom1(PRUnichar * *aCustom1) = 0;
  NS_IMETHOD SetCustom1(const PRUnichar * aCustom1) = 0;

  /* attribute wstring custom2; */
  NS_IMETHOD GetCustom2(PRUnichar * *aCustom2) = 0;
  NS_IMETHOD SetCustom2(const PRUnichar * aCustom2) = 0;

  /* attribute wstring custom3; */
  NS_IMETHOD GetCustom3(PRUnichar * *aCustom3) = 0;
  NS_IMETHOD SetCustom3(const PRUnichar * aCustom3) = 0;

  /* attribute wstring custom4; */
  NS_IMETHOD GetCustom4(PRUnichar * *aCustom4) = 0;
  NS_IMETHOD SetCustom4(const PRUnichar * aCustom4) = 0;

  /* attribute wstring notes; */
  NS_IMETHOD GetNotes(PRUnichar * *aNotes) = 0;
  NS_IMETHOD SetNotes(const PRUnichar * aNotes) = 0;

  /* attribute unsigned long lastModifiedDate; */
  NS_IMETHOD GetLastModifiedDate(PRUint32 *aLastModifiedDate) = 0;
  NS_IMETHOD SetLastModifiedDate(PRUint32 aLastModifiedDate) = 0;

  /* attribute wstring name; */
  NS_IMETHOD GetName(PRUnichar * *aName) = 0;
  NS_IMETHOD SetName(const PRUnichar * aName) = 0;

  /* attribute unsigned long preferMailFormat; */
  NS_IMETHOD GetPreferMailFormat(PRUint32 *aPreferMailFormat) = 0;
  NS_IMETHOD SetPreferMailFormat(PRUint32 aPreferMailFormat) = 0;

  /* attribute boolean isMailList; */
  NS_IMETHOD GetIsMailList(PRBool *aIsMailList) = 0;
  NS_IMETHOD SetIsMailList(PRBool aIsMailList) = 0;

  /* attribute string mailListURI; */
  NS_IMETHOD GetMailListURI(char * *aMailListURI) = 0;
  NS_IMETHOD SetMailListURI(const char * aMailListURI) = 0;

  /* wstring getCardValue (in string attrname); */
  NS_IMETHOD GetCardValue(const char *attrname, PRUnichar **_retval) = 0;

  /* void setCardValue (in string attrname, in wstring value); */
  NS_IMETHOD SetCardValue(const char *attrname, const PRUnichar *value) = 0;

  /* void copy (in nsIAbCard srcCard); */
  NS_IMETHOD Copy(nsIAbCard *srcCard) = 0;

  /* readonly attribute string printCardUrl; */
  NS_IMETHOD GetPrintCardUrl(char * *aPrintCardUrl) = 0;

  /* nsIAbCard addCardToDatabase (in string uri); */
  NS_IMETHOD AddCardToDatabase(const char *uri, nsIAbCard **_retval) = 0;

  /* nsIAbCard dropCardToDatabase (in string uri); */
  NS_IMETHOD DropCardToDatabase(const char *uri, nsIAbCard **_retval) = 0;

  /* void editCardToDatabase (in string uri); */
  NS_IMETHOD EditCardToDatabase(const char *uri) = 0;

  /* wstring getCollationKey (in wstring str); */
  NS_IMETHOD GetCollationKey(const PRUnichar *str, PRUnichar **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABCARD \
  NS_IMETHOD GetFirstName(PRUnichar * *aFirstName); \
  NS_IMETHOD SetFirstName(const PRUnichar * aFirstName); \
  NS_IMETHOD GetLastName(PRUnichar * *aLastName); \
  NS_IMETHOD SetLastName(const PRUnichar * aLastName); \
  NS_IMETHOD GetDisplayName(PRUnichar * *aDisplayName); \
  NS_IMETHOD SetDisplayName(const PRUnichar * aDisplayName); \
  NS_IMETHOD GetNickName(PRUnichar * *aNickName); \
  NS_IMETHOD SetNickName(const PRUnichar * aNickName); \
  NS_IMETHOD GetPrimaryEmail(PRUnichar * *aPrimaryEmail); \
  NS_IMETHOD SetPrimaryEmail(const PRUnichar * aPrimaryEmail); \
  NS_IMETHOD GetSecondEmail(PRUnichar * *aSecondEmail); \
  NS_IMETHOD SetSecondEmail(const PRUnichar * aSecondEmail); \
  NS_IMETHOD GetWorkPhone(PRUnichar * *aWorkPhone); \
  NS_IMETHOD SetWorkPhone(const PRUnichar * aWorkPhone); \
  NS_IMETHOD GetHomePhone(PRUnichar * *aHomePhone); \
  NS_IMETHOD SetHomePhone(const PRUnichar * aHomePhone); \
  NS_IMETHOD GetFaxNumber(PRUnichar * *aFaxNumber); \
  NS_IMETHOD SetFaxNumber(const PRUnichar * aFaxNumber); \
  NS_IMETHOD GetPagerNumber(PRUnichar * *aPagerNumber); \
  NS_IMETHOD SetPagerNumber(const PRUnichar * aPagerNumber); \
  NS_IMETHOD GetCellularNumber(PRUnichar * *aCellularNumber); \
  NS_IMETHOD SetCellularNumber(const PRUnichar * aCellularNumber); \
  NS_IMETHOD GetHomeAddress(PRUnichar * *aHomeAddress); \
  NS_IMETHOD SetHomeAddress(const PRUnichar * aHomeAddress); \
  NS_IMETHOD GetHomeAddress2(PRUnichar * *aHomeAddress2); \
  NS_IMETHOD SetHomeAddress2(const PRUnichar * aHomeAddress2); \
  NS_IMETHOD GetHomeCity(PRUnichar * *aHomeCity); \
  NS_IMETHOD SetHomeCity(const PRUnichar * aHomeCity); \
  NS_IMETHOD GetHomeState(PRUnichar * *aHomeState); \
  NS_IMETHOD SetHomeState(const PRUnichar * aHomeState); \
  NS_IMETHOD GetHomeZipCode(PRUnichar * *aHomeZipCode); \
  NS_IMETHOD SetHomeZipCode(const PRUnichar * aHomeZipCode); \
  NS_IMETHOD GetHomeCountry(PRUnichar * *aHomeCountry); \
  NS_IMETHOD SetHomeCountry(const PRUnichar * aHomeCountry); \
  NS_IMETHOD GetWorkAddress(PRUnichar * *aWorkAddress); \
  NS_IMETHOD SetWorkAddress(const PRUnichar * aWorkAddress); \
  NS_IMETHOD GetWorkAddress2(PRUnichar * *aWorkAddress2); \
  NS_IMETHOD SetWorkAddress2(const PRUnichar * aWorkAddress2); \
  NS_IMETHOD GetWorkCity(PRUnichar * *aWorkCity); \
  NS_IMETHOD SetWorkCity(const PRUnichar * aWorkCity); \
  NS_IMETHOD GetWorkState(PRUnichar * *aWorkState); \
  NS_IMETHOD SetWorkState(const PRUnichar * aWorkState); \
  NS_IMETHOD GetWorkZipCode(PRUnichar * *aWorkZipCode); \
  NS_IMETHOD SetWorkZipCode(const PRUnichar * aWorkZipCode); \
  NS_IMETHOD GetWorkCountry(PRUnichar * *aWorkCountry); \
  NS_IMETHOD SetWorkCountry(const PRUnichar * aWorkCountry); \
  NS_IMETHOD GetJobTitle(PRUnichar * *aJobTitle); \
  NS_IMETHOD SetJobTitle(const PRUnichar * aJobTitle); \
  NS_IMETHOD GetDepartment(PRUnichar * *aDepartment); \
  NS_IMETHOD SetDepartment(const PRUnichar * aDepartment); \
  NS_IMETHOD GetCompany(PRUnichar * *aCompany); \
  NS_IMETHOD SetCompany(const PRUnichar * aCompany); \
  NS_IMETHOD GetWebPage1(PRUnichar * *aWebPage1); \
  NS_IMETHOD SetWebPage1(const PRUnichar * aWebPage1); \
  NS_IMETHOD GetWebPage2(PRUnichar * *aWebPage2); \
  NS_IMETHOD SetWebPage2(const PRUnichar * aWebPage2); \
  NS_IMETHOD GetBirthYear(PRUnichar * *aBirthYear); \
  NS_IMETHOD SetBirthYear(const PRUnichar * aBirthYear); \
  NS_IMETHOD GetBirthMonth(PRUnichar * *aBirthMonth); \
  NS_IMETHOD SetBirthMonth(const PRUnichar * aBirthMonth); \
  NS_IMETHOD GetBirthDay(PRUnichar * *aBirthDay); \
  NS_IMETHOD SetBirthDay(const PRUnichar * aBirthDay); \
  NS_IMETHOD GetCustom1(PRUnichar * *aCustom1); \
  NS_IMETHOD SetCustom1(const PRUnichar * aCustom1); \
  NS_IMETHOD GetCustom2(PRUnichar * *aCustom2); \
  NS_IMETHOD SetCustom2(const PRUnichar * aCustom2); \
  NS_IMETHOD GetCustom3(PRUnichar * *aCustom3); \
  NS_IMETHOD SetCustom3(const PRUnichar * aCustom3); \
  NS_IMETHOD GetCustom4(PRUnichar * *aCustom4); \
  NS_IMETHOD SetCustom4(const PRUnichar * aCustom4); \
  NS_IMETHOD GetNotes(PRUnichar * *aNotes); \
  NS_IMETHOD SetNotes(const PRUnichar * aNotes); \
  NS_IMETHOD GetLastModifiedDate(PRUint32 *aLastModifiedDate); \
  NS_IMETHOD SetLastModifiedDate(PRUint32 aLastModifiedDate); \
  NS_IMETHOD GetName(PRUnichar * *aName); \
  NS_IMETHOD SetName(const PRUnichar * aName); \
  NS_IMETHOD GetPreferMailFormat(PRUint32 *aPreferMailFormat); \
  NS_IMETHOD SetPreferMailFormat(PRUint32 aPreferMailFormat); \
  NS_IMETHOD GetIsMailList(PRBool *aIsMailList); \
  NS_IMETHOD SetIsMailList(PRBool aIsMailList); \
  NS_IMETHOD GetMailListURI(char * *aMailListURI); \
  NS_IMETHOD SetMailListURI(const char * aMailListURI); \
  NS_IMETHOD GetCardValue(const char *attrname, PRUnichar **_retval); \
  NS_IMETHOD SetCardValue(const char *attrname, const PRUnichar *value); \
  NS_IMETHOD Copy(nsIAbCard *srcCard); \
  NS_IMETHOD GetPrintCardUrl(char * *aPrintCardUrl); \
  NS_IMETHOD AddCardToDatabase(const char *uri, nsIAbCard **_retval); \
  NS_IMETHOD DropCardToDatabase(const char *uri, nsIAbCard **_retval); \
  NS_IMETHOD EditCardToDatabase(const char *uri); \
  NS_IMETHOD GetCollationKey(const PRUnichar *str, PRUnichar **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABCARD(_to) \
  NS_IMETHOD GetFirstName(PRUnichar * *aFirstName) { return _to GetFirstName(aFirstName); } \
  NS_IMETHOD SetFirstName(const PRUnichar * aFirstName) { return _to SetFirstName(aFirstName); } \
  NS_IMETHOD GetLastName(PRUnichar * *aLastName) { return _to GetLastName(aLastName); } \
  NS_IMETHOD SetLastName(const PRUnichar * aLastName) { return _to SetLastName(aLastName); } \
  NS_IMETHOD GetDisplayName(PRUnichar * *aDisplayName) { return _to GetDisplayName(aDisplayName); } \
  NS_IMETHOD SetDisplayName(const PRUnichar * aDisplayName) { return _to SetDisplayName(aDisplayName); } \
  NS_IMETHOD GetNickName(PRUnichar * *aNickName) { return _to GetNickName(aNickName); } \
  NS_IMETHOD SetNickName(const PRUnichar * aNickName) { return _to SetNickName(aNickName); } \
  NS_IMETHOD GetPrimaryEmail(PRUnichar * *aPrimaryEmail) { return _to GetPrimaryEmail(aPrimaryEmail); } \
  NS_IMETHOD SetPrimaryEmail(const PRUnichar * aPrimaryEmail) { return _to SetPrimaryEmail(aPrimaryEmail); } \
  NS_IMETHOD GetSecondEmail(PRUnichar * *aSecondEmail) { return _to GetSecondEmail(aSecondEmail); } \
  NS_IMETHOD SetSecondEmail(const PRUnichar * aSecondEmail) { return _to SetSecondEmail(aSecondEmail); } \
  NS_IMETHOD GetWorkPhone(PRUnichar * *aWorkPhone) { return _to GetWorkPhone(aWorkPhone); } \
  NS_IMETHOD SetWorkPhone(const PRUnichar * aWorkPhone) { return _to SetWorkPhone(aWorkPhone); } \
  NS_IMETHOD GetHomePhone(PRUnichar * *aHomePhone) { return _to GetHomePhone(aHomePhone); } \
  NS_IMETHOD SetHomePhone(const PRUnichar * aHomePhone) { return _to SetHomePhone(aHomePhone); } \
  NS_IMETHOD GetFaxNumber(PRUnichar * *aFaxNumber) { return _to GetFaxNumber(aFaxNumber); } \
  NS_IMETHOD SetFaxNumber(const PRUnichar * aFaxNumber) { return _to SetFaxNumber(aFaxNumber); } \
  NS_IMETHOD GetPagerNumber(PRUnichar * *aPagerNumber) { return _to GetPagerNumber(aPagerNumber); } \
  NS_IMETHOD SetPagerNumber(const PRUnichar * aPagerNumber) { return _to SetPagerNumber(aPagerNumber); } \
  NS_IMETHOD GetCellularNumber(PRUnichar * *aCellularNumber) { return _to GetCellularNumber(aCellularNumber); } \
  NS_IMETHOD SetCellularNumber(const PRUnichar * aCellularNumber) { return _to SetCellularNumber(aCellularNumber); } \
  NS_IMETHOD GetHomeAddress(PRUnichar * *aHomeAddress) { return _to GetHomeAddress(aHomeAddress); } \
  NS_IMETHOD SetHomeAddress(const PRUnichar * aHomeAddress) { return _to SetHomeAddress(aHomeAddress); } \
  NS_IMETHOD GetHomeAddress2(PRUnichar * *aHomeAddress2) { return _to GetHomeAddress2(aHomeAddress2); } \
  NS_IMETHOD SetHomeAddress2(const PRUnichar * aHomeAddress2) { return _to SetHomeAddress2(aHomeAddress2); } \
  NS_IMETHOD GetHomeCity(PRUnichar * *aHomeCity) { return _to GetHomeCity(aHomeCity); } \
  NS_IMETHOD SetHomeCity(const PRUnichar * aHomeCity) { return _to SetHomeCity(aHomeCity); } \
  NS_IMETHOD GetHomeState(PRUnichar * *aHomeState) { return _to GetHomeState(aHomeState); } \
  NS_IMETHOD SetHomeState(const PRUnichar * aHomeState) { return _to SetHomeState(aHomeState); } \
  NS_IMETHOD GetHomeZipCode(PRUnichar * *aHomeZipCode) { return _to GetHomeZipCode(aHomeZipCode); } \
  NS_IMETHOD SetHomeZipCode(const PRUnichar * aHomeZipCode) { return _to SetHomeZipCode(aHomeZipCode); } \
  NS_IMETHOD GetHomeCountry(PRUnichar * *aHomeCountry) { return _to GetHomeCountry(aHomeCountry); } \
  NS_IMETHOD SetHomeCountry(const PRUnichar * aHomeCountry) { return _to SetHomeCountry(aHomeCountry); } \
  NS_IMETHOD GetWorkAddress(PRUnichar * *aWorkAddress) { return _to GetWorkAddress(aWorkAddress); } \
  NS_IMETHOD SetWorkAddress(const PRUnichar * aWorkAddress) { return _to SetWorkAddress(aWorkAddress); } \
  NS_IMETHOD GetWorkAddress2(PRUnichar * *aWorkAddress2) { return _to GetWorkAddress2(aWorkAddress2); } \
  NS_IMETHOD SetWorkAddress2(const PRUnichar * aWorkAddress2) { return _to SetWorkAddress2(aWorkAddress2); } \
  NS_IMETHOD GetWorkCity(PRUnichar * *aWorkCity) { return _to GetWorkCity(aWorkCity); } \
  NS_IMETHOD SetWorkCity(const PRUnichar * aWorkCity) { return _to SetWorkCity(aWorkCity); } \
  NS_IMETHOD GetWorkState(PRUnichar * *aWorkState) { return _to GetWorkState(aWorkState); } \
  NS_IMETHOD SetWorkState(const PRUnichar * aWorkState) { return _to SetWorkState(aWorkState); } \
  NS_IMETHOD GetWorkZipCode(PRUnichar * *aWorkZipCode) { return _to GetWorkZipCode(aWorkZipCode); } \
  NS_IMETHOD SetWorkZipCode(const PRUnichar * aWorkZipCode) { return _to SetWorkZipCode(aWorkZipCode); } \
  NS_IMETHOD GetWorkCountry(PRUnichar * *aWorkCountry) { return _to GetWorkCountry(aWorkCountry); } \
  NS_IMETHOD SetWorkCountry(const PRUnichar * aWorkCountry) { return _to SetWorkCountry(aWorkCountry); } \
  NS_IMETHOD GetJobTitle(PRUnichar * *aJobTitle) { return _to GetJobTitle(aJobTitle); } \
  NS_IMETHOD SetJobTitle(const PRUnichar * aJobTitle) { return _to SetJobTitle(aJobTitle); } \
  NS_IMETHOD GetDepartment(PRUnichar * *aDepartment) { return _to GetDepartment(aDepartment); } \
  NS_IMETHOD SetDepartment(const PRUnichar * aDepartment) { return _to SetDepartment(aDepartment); } \
  NS_IMETHOD GetCompany(PRUnichar * *aCompany) { return _to GetCompany(aCompany); } \
  NS_IMETHOD SetCompany(const PRUnichar * aCompany) { return _to SetCompany(aCompany); } \
  NS_IMETHOD GetWebPage1(PRUnichar * *aWebPage1) { return _to GetWebPage1(aWebPage1); } \
  NS_IMETHOD SetWebPage1(const PRUnichar * aWebPage1) { return _to SetWebPage1(aWebPage1); } \
  NS_IMETHOD GetWebPage2(PRUnichar * *aWebPage2) { return _to GetWebPage2(aWebPage2); } \
  NS_IMETHOD SetWebPage2(const PRUnichar * aWebPage2) { return _to SetWebPage2(aWebPage2); } \
  NS_IMETHOD GetBirthYear(PRUnichar * *aBirthYear) { return _to GetBirthYear(aBirthYear); } \
  NS_IMETHOD SetBirthYear(const PRUnichar * aBirthYear) { return _to SetBirthYear(aBirthYear); } \
  NS_IMETHOD GetBirthMonth(PRUnichar * *aBirthMonth) { return _to GetBirthMonth(aBirthMonth); } \
  NS_IMETHOD SetBirthMonth(const PRUnichar * aBirthMonth) { return _to SetBirthMonth(aBirthMonth); } \
  NS_IMETHOD GetBirthDay(PRUnichar * *aBirthDay) { return _to GetBirthDay(aBirthDay); } \
  NS_IMETHOD SetBirthDay(const PRUnichar * aBirthDay) { return _to SetBirthDay(aBirthDay); } \
  NS_IMETHOD GetCustom1(PRUnichar * *aCustom1) { return _to GetCustom1(aCustom1); } \
  NS_IMETHOD SetCustom1(const PRUnichar * aCustom1) { return _to SetCustom1(aCustom1); } \
  NS_IMETHOD GetCustom2(PRUnichar * *aCustom2) { return _to GetCustom2(aCustom2); } \
  NS_IMETHOD SetCustom2(const PRUnichar * aCustom2) { return _to SetCustom2(aCustom2); } \
  NS_IMETHOD GetCustom3(PRUnichar * *aCustom3) { return _to GetCustom3(aCustom3); } \
  NS_IMETHOD SetCustom3(const PRUnichar * aCustom3) { return _to SetCustom3(aCustom3); } \
  NS_IMETHOD GetCustom4(PRUnichar * *aCustom4) { return _to GetCustom4(aCustom4); } \
  NS_IMETHOD SetCustom4(const PRUnichar * aCustom4) { return _to SetCustom4(aCustom4); } \
  NS_IMETHOD GetNotes(PRUnichar * *aNotes) { return _to GetNotes(aNotes); } \
  NS_IMETHOD SetNotes(const PRUnichar * aNotes) { return _to SetNotes(aNotes); } \
  NS_IMETHOD GetLastModifiedDate(PRUint32 *aLastModifiedDate) { return _to GetLastModifiedDate(aLastModifiedDate); } \
  NS_IMETHOD SetLastModifiedDate(PRUint32 aLastModifiedDate) { return _to SetLastModifiedDate(aLastModifiedDate); } \
  NS_IMETHOD GetName(PRUnichar * *aName) { return _to GetName(aName); } \
  NS_IMETHOD SetName(const PRUnichar * aName) { return _to SetName(aName); } \
  NS_IMETHOD GetPreferMailFormat(PRUint32 *aPreferMailFormat) { return _to GetPreferMailFormat(aPreferMailFormat); } \
  NS_IMETHOD SetPreferMailFormat(PRUint32 aPreferMailFormat) { return _to SetPreferMailFormat(aPreferMailFormat); } \
  NS_IMETHOD GetIsMailList(PRBool *aIsMailList) { return _to GetIsMailList(aIsMailList); } \
  NS_IMETHOD SetIsMailList(PRBool aIsMailList) { return _to SetIsMailList(aIsMailList); } \
  NS_IMETHOD GetMailListURI(char * *aMailListURI) { return _to GetMailListURI(aMailListURI); } \
  NS_IMETHOD SetMailListURI(const char * aMailListURI) { return _to SetMailListURI(aMailListURI); } \
  NS_IMETHOD GetCardValue(const char *attrname, PRUnichar **_retval) { return _to GetCardValue(attrname, _retval); } \
  NS_IMETHOD SetCardValue(const char *attrname, const PRUnichar *value) { return _to SetCardValue(attrname, value); } \
  NS_IMETHOD Copy(nsIAbCard *srcCard) { return _to Copy(srcCard); } \
  NS_IMETHOD GetPrintCardUrl(char * *aPrintCardUrl) { return _to GetPrintCardUrl(aPrintCardUrl); } \
  NS_IMETHOD AddCardToDatabase(const char *uri, nsIAbCard **_retval) { return _to AddCardToDatabase(uri, _retval); } \
  NS_IMETHOD DropCardToDatabase(const char *uri, nsIAbCard **_retval) { return _to DropCardToDatabase(uri, _retval); } \
  NS_IMETHOD EditCardToDatabase(const char *uri) { return _to EditCardToDatabase(uri); } \
  NS_IMETHOD GetCollationKey(const PRUnichar *str, PRUnichar **_retval) { return _to GetCollationKey(str, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABCARD(_to) \
  NS_IMETHOD GetFirstName(PRUnichar * *aFirstName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetFirstName(aFirstName); } \
  NS_IMETHOD SetFirstName(const PRUnichar * aFirstName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetFirstName(aFirstName); } \
  NS_IMETHOD GetLastName(PRUnichar * *aLastName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetLastName(aLastName); } \
  NS_IMETHOD SetLastName(const PRUnichar * aLastName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetLastName(aLastName); } \
  NS_IMETHOD GetDisplayName(PRUnichar * *aDisplayName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDisplayName(aDisplayName); } \
  NS_IMETHOD SetDisplayName(const PRUnichar * aDisplayName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDisplayName(aDisplayName); } \
  NS_IMETHOD GetNickName(PRUnichar * *aNickName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetNickName(aNickName); } \
  NS_IMETHOD SetNickName(const PRUnichar * aNickName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetNickName(aNickName); } \
  NS_IMETHOD GetPrimaryEmail(PRUnichar * *aPrimaryEmail) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPrimaryEmail(aPrimaryEmail); } \
  NS_IMETHOD SetPrimaryEmail(const PRUnichar * aPrimaryEmail) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPrimaryEmail(aPrimaryEmail); } \
  NS_IMETHOD GetSecondEmail(PRUnichar * *aSecondEmail) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSecondEmail(aSecondEmail); } \
  NS_IMETHOD SetSecondEmail(const PRUnichar * aSecondEmail) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetSecondEmail(aSecondEmail); } \
  NS_IMETHOD GetWorkPhone(PRUnichar * *aWorkPhone) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWorkPhone(aWorkPhone); } \
  NS_IMETHOD SetWorkPhone(const PRUnichar * aWorkPhone) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWorkPhone(aWorkPhone); } \
  NS_IMETHOD GetHomePhone(PRUnichar * *aHomePhone) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetHomePhone(aHomePhone); } \
  NS_IMETHOD SetHomePhone(const PRUnichar * aHomePhone) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetHomePhone(aHomePhone); } \
  NS_IMETHOD GetFaxNumber(PRUnichar * *aFaxNumber) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetFaxNumber(aFaxNumber); } \
  NS_IMETHOD SetFaxNumber(const PRUnichar * aFaxNumber) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetFaxNumber(aFaxNumber); } \
  NS_IMETHOD GetPagerNumber(PRUnichar * *aPagerNumber) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPagerNumber(aPagerNumber); } \
  NS_IMETHOD SetPagerNumber(const PRUnichar * aPagerNumber) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPagerNumber(aPagerNumber); } \
  NS_IMETHOD GetCellularNumber(PRUnichar * *aCellularNumber) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCellularNumber(aCellularNumber); } \
  NS_IMETHOD SetCellularNumber(const PRUnichar * aCellularNumber) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCellularNumber(aCellularNumber); } \
  NS_IMETHOD GetHomeAddress(PRUnichar * *aHomeAddress) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetHomeAddress(aHomeAddress); } \
  NS_IMETHOD SetHomeAddress(const PRUnichar * aHomeAddress) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetHomeAddress(aHomeAddress); } \
  NS_IMETHOD GetHomeAddress2(PRUnichar * *aHomeAddress2) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetHomeAddress2(aHomeAddress2); } \
  NS_IMETHOD SetHomeAddress2(const PRUnichar * aHomeAddress2) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetHomeAddress2(aHomeAddress2); } \
  NS_IMETHOD GetHomeCity(PRUnichar * *aHomeCity) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetHomeCity(aHomeCity); } \
  NS_IMETHOD SetHomeCity(const PRUnichar * aHomeCity) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetHomeCity(aHomeCity); } \
  NS_IMETHOD GetHomeState(PRUnichar * *aHomeState) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetHomeState(aHomeState); } \
  NS_IMETHOD SetHomeState(const PRUnichar * aHomeState) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetHomeState(aHomeState); } \
  NS_IMETHOD GetHomeZipCode(PRUnichar * *aHomeZipCode) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetHomeZipCode(aHomeZipCode); } \
  NS_IMETHOD SetHomeZipCode(const PRUnichar * aHomeZipCode) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetHomeZipCode(aHomeZipCode); } \
  NS_IMETHOD GetHomeCountry(PRUnichar * *aHomeCountry) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetHomeCountry(aHomeCountry); } \
  NS_IMETHOD SetHomeCountry(const PRUnichar * aHomeCountry) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetHomeCountry(aHomeCountry); } \
  NS_IMETHOD GetWorkAddress(PRUnichar * *aWorkAddress) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWorkAddress(aWorkAddress); } \
  NS_IMETHOD SetWorkAddress(const PRUnichar * aWorkAddress) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWorkAddress(aWorkAddress); } \
  NS_IMETHOD GetWorkAddress2(PRUnichar * *aWorkAddress2) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWorkAddress2(aWorkAddress2); } \
  NS_IMETHOD SetWorkAddress2(const PRUnichar * aWorkAddress2) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWorkAddress2(aWorkAddress2); } \
  NS_IMETHOD GetWorkCity(PRUnichar * *aWorkCity) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWorkCity(aWorkCity); } \
  NS_IMETHOD SetWorkCity(const PRUnichar * aWorkCity) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWorkCity(aWorkCity); } \
  NS_IMETHOD GetWorkState(PRUnichar * *aWorkState) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWorkState(aWorkState); } \
  NS_IMETHOD SetWorkState(const PRUnichar * aWorkState) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWorkState(aWorkState); } \
  NS_IMETHOD GetWorkZipCode(PRUnichar * *aWorkZipCode) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWorkZipCode(aWorkZipCode); } \
  NS_IMETHOD SetWorkZipCode(const PRUnichar * aWorkZipCode) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWorkZipCode(aWorkZipCode); } \
  NS_IMETHOD GetWorkCountry(PRUnichar * *aWorkCountry) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWorkCountry(aWorkCountry); } \
  NS_IMETHOD SetWorkCountry(const PRUnichar * aWorkCountry) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWorkCountry(aWorkCountry); } \
  NS_IMETHOD GetJobTitle(PRUnichar * *aJobTitle) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetJobTitle(aJobTitle); } \
  NS_IMETHOD SetJobTitle(const PRUnichar * aJobTitle) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetJobTitle(aJobTitle); } \
  NS_IMETHOD GetDepartment(PRUnichar * *aDepartment) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDepartment(aDepartment); } \
  NS_IMETHOD SetDepartment(const PRUnichar * aDepartment) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDepartment(aDepartment); } \
  NS_IMETHOD GetCompany(PRUnichar * *aCompany) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCompany(aCompany); } \
  NS_IMETHOD SetCompany(const PRUnichar * aCompany) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCompany(aCompany); } \
  NS_IMETHOD GetWebPage1(PRUnichar * *aWebPage1) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWebPage1(aWebPage1); } \
  NS_IMETHOD SetWebPage1(const PRUnichar * aWebPage1) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWebPage1(aWebPage1); } \
  NS_IMETHOD GetWebPage2(PRUnichar * *aWebPage2) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWebPage2(aWebPage2); } \
  NS_IMETHOD SetWebPage2(const PRUnichar * aWebPage2) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWebPage2(aWebPage2); } \
  NS_IMETHOD GetBirthYear(PRUnichar * *aBirthYear) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBirthYear(aBirthYear); } \
  NS_IMETHOD SetBirthYear(const PRUnichar * aBirthYear) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBirthYear(aBirthYear); } \
  NS_IMETHOD GetBirthMonth(PRUnichar * *aBirthMonth) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBirthMonth(aBirthMonth); } \
  NS_IMETHOD SetBirthMonth(const PRUnichar * aBirthMonth) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBirthMonth(aBirthMonth); } \
  NS_IMETHOD GetBirthDay(PRUnichar * *aBirthDay) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBirthDay(aBirthDay); } \
  NS_IMETHOD SetBirthDay(const PRUnichar * aBirthDay) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBirthDay(aBirthDay); } \
  NS_IMETHOD GetCustom1(PRUnichar * *aCustom1) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCustom1(aCustom1); } \
  NS_IMETHOD SetCustom1(const PRUnichar * aCustom1) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCustom1(aCustom1); } \
  NS_IMETHOD GetCustom2(PRUnichar * *aCustom2) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCustom2(aCustom2); } \
  NS_IMETHOD SetCustom2(const PRUnichar * aCustom2) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCustom2(aCustom2); } \
  NS_IMETHOD GetCustom3(PRUnichar * *aCustom3) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCustom3(aCustom3); } \
  NS_IMETHOD SetCustom3(const PRUnichar * aCustom3) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCustom3(aCustom3); } \
  NS_IMETHOD GetCustom4(PRUnichar * *aCustom4) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCustom4(aCustom4); } \
  NS_IMETHOD SetCustom4(const PRUnichar * aCustom4) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCustom4(aCustom4); } \
  NS_IMETHOD GetNotes(PRUnichar * *aNotes) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetNotes(aNotes); } \
  NS_IMETHOD SetNotes(const PRUnichar * aNotes) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetNotes(aNotes); } \
  NS_IMETHOD GetLastModifiedDate(PRUint32 *aLastModifiedDate) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetLastModifiedDate(aLastModifiedDate); } \
  NS_IMETHOD SetLastModifiedDate(PRUint32 aLastModifiedDate) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetLastModifiedDate(aLastModifiedDate); } \
  NS_IMETHOD GetName(PRUnichar * *aName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetName(aName); } \
  NS_IMETHOD SetName(const PRUnichar * aName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetName(aName); } \
  NS_IMETHOD GetPreferMailFormat(PRUint32 *aPreferMailFormat) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPreferMailFormat(aPreferMailFormat); } \
  NS_IMETHOD SetPreferMailFormat(PRUint32 aPreferMailFormat) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPreferMailFormat(aPreferMailFormat); } \
  NS_IMETHOD GetIsMailList(PRBool *aIsMailList) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsMailList(aIsMailList); } \
  NS_IMETHOD SetIsMailList(PRBool aIsMailList) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetIsMailList(aIsMailList); } \
  NS_IMETHOD GetMailListURI(char * *aMailListURI) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetMailListURI(aMailListURI); } \
  NS_IMETHOD SetMailListURI(const char * aMailListURI) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetMailListURI(aMailListURI); } \
  NS_IMETHOD GetCardValue(const char *attrname, PRUnichar **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCardValue(attrname, _retval); } \
  NS_IMETHOD SetCardValue(const char *attrname, const PRUnichar *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCardValue(attrname, value); } \
  NS_IMETHOD Copy(nsIAbCard *srcCard) { return !_to ? NS_ERROR_NULL_POINTER : _to->Copy(srcCard); } \
  NS_IMETHOD GetPrintCardUrl(char * *aPrintCardUrl) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPrintCardUrl(aPrintCardUrl); } \
  NS_IMETHOD AddCardToDatabase(const char *uri, nsIAbCard **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddCardToDatabase(uri, _retval); } \
  NS_IMETHOD DropCardToDatabase(const char *uri, nsIAbCard **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->DropCardToDatabase(uri, _retval); } \
  NS_IMETHOD EditCardToDatabase(const char *uri) { return !_to ? NS_ERROR_NULL_POINTER : _to->EditCardToDatabase(uri); } \
  NS_IMETHOD GetCollationKey(const PRUnichar *str, PRUnichar **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCollationKey(str, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbCard : public nsIAbCard
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABCARD

  nsAbCard();
  virtual ~nsAbCard();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbCard, nsIAbCard)

nsAbCard::nsAbCard()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAbCard::~nsAbCard()
{
  /* destructor code */
}

/* attribute wstring firstName; */
NS_IMETHODIMP nsAbCard::GetFirstName(PRUnichar * *aFirstName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetFirstName(const PRUnichar * aFirstName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring lastName; */
NS_IMETHODIMP nsAbCard::GetLastName(PRUnichar * *aLastName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetLastName(const PRUnichar * aLastName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring displayName; */
NS_IMETHODIMP nsAbCard::GetDisplayName(PRUnichar * *aDisplayName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetDisplayName(const PRUnichar * aDisplayName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring nickName; */
NS_IMETHODIMP nsAbCard::GetNickName(PRUnichar * *aNickName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetNickName(const PRUnichar * aNickName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring primaryEmail; */
NS_IMETHODIMP nsAbCard::GetPrimaryEmail(PRUnichar * *aPrimaryEmail)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetPrimaryEmail(const PRUnichar * aPrimaryEmail)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring secondEmail; */
NS_IMETHODIMP nsAbCard::GetSecondEmail(PRUnichar * *aSecondEmail)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetSecondEmail(const PRUnichar * aSecondEmail)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring workPhone; */
NS_IMETHODIMP nsAbCard::GetWorkPhone(PRUnichar * *aWorkPhone)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetWorkPhone(const PRUnichar * aWorkPhone)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring homePhone; */
NS_IMETHODIMP nsAbCard::GetHomePhone(PRUnichar * *aHomePhone)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetHomePhone(const PRUnichar * aHomePhone)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring faxNumber; */
NS_IMETHODIMP nsAbCard::GetFaxNumber(PRUnichar * *aFaxNumber)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetFaxNumber(const PRUnichar * aFaxNumber)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring pagerNumber; */
NS_IMETHODIMP nsAbCard::GetPagerNumber(PRUnichar * *aPagerNumber)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetPagerNumber(const PRUnichar * aPagerNumber)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring cellularNumber; */
NS_IMETHODIMP nsAbCard::GetCellularNumber(PRUnichar * *aCellularNumber)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetCellularNumber(const PRUnichar * aCellularNumber)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring homeAddress; */
NS_IMETHODIMP nsAbCard::GetHomeAddress(PRUnichar * *aHomeAddress)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetHomeAddress(const PRUnichar * aHomeAddress)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring homeAddress2; */
NS_IMETHODIMP nsAbCard::GetHomeAddress2(PRUnichar * *aHomeAddress2)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetHomeAddress2(const PRUnichar * aHomeAddress2)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring homeCity; */
NS_IMETHODIMP nsAbCard::GetHomeCity(PRUnichar * *aHomeCity)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetHomeCity(const PRUnichar * aHomeCity)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring homeState; */
NS_IMETHODIMP nsAbCard::GetHomeState(PRUnichar * *aHomeState)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetHomeState(const PRUnichar * aHomeState)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring homeZipCode; */
NS_IMETHODIMP nsAbCard::GetHomeZipCode(PRUnichar * *aHomeZipCode)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetHomeZipCode(const PRUnichar * aHomeZipCode)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring homeCountry; */
NS_IMETHODIMP nsAbCard::GetHomeCountry(PRUnichar * *aHomeCountry)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetHomeCountry(const PRUnichar * aHomeCountry)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring workAddress; */
NS_IMETHODIMP nsAbCard::GetWorkAddress(PRUnichar * *aWorkAddress)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetWorkAddress(const PRUnichar * aWorkAddress)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring workAddress2; */
NS_IMETHODIMP nsAbCard::GetWorkAddress2(PRUnichar * *aWorkAddress2)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetWorkAddress2(const PRUnichar * aWorkAddress2)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring workCity; */
NS_IMETHODIMP nsAbCard::GetWorkCity(PRUnichar * *aWorkCity)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetWorkCity(const PRUnichar * aWorkCity)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring workState; */
NS_IMETHODIMP nsAbCard::GetWorkState(PRUnichar * *aWorkState)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetWorkState(const PRUnichar * aWorkState)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring workZipCode; */
NS_IMETHODIMP nsAbCard::GetWorkZipCode(PRUnichar * *aWorkZipCode)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetWorkZipCode(const PRUnichar * aWorkZipCode)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring workCountry; */
NS_IMETHODIMP nsAbCard::GetWorkCountry(PRUnichar * *aWorkCountry)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetWorkCountry(const PRUnichar * aWorkCountry)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring jobTitle; */
NS_IMETHODIMP nsAbCard::GetJobTitle(PRUnichar * *aJobTitle)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetJobTitle(const PRUnichar * aJobTitle)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring department; */
NS_IMETHODIMP nsAbCard::GetDepartment(PRUnichar * *aDepartment)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetDepartment(const PRUnichar * aDepartment)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring company; */
NS_IMETHODIMP nsAbCard::GetCompany(PRUnichar * *aCompany)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetCompany(const PRUnichar * aCompany)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring webPage1; */
NS_IMETHODIMP nsAbCard::GetWebPage1(PRUnichar * *aWebPage1)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetWebPage1(const PRUnichar * aWebPage1)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring webPage2; */
NS_IMETHODIMP nsAbCard::GetWebPage2(PRUnichar * *aWebPage2)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetWebPage2(const PRUnichar * aWebPage2)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring birthYear; */
NS_IMETHODIMP nsAbCard::GetBirthYear(PRUnichar * *aBirthYear)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetBirthYear(const PRUnichar * aBirthYear)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring birthMonth; */
NS_IMETHODIMP nsAbCard::GetBirthMonth(PRUnichar * *aBirthMonth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetBirthMonth(const PRUnichar * aBirthMonth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring birthDay; */
NS_IMETHODIMP nsAbCard::GetBirthDay(PRUnichar * *aBirthDay)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetBirthDay(const PRUnichar * aBirthDay)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring custom1; */
NS_IMETHODIMP nsAbCard::GetCustom1(PRUnichar * *aCustom1)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetCustom1(const PRUnichar * aCustom1)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring custom2; */
NS_IMETHODIMP nsAbCard::GetCustom2(PRUnichar * *aCustom2)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetCustom2(const PRUnichar * aCustom2)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring custom3; */
NS_IMETHODIMP nsAbCard::GetCustom3(PRUnichar * *aCustom3)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetCustom3(const PRUnichar * aCustom3)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring custom4; */
NS_IMETHODIMP nsAbCard::GetCustom4(PRUnichar * *aCustom4)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetCustom4(const PRUnichar * aCustom4)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring notes; */
NS_IMETHODIMP nsAbCard::GetNotes(PRUnichar * *aNotes)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetNotes(const PRUnichar * aNotes)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute unsigned long lastModifiedDate; */
NS_IMETHODIMP nsAbCard::GetLastModifiedDate(PRUint32 *aLastModifiedDate)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetLastModifiedDate(PRUint32 aLastModifiedDate)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring name; */
NS_IMETHODIMP nsAbCard::GetName(PRUnichar * *aName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetName(const PRUnichar * aName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute unsigned long preferMailFormat; */
NS_IMETHODIMP nsAbCard::GetPreferMailFormat(PRUint32 *aPreferMailFormat)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetPreferMailFormat(PRUint32 aPreferMailFormat)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute boolean isMailList; */
NS_IMETHODIMP nsAbCard::GetIsMailList(PRBool *aIsMailList)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetIsMailList(PRBool aIsMailList)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute string mailListURI; */
NS_IMETHODIMP nsAbCard::GetMailListURI(char * *aMailListURI)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetMailListURI(const char * aMailListURI)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* wstring getCardValue (in string attrname); */
NS_IMETHODIMP nsAbCard::GetCardValue(const char *attrname, PRUnichar **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setCardValue (in string attrname, in wstring value); */
NS_IMETHODIMP nsAbCard::SetCardValue(const char *attrname, const PRUnichar *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void copy (in nsIAbCard srcCard); */
NS_IMETHODIMP nsAbCard::Copy(nsIAbCard *srcCard)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute string printCardUrl; */
NS_IMETHODIMP nsAbCard::GetPrintCardUrl(char * *aPrintCardUrl)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAbCard addCardToDatabase (in string uri); */
NS_IMETHODIMP nsAbCard::AddCardToDatabase(const char *uri, nsIAbCard **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAbCard dropCardToDatabase (in string uri); */
NS_IMETHODIMP nsAbCard::DropCardToDatabase(const char *uri, nsIAbCard **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void editCardToDatabase (in string uri); */
NS_IMETHODIMP nsAbCard::EditCardToDatabase(const char *uri)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* wstring getCollationKey (in wstring str); */
NS_IMETHODIMP nsAbCard::GetCollationKey(const PRUnichar *str, PRUnichar **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbCard_h__ */
