/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbDirectoryQueryProxy.idl
 */

#ifndef __gen_nsIAbDirectoryQueryProxy_h__
#define __gen_nsIAbDirectoryQueryProxy_h__


#ifndef __gen_nsIAbDirectoryQuery_h__
#include "nsIAbDirectoryQuery.h"
#endif

#ifndef __gen_nsIAbDirectory_h__
#include "nsIAbDirectory.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIAbDirectoryQueryProxy */
#define NS_IABDIRECTORYQUERYPROXY_IID_STR "cfa60e0c-94d5-4292-a675-28c737950b3b"

#define NS_IABDIRECTORYQUERYPROXY_IID \
  {0xcfa60e0c, 0x94d5, 0x4292, \
    { 0xa6, 0x75, 0x28, 0xc7, 0x37, 0x95, 0x0b, 0x3b }}

class NS_NO_VTABLE nsIAbDirectoryQueryProxy : public nsIAbDirectoryQuery {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABDIRECTORYQUERYPROXY_IID)

  /* void initiate (in nsIAbDirectory directory); */
  NS_IMETHOD Initiate(nsIAbDirectory *directory) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABDIRECTORYQUERYPROXY \
  NS_IMETHOD Initiate(nsIAbDirectory *directory); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABDIRECTORYQUERYPROXY(_to) \
  NS_IMETHOD Initiate(nsIAbDirectory *directory) { return _to Initiate(directory); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABDIRECTORYQUERYPROXY(_to) \
  NS_IMETHOD Initiate(nsIAbDirectory *directory) { return !_to ? NS_ERROR_NULL_POINTER : _to->Initiate(directory); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbDirectoryQueryProxy : public nsIAbDirectoryQueryProxy
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABDIRECTORYQUERYPROXY

  nsAbDirectoryQueryProxy();
  virtual ~nsAbDirectoryQueryProxy();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbDirectoryQueryProxy, nsIAbDirectoryQueryProxy)

nsAbDirectoryQueryProxy::nsAbDirectoryQueryProxy()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAbDirectoryQueryProxy::~nsAbDirectoryQueryProxy()
{
  /* destructor code */
}

/* void initiate (in nsIAbDirectory directory); */
NS_IMETHODIMP nsAbDirectoryQueryProxy::Initiate(nsIAbDirectory *directory)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbDirectoryQueryProxy_h__ */
