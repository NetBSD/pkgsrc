/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsCExternalHandlerService.idl
 */

#ifndef __gen_nsCExternalHandlerService_h__
#define __gen_nsCExternalHandlerService_h__


#ifndef __gen_nsIExternalHelperAppService_h__
#include "nsIExternalHelperAppService.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
/* A7F800E0-4306-11d4-98D0-001083010E9B */
#define NS_EXTERNALHELPERAPPSERVICE_CID   \
 { 0xa7f800e0, 0x4306, 0x11d4, { 0x98, 0xd0, 0x0, 0x10, 0x83, 0x1, 0xe, 0x9b } }
#define NS_EXTERNALHELPERAPPSERVICE_CONTRACTID \
"@mozilla.org/uriloader/external-helper-app-service;1"
#define NS_EXTERNALPROTOCOLSERVICE_CONTRACTID \
"@mozilla.org/uriloader/external-protocol-service;1"
#define NS_MIMESERVICE_CONTRACTID \
"@mozilla.org/mime;1"
#define NS_EXTERNALPROTOCOLHANDLER_CID	\
{ 0xbd6390c8, 0xfbea, 0x11d4, {0x98, 0xf6, 0x0, 0x10, 0x83, 0x1, 0xe, 0x9b } }

#endif /* __gen_nsCExternalHandlerService_h__ */
