/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIDBFolderInfo.idl
 */

#ifndef __gen_nsIDBFolderInfo_h__
#define __gen_nsIDBFolderInfo_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_MailNewsTypes2_h__
#include "MailNewsTypes2.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
#include "nsString.h"

/* starting interface:    nsIDBFolderInfo */
#define NS_IDBFOLDERINFO_IID_STR "5cb11c00-cb8b-11d2-8d67-00805f8a6617"

#define NS_IDBFOLDERINFO_IID \
  {0x5cb11c00, 0xcb8b, 0x11d2, \
    { 0x8d, 0x67, 0x00, 0x80, 0x5f, 0x8a, 0x66, 0x17 }}

class NS_NO_VTABLE nsIDBFolderInfo : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IDBFOLDERINFO_IID)

  /* attribute long Flags; */
  NS_IMETHOD GetFlags(PRInt32 *aFlags) = 0;
  NS_IMETHOD SetFlags(PRInt32 aFlags) = 0;

  /* long OrFlags (in long flags); */
  NS_IMETHOD OrFlags(PRInt32 flags, PRInt32 *_retval) = 0;

  /* long AndFlags (in long flags); */
  NS_IMETHOD AndFlags(PRInt32 flags, PRInt32 *_retval) = 0;

  /* void SetHighWater (in nsMsgKey highwater, in boolean force); */
  NS_IMETHOD SetHighWater(nsMsgKey highwater, PRBool force) = 0;

  /* attribute nsMsgKey HighWater; */
  NS_IMETHOD GetHighWater(nsMsgKey *aHighWater) = 0;
  NS_IMETHOD SetHighWater(nsMsgKey aHighWater) = 0;

  /* attribute nsMsgKey ExpiredMark; */
  NS_IMETHOD GetExpiredMark(nsMsgKey *aExpiredMark) = 0;
  NS_IMETHOD SetExpiredMark(nsMsgKey aExpiredMark) = 0;

  /* attribute unsigned long FolderSize; */
  NS_IMETHOD GetFolderSize(PRUint32 *aFolderSize) = 0;
  NS_IMETHOD SetFolderSize(PRUint32 aFolderSize) = 0;

  /* attribute nsMsgKey LastMessageLoaded; */
  NS_IMETHOD GetLastMessageLoaded(nsMsgKey *aLastMessageLoaded) = 0;
  NS_IMETHOD SetLastMessageLoaded(nsMsgKey aLastMessageLoaded) = 0;

  /* attribute unsigned long FolderDate; */
  NS_IMETHOD GetFolderDate(PRUint32 *aFolderDate) = 0;
  NS_IMETHOD SetFolderDate(PRUint32 aFolderDate) = 0;

  /* void ChangeNumNewMessages (in long delta); */
  NS_IMETHOD ChangeNumNewMessages(PRInt32 delta) = 0;

  /* void ChangeNumMessages (in long delta); */
  NS_IMETHOD ChangeNumMessages(PRInt32 delta) = 0;

  /* void ChangeNumVisibleMessages (in long delta); */
  NS_IMETHOD ChangeNumVisibleMessages(PRInt32 delta) = 0;

  /* attribute long NumNewMessages; */
  NS_IMETHOD GetNumNewMessages(PRInt32 *aNumNewMessages) = 0;
  NS_IMETHOD SetNumNewMessages(PRInt32 aNumNewMessages) = 0;

  /* attribute long NumMessages; */
  NS_IMETHOD GetNumMessages(PRInt32 *aNumMessages) = 0;
  NS_IMETHOD SetNumMessages(PRInt32 aNumMessages) = 0;

  /* attribute long expungedBytes; */
  NS_IMETHOD GetExpungedBytes(PRInt32 *aExpungedBytes) = 0;
  NS_IMETHOD SetExpungedBytes(PRInt32 aExpungedBytes) = 0;

  /* attribute long NumVisibleMessages; */
  NS_IMETHOD GetNumVisibleMessages(PRInt32 *aNumVisibleMessages) = 0;
  NS_IMETHOD SetNumVisibleMessages(PRInt32 aNumVisibleMessages) = 0;

  /* attribute long ImapUidValidity; */
  NS_IMETHOD GetImapUidValidity(PRInt32 *aImapUidValidity) = 0;
  NS_IMETHOD SetImapUidValidity(PRInt32 aImapUidValidity) = 0;

  /* attribute unsigned long Version; */
  NS_IMETHOD GetVersion(PRUint32 *aVersion) = 0;
  NS_IMETHOD SetVersion(PRUint32 aVersion) = 0;

  /* attribute long ImapTotalPendingMessages; */
  NS_IMETHOD GetImapTotalPendingMessages(PRInt32 *aImapTotalPendingMessages) = 0;
  NS_IMETHOD SetImapTotalPendingMessages(PRInt32 aImapTotalPendingMessages) = 0;

  /* attribute long ImapUnreadPendingMessages; */
  NS_IMETHOD GetImapUnreadPendingMessages(PRInt32 *aImapUnreadPendingMessages) = 0;
  NS_IMETHOD SetImapUnreadPendingMessages(PRInt32 aImapUnreadPendingMessages) = 0;

  /* attribute wchar IMAPHierarchySeparator; */
  NS_IMETHOD GetIMAPHierarchySeparator(PRUnichar *aIMAPHierarchySeparator) = 0;
  NS_IMETHOD SetIMAPHierarchySeparator(PRUnichar aIMAPHierarchySeparator) = 0;

  /* attribute nsMsgViewTypeValue viewType; */
  NS_IMETHOD GetViewType(nsMsgViewTypeValue *aViewType) = 0;
  NS_IMETHOD SetViewType(nsMsgViewTypeValue aViewType) = 0;

  /* attribute nsMsgViewFlagsTypeValue viewFlags; */
  NS_IMETHOD GetViewFlags(nsMsgViewFlagsTypeValue *aViewFlags) = 0;
  NS_IMETHOD SetViewFlags(nsMsgViewFlagsTypeValue aViewFlags) = 0;

  /* attribute nsMsgViewSortTypeValue sortType; */
  NS_IMETHOD GetSortType(nsMsgViewSortTypeValue *aSortType) = 0;
  NS_IMETHOD SetSortType(nsMsgViewSortTypeValue aSortType) = 0;

  /* attribute nsMsgViewSortOrderValue sortOrder; */
  NS_IMETHOD GetSortOrder(nsMsgViewSortOrderValue *aSortOrder) = 0;
  NS_IMETHOD SetSortOrder(nsMsgViewSortOrderValue aSortOrder) = 0;

  /* void ChangeExpungedBytes (in long delta); */
  NS_IMETHOD ChangeExpungedBytes(PRInt32 delta) = 0;

  /* void GetCharPtrProperty (in string propertyName, out string resultProperty); */
  NS_IMETHOD GetCharPtrProperty(const char *propertyName, char **resultProperty) = 0;

  /* void SetUint32Property (in string propertyName, in unsigned long propertyValue); */
  NS_IMETHOD SetUint32Property(const char *propertyName, PRUint32 propertyValue) = 0;

  /* void GetUint32Property (in string propertyName, out unsigned long result, in unsigned long defaultValue); */
  NS_IMETHOD GetUint32Property(const char *propertyName, PRUint32 *result, PRUint32 defaultValue) = 0;

  /* void getBooleanProperty (in string propertyName, out boolean result, in boolean defaultValue); */
  NS_IMETHOD GetBooleanProperty(const char *propertyName, PRBool *result, PRBool defaultValue) = 0;

  /* void setBooleanProperty (in string propertyName, in boolean aPropertyValue); */
  NS_IMETHOD SetBooleanProperty(const char *propertyName, PRBool aPropertyValue) = 0;

  /* void GetTransferInfo (out nsIDBFolderInfo transferInfo); */
  NS_IMETHOD GetTransferInfo(nsIDBFolderInfo **transferInfo) = 0;

  /* void InitFromTransferInfo (in nsIDBFolderInfo transferInfo); */
  NS_IMETHOD InitFromTransferInfo(nsIDBFolderInfo *transferInfo) = 0;

  /* [noscript] void GetCharacterSet (in nsString result, out boolean usedDefault); */
  NS_IMETHOD GetCharacterSet(nsString * result, PRBool *usedDefault) = 0;

  /* [noscript] void SetCharacterSet (in nsString result); */
  NS_IMETHOD SetCharacterSet(nsString * result) = 0;

  /* void GetCharacterSetOverride (out boolean characterSetOverride); */
  NS_IMETHOD GetCharacterSetOverride(PRBool *characterSetOverride) = 0;

  /* void SetCharacterSetOverride (in boolean characterSetOverride); */
  NS_IMETHOD SetCharacterSetOverride(PRBool characterSetOverride) = 0;

  /* void GetCharPtrCharacterSet (out string result); */
  NS_IMETHOD GetCharPtrCharacterSet(char **result) = 0;

  /* [noscript] void GetLocale (in nsString result); */
  NS_IMETHOD GetLocale(nsString * result) = 0;

  /* [noscript] void SetLocale (in nsString locale); */
  NS_IMETHOD SetLocale(nsString * locale) = 0;

  /* [noscript] void SetMailboxName (in nsString newBoxName); */
  NS_IMETHOD SetMailboxName(nsString * newBoxName) = 0;

  /* [noscript] void GetMailboxName (in nsString boxName); */
  NS_IMETHOD GetMailboxName(nsString * boxName) = 0;

  /* [noscript] void GetProperty (in string propertyName, in nsString resultProperty); */
  NS_IMETHOD GetProperty(const char *propertyName, nsString * resultProperty) = 0;

  /* [noscript] void SetProperty (in string propertyName, in nsString propertyStr); */
  NS_IMETHOD SetProperty(const char *propertyName, nsString * propertyStr) = 0;

  /* [noscript] void SetKnownArtsSet (in nsString newsArtSet); */
  NS_IMETHOD SetKnownArtsSet(nsString * newsArtSet) = 0;

  /* [noscript] void GetKnownArtsSet (in nsString newsArtSet); */
  NS_IMETHOD GetKnownArtsSet(nsString * newsArtSet) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIDBFOLDERINFO \
  NS_IMETHOD GetFlags(PRInt32 *aFlags); \
  NS_IMETHOD SetFlags(PRInt32 aFlags); \
  NS_IMETHOD OrFlags(PRInt32 flags, PRInt32 *_retval); \
  NS_IMETHOD AndFlags(PRInt32 flags, PRInt32 *_retval); \
  NS_IMETHOD SetHighWater(nsMsgKey highwater, PRBool force); \
  NS_IMETHOD GetHighWater(nsMsgKey *aHighWater); \
  NS_IMETHOD SetHighWater(nsMsgKey aHighWater); \
  NS_IMETHOD GetExpiredMark(nsMsgKey *aExpiredMark); \
  NS_IMETHOD SetExpiredMark(nsMsgKey aExpiredMark); \
  NS_IMETHOD GetFolderSize(PRUint32 *aFolderSize); \
  NS_IMETHOD SetFolderSize(PRUint32 aFolderSize); \
  NS_IMETHOD GetLastMessageLoaded(nsMsgKey *aLastMessageLoaded); \
  NS_IMETHOD SetLastMessageLoaded(nsMsgKey aLastMessageLoaded); \
  NS_IMETHOD GetFolderDate(PRUint32 *aFolderDate); \
  NS_IMETHOD SetFolderDate(PRUint32 aFolderDate); \
  NS_IMETHOD ChangeNumNewMessages(PRInt32 delta); \
  NS_IMETHOD ChangeNumMessages(PRInt32 delta); \
  NS_IMETHOD ChangeNumVisibleMessages(PRInt32 delta); \
  NS_IMETHOD GetNumNewMessages(PRInt32 *aNumNewMessages); \
  NS_IMETHOD SetNumNewMessages(PRInt32 aNumNewMessages); \
  NS_IMETHOD GetNumMessages(PRInt32 *aNumMessages); \
  NS_IMETHOD SetNumMessages(PRInt32 aNumMessages); \
  NS_IMETHOD GetExpungedBytes(PRInt32 *aExpungedBytes); \
  NS_IMETHOD SetExpungedBytes(PRInt32 aExpungedBytes); \
  NS_IMETHOD GetNumVisibleMessages(PRInt32 *aNumVisibleMessages); \
  NS_IMETHOD SetNumVisibleMessages(PRInt32 aNumVisibleMessages); \
  NS_IMETHOD GetImapUidValidity(PRInt32 *aImapUidValidity); \
  NS_IMETHOD SetImapUidValidity(PRInt32 aImapUidValidity); \
  NS_IMETHOD GetVersion(PRUint32 *aVersion); \
  NS_IMETHOD SetVersion(PRUint32 aVersion); \
  NS_IMETHOD GetImapTotalPendingMessages(PRInt32 *aImapTotalPendingMessages); \
  NS_IMETHOD SetImapTotalPendingMessages(PRInt32 aImapTotalPendingMessages); \
  NS_IMETHOD GetImapUnreadPendingMessages(PRInt32 *aImapUnreadPendingMessages); \
  NS_IMETHOD SetImapUnreadPendingMessages(PRInt32 aImapUnreadPendingMessages); \
  NS_IMETHOD GetIMAPHierarchySeparator(PRUnichar *aIMAPHierarchySeparator); \
  NS_IMETHOD SetIMAPHierarchySeparator(PRUnichar aIMAPHierarchySeparator); \
  NS_IMETHOD GetViewType(nsMsgViewTypeValue *aViewType); \
  NS_IMETHOD SetViewType(nsMsgViewTypeValue aViewType); \
  NS_IMETHOD GetViewFlags(nsMsgViewFlagsTypeValue *aViewFlags); \
  NS_IMETHOD SetViewFlags(nsMsgViewFlagsTypeValue aViewFlags); \
  NS_IMETHOD GetSortType(nsMsgViewSortTypeValue *aSortType); \
  NS_IMETHOD SetSortType(nsMsgViewSortTypeValue aSortType); \
  NS_IMETHOD GetSortOrder(nsMsgViewSortOrderValue *aSortOrder); \
  NS_IMETHOD SetSortOrder(nsMsgViewSortOrderValue aSortOrder); \
  NS_IMETHOD ChangeExpungedBytes(PRInt32 delta); \
  NS_IMETHOD GetCharPtrProperty(const char *propertyName, char **resultProperty); \
  NS_IMETHOD SetUint32Property(const char *propertyName, PRUint32 propertyValue); \
  NS_IMETHOD GetUint32Property(const char *propertyName, PRUint32 *result, PRUint32 defaultValue); \
  NS_IMETHOD GetBooleanProperty(const char *propertyName, PRBool *result, PRBool defaultValue); \
  NS_IMETHOD SetBooleanProperty(const char *propertyName, PRBool aPropertyValue); \
  NS_IMETHOD GetTransferInfo(nsIDBFolderInfo **transferInfo); \
  NS_IMETHOD InitFromTransferInfo(nsIDBFolderInfo *transferInfo); \
  NS_IMETHOD GetCharacterSet(nsString * result, PRBool *usedDefault); \
  NS_IMETHOD SetCharacterSet(nsString * result); \
  NS_IMETHOD GetCharacterSetOverride(PRBool *characterSetOverride); \
  NS_IMETHOD SetCharacterSetOverride(PRBool characterSetOverride); \
  NS_IMETHOD GetCharPtrCharacterSet(char **result); \
  NS_IMETHOD GetLocale(nsString * result); \
  NS_IMETHOD SetLocale(nsString * locale); \
  NS_IMETHOD SetMailboxName(nsString * newBoxName); \
  NS_IMETHOD GetMailboxName(nsString * boxName); \
  NS_IMETHOD GetProperty(const char *propertyName, nsString * resultProperty); \
  NS_IMETHOD SetProperty(const char *propertyName, nsString * propertyStr); \
  NS_IMETHOD SetKnownArtsSet(nsString * newsArtSet); \
  NS_IMETHOD GetKnownArtsSet(nsString * newsArtSet); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIDBFOLDERINFO(_to) \
  NS_IMETHOD GetFlags(PRInt32 *aFlags) { return _to GetFlags(aFlags); } \
  NS_IMETHOD SetFlags(PRInt32 aFlags) { return _to SetFlags(aFlags); } \
  NS_IMETHOD OrFlags(PRInt32 flags, PRInt32 *_retval) { return _to OrFlags(flags, _retval); } \
  NS_IMETHOD AndFlags(PRInt32 flags, PRInt32 *_retval) { return _to AndFlags(flags, _retval); } \
  NS_IMETHOD SetHighWater(nsMsgKey highwater, PRBool force) { return _to SetHighWater(highwater, force); } \
  NS_IMETHOD GetHighWater(nsMsgKey *aHighWater) { return _to GetHighWater(aHighWater); } \
  NS_IMETHOD SetHighWater(nsMsgKey aHighWater) { return _to SetHighWater(aHighWater); } \
  NS_IMETHOD GetExpiredMark(nsMsgKey *aExpiredMark) { return _to GetExpiredMark(aExpiredMark); } \
  NS_IMETHOD SetExpiredMark(nsMsgKey aExpiredMark) { return _to SetExpiredMark(aExpiredMark); } \
  NS_IMETHOD GetFolderSize(PRUint32 *aFolderSize) { return _to GetFolderSize(aFolderSize); } \
  NS_IMETHOD SetFolderSize(PRUint32 aFolderSize) { return _to SetFolderSize(aFolderSize); } \
  NS_IMETHOD GetLastMessageLoaded(nsMsgKey *aLastMessageLoaded) { return _to GetLastMessageLoaded(aLastMessageLoaded); } \
  NS_IMETHOD SetLastMessageLoaded(nsMsgKey aLastMessageLoaded) { return _to SetLastMessageLoaded(aLastMessageLoaded); } \
  NS_IMETHOD GetFolderDate(PRUint32 *aFolderDate) { return _to GetFolderDate(aFolderDate); } \
  NS_IMETHOD SetFolderDate(PRUint32 aFolderDate) { return _to SetFolderDate(aFolderDate); } \
  NS_IMETHOD ChangeNumNewMessages(PRInt32 delta) { return _to ChangeNumNewMessages(delta); } \
  NS_IMETHOD ChangeNumMessages(PRInt32 delta) { return _to ChangeNumMessages(delta); } \
  NS_IMETHOD ChangeNumVisibleMessages(PRInt32 delta) { return _to ChangeNumVisibleMessages(delta); } \
  NS_IMETHOD GetNumNewMessages(PRInt32 *aNumNewMessages) { return _to GetNumNewMessages(aNumNewMessages); } \
  NS_IMETHOD SetNumNewMessages(PRInt32 aNumNewMessages) { return _to SetNumNewMessages(aNumNewMessages); } \
  NS_IMETHOD GetNumMessages(PRInt32 *aNumMessages) { return _to GetNumMessages(aNumMessages); } \
  NS_IMETHOD SetNumMessages(PRInt32 aNumMessages) { return _to SetNumMessages(aNumMessages); } \
  NS_IMETHOD GetExpungedBytes(PRInt32 *aExpungedBytes) { return _to GetExpungedBytes(aExpungedBytes); } \
  NS_IMETHOD SetExpungedBytes(PRInt32 aExpungedBytes) { return _to SetExpungedBytes(aExpungedBytes); } \
  NS_IMETHOD GetNumVisibleMessages(PRInt32 *aNumVisibleMessages) { return _to GetNumVisibleMessages(aNumVisibleMessages); } \
  NS_IMETHOD SetNumVisibleMessages(PRInt32 aNumVisibleMessages) { return _to SetNumVisibleMessages(aNumVisibleMessages); } \
  NS_IMETHOD GetImapUidValidity(PRInt32 *aImapUidValidity) { return _to GetImapUidValidity(aImapUidValidity); } \
  NS_IMETHOD SetImapUidValidity(PRInt32 aImapUidValidity) { return _to SetImapUidValidity(aImapUidValidity); } \
  NS_IMETHOD GetVersion(PRUint32 *aVersion) { return _to GetVersion(aVersion); } \
  NS_IMETHOD SetVersion(PRUint32 aVersion) { return _to SetVersion(aVersion); } \
  NS_IMETHOD GetImapTotalPendingMessages(PRInt32 *aImapTotalPendingMessages) { return _to GetImapTotalPendingMessages(aImapTotalPendingMessages); } \
  NS_IMETHOD SetImapTotalPendingMessages(PRInt32 aImapTotalPendingMessages) { return _to SetImapTotalPendingMessages(aImapTotalPendingMessages); } \
  NS_IMETHOD GetImapUnreadPendingMessages(PRInt32 *aImapUnreadPendingMessages) { return _to GetImapUnreadPendingMessages(aImapUnreadPendingMessages); } \
  NS_IMETHOD SetImapUnreadPendingMessages(PRInt32 aImapUnreadPendingMessages) { return _to SetImapUnreadPendingMessages(aImapUnreadPendingMessages); } \
  NS_IMETHOD GetIMAPHierarchySeparator(PRUnichar *aIMAPHierarchySeparator) { return _to GetIMAPHierarchySeparator(aIMAPHierarchySeparator); } \
  NS_IMETHOD SetIMAPHierarchySeparator(PRUnichar aIMAPHierarchySeparator) { return _to SetIMAPHierarchySeparator(aIMAPHierarchySeparator); } \
  NS_IMETHOD GetViewType(nsMsgViewTypeValue *aViewType) { return _to GetViewType(aViewType); } \
  NS_IMETHOD SetViewType(nsMsgViewTypeValue aViewType) { return _to SetViewType(aViewType); } \
  NS_IMETHOD GetViewFlags(nsMsgViewFlagsTypeValue *aViewFlags) { return _to GetViewFlags(aViewFlags); } \
  NS_IMETHOD SetViewFlags(nsMsgViewFlagsTypeValue aViewFlags) { return _to SetViewFlags(aViewFlags); } \
  NS_IMETHOD GetSortType(nsMsgViewSortTypeValue *aSortType) { return _to GetSortType(aSortType); } \
  NS_IMETHOD SetSortType(nsMsgViewSortTypeValue aSortType) { return _to SetSortType(aSortType); } \
  NS_IMETHOD GetSortOrder(nsMsgViewSortOrderValue *aSortOrder) { return _to GetSortOrder(aSortOrder); } \
  NS_IMETHOD SetSortOrder(nsMsgViewSortOrderValue aSortOrder) { return _to SetSortOrder(aSortOrder); } \
  NS_IMETHOD ChangeExpungedBytes(PRInt32 delta) { return _to ChangeExpungedBytes(delta); } \
  NS_IMETHOD GetCharPtrProperty(const char *propertyName, char **resultProperty) { return _to GetCharPtrProperty(propertyName, resultProperty); } \
  NS_IMETHOD SetUint32Property(const char *propertyName, PRUint32 propertyValue) { return _to SetUint32Property(propertyName, propertyValue); } \
  NS_IMETHOD GetUint32Property(const char *propertyName, PRUint32 *result, PRUint32 defaultValue) { return _to GetUint32Property(propertyName, result, defaultValue); } \
  NS_IMETHOD GetBooleanProperty(const char *propertyName, PRBool *result, PRBool defaultValue) { return _to GetBooleanProperty(propertyName, result, defaultValue); } \
  NS_IMETHOD SetBooleanProperty(const char *propertyName, PRBool aPropertyValue) { return _to SetBooleanProperty(propertyName, aPropertyValue); } \
  NS_IMETHOD GetTransferInfo(nsIDBFolderInfo **transferInfo) { return _to GetTransferInfo(transferInfo); } \
  NS_IMETHOD InitFromTransferInfo(nsIDBFolderInfo *transferInfo) { return _to InitFromTransferInfo(transferInfo); } \
  NS_IMETHOD GetCharacterSet(nsString * result, PRBool *usedDefault) { return _to GetCharacterSet(result, usedDefault); } \
  NS_IMETHOD SetCharacterSet(nsString * result) { return _to SetCharacterSet(result); } \
  NS_IMETHOD GetCharacterSetOverride(PRBool *characterSetOverride) { return _to GetCharacterSetOverride(characterSetOverride); } \
  NS_IMETHOD SetCharacterSetOverride(PRBool characterSetOverride) { return _to SetCharacterSetOverride(characterSetOverride); } \
  NS_IMETHOD GetCharPtrCharacterSet(char **result) { return _to GetCharPtrCharacterSet(result); } \
  NS_IMETHOD GetLocale(nsString * result) { return _to GetLocale(result); } \
  NS_IMETHOD SetLocale(nsString * locale) { return _to SetLocale(locale); } \
  NS_IMETHOD SetMailboxName(nsString * newBoxName) { return _to SetMailboxName(newBoxName); } \
  NS_IMETHOD GetMailboxName(nsString * boxName) { return _to GetMailboxName(boxName); } \
  NS_IMETHOD GetProperty(const char *propertyName, nsString * resultProperty) { return _to GetProperty(propertyName, resultProperty); } \
  NS_IMETHOD SetProperty(const char *propertyName, nsString * propertyStr) { return _to SetProperty(propertyName, propertyStr); } \
  NS_IMETHOD SetKnownArtsSet(nsString * newsArtSet) { return _to SetKnownArtsSet(newsArtSet); } \
  NS_IMETHOD GetKnownArtsSet(nsString * newsArtSet) { return _to GetKnownArtsSet(newsArtSet); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIDBFOLDERINFO(_to) \
  NS_IMETHOD GetFlags(PRInt32 *aFlags) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetFlags(aFlags); } \
  NS_IMETHOD SetFlags(PRInt32 aFlags) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetFlags(aFlags); } \
  NS_IMETHOD OrFlags(PRInt32 flags, PRInt32 *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->OrFlags(flags, _retval); } \
  NS_IMETHOD AndFlags(PRInt32 flags, PRInt32 *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->AndFlags(flags, _retval); } \
  NS_IMETHOD SetHighWater(nsMsgKey highwater, PRBool force) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetHighWater(highwater, force); } \
  NS_IMETHOD GetHighWater(nsMsgKey *aHighWater) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetHighWater(aHighWater); } \
  NS_IMETHOD SetHighWater(nsMsgKey aHighWater) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetHighWater(aHighWater); } \
  NS_IMETHOD GetExpiredMark(nsMsgKey *aExpiredMark) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetExpiredMark(aExpiredMark); } \
  NS_IMETHOD SetExpiredMark(nsMsgKey aExpiredMark) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetExpiredMark(aExpiredMark); } \
  NS_IMETHOD GetFolderSize(PRUint32 *aFolderSize) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetFolderSize(aFolderSize); } \
  NS_IMETHOD SetFolderSize(PRUint32 aFolderSize) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetFolderSize(aFolderSize); } \
  NS_IMETHOD GetLastMessageLoaded(nsMsgKey *aLastMessageLoaded) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetLastMessageLoaded(aLastMessageLoaded); } \
  NS_IMETHOD SetLastMessageLoaded(nsMsgKey aLastMessageLoaded) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetLastMessageLoaded(aLastMessageLoaded); } \
  NS_IMETHOD GetFolderDate(PRUint32 *aFolderDate) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetFolderDate(aFolderDate); } \
  NS_IMETHOD SetFolderDate(PRUint32 aFolderDate) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetFolderDate(aFolderDate); } \
  NS_IMETHOD ChangeNumNewMessages(PRInt32 delta) { return !_to ? NS_ERROR_NULL_POINTER : _to->ChangeNumNewMessages(delta); } \
  NS_IMETHOD ChangeNumMessages(PRInt32 delta) { return !_to ? NS_ERROR_NULL_POINTER : _to->ChangeNumMessages(delta); } \
  NS_IMETHOD ChangeNumVisibleMessages(PRInt32 delta) { return !_to ? NS_ERROR_NULL_POINTER : _to->ChangeNumVisibleMessages(delta); } \
  NS_IMETHOD GetNumNewMessages(PRInt32 *aNumNewMessages) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetNumNewMessages(aNumNewMessages); } \
  NS_IMETHOD SetNumNewMessages(PRInt32 aNumNewMessages) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetNumNewMessages(aNumNewMessages); } \
  NS_IMETHOD GetNumMessages(PRInt32 *aNumMessages) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetNumMessages(aNumMessages); } \
  NS_IMETHOD SetNumMessages(PRInt32 aNumMessages) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetNumMessages(aNumMessages); } \
  NS_IMETHOD GetExpungedBytes(PRInt32 *aExpungedBytes) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetExpungedBytes(aExpungedBytes); } \
  NS_IMETHOD SetExpungedBytes(PRInt32 aExpungedBytes) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetExpungedBytes(aExpungedBytes); } \
  NS_IMETHOD GetNumVisibleMessages(PRInt32 *aNumVisibleMessages) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetNumVisibleMessages(aNumVisibleMessages); } \
  NS_IMETHOD SetNumVisibleMessages(PRInt32 aNumVisibleMessages) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetNumVisibleMessages(aNumVisibleMessages); } \
  NS_IMETHOD GetImapUidValidity(PRInt32 *aImapUidValidity) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetImapUidValidity(aImapUidValidity); } \
  NS_IMETHOD SetImapUidValidity(PRInt32 aImapUidValidity) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetImapUidValidity(aImapUidValidity); } \
  NS_IMETHOD GetVersion(PRUint32 *aVersion) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetVersion(aVersion); } \
  NS_IMETHOD SetVersion(PRUint32 aVersion) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetVersion(aVersion); } \
  NS_IMETHOD GetImapTotalPendingMessages(PRInt32 *aImapTotalPendingMessages) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetImapTotalPendingMessages(aImapTotalPendingMessages); } \
  NS_IMETHOD SetImapTotalPendingMessages(PRInt32 aImapTotalPendingMessages) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetImapTotalPendingMessages(aImapTotalPendingMessages); } \
  NS_IMETHOD GetImapUnreadPendingMessages(PRInt32 *aImapUnreadPendingMessages) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetImapUnreadPendingMessages(aImapUnreadPendingMessages); } \
  NS_IMETHOD SetImapUnreadPendingMessages(PRInt32 aImapUnreadPendingMessages) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetImapUnreadPendingMessages(aImapUnreadPendingMessages); } \
  NS_IMETHOD GetIMAPHierarchySeparator(PRUnichar *aIMAPHierarchySeparator) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIMAPHierarchySeparator(aIMAPHierarchySeparator); } \
  NS_IMETHOD SetIMAPHierarchySeparator(PRUnichar aIMAPHierarchySeparator) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetIMAPHierarchySeparator(aIMAPHierarchySeparator); } \
  NS_IMETHOD GetViewType(nsMsgViewTypeValue *aViewType) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetViewType(aViewType); } \
  NS_IMETHOD SetViewType(nsMsgViewTypeValue aViewType) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetViewType(aViewType); } \
  NS_IMETHOD GetViewFlags(nsMsgViewFlagsTypeValue *aViewFlags) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetViewFlags(aViewFlags); } \
  NS_IMETHOD SetViewFlags(nsMsgViewFlagsTypeValue aViewFlags) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetViewFlags(aViewFlags); } \
  NS_IMETHOD GetSortType(nsMsgViewSortTypeValue *aSortType) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSortType(aSortType); } \
  NS_IMETHOD SetSortType(nsMsgViewSortTypeValue aSortType) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetSortType(aSortType); } \
  NS_IMETHOD GetSortOrder(nsMsgViewSortOrderValue *aSortOrder) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSortOrder(aSortOrder); } \
  NS_IMETHOD SetSortOrder(nsMsgViewSortOrderValue aSortOrder) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetSortOrder(aSortOrder); } \
  NS_IMETHOD ChangeExpungedBytes(PRInt32 delta) { return !_to ? NS_ERROR_NULL_POINTER : _to->ChangeExpungedBytes(delta); } \
  NS_IMETHOD GetCharPtrProperty(const char *propertyName, char **resultProperty) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCharPtrProperty(propertyName, resultProperty); } \
  NS_IMETHOD SetUint32Property(const char *propertyName, PRUint32 propertyValue) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetUint32Property(propertyName, propertyValue); } \
  NS_IMETHOD GetUint32Property(const char *propertyName, PRUint32 *result, PRUint32 defaultValue) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetUint32Property(propertyName, result, defaultValue); } \
  NS_IMETHOD GetBooleanProperty(const char *propertyName, PRBool *result, PRBool defaultValue) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBooleanProperty(propertyName, result, defaultValue); } \
  NS_IMETHOD SetBooleanProperty(const char *propertyName, PRBool aPropertyValue) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBooleanProperty(propertyName, aPropertyValue); } \
  NS_IMETHOD GetTransferInfo(nsIDBFolderInfo **transferInfo) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetTransferInfo(transferInfo); } \
  NS_IMETHOD InitFromTransferInfo(nsIDBFolderInfo *transferInfo) { return !_to ? NS_ERROR_NULL_POINTER : _to->InitFromTransferInfo(transferInfo); } \
  NS_IMETHOD GetCharacterSet(nsString * result, PRBool *usedDefault) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCharacterSet(result, usedDefault); } \
  NS_IMETHOD SetCharacterSet(nsString * result) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCharacterSet(result); } \
  NS_IMETHOD GetCharacterSetOverride(PRBool *characterSetOverride) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCharacterSetOverride(characterSetOverride); } \
  NS_IMETHOD SetCharacterSetOverride(PRBool characterSetOverride) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCharacterSetOverride(characterSetOverride); } \
  NS_IMETHOD GetCharPtrCharacterSet(char **result) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCharPtrCharacterSet(result); } \
  NS_IMETHOD GetLocale(nsString * result) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetLocale(result); } \
  NS_IMETHOD SetLocale(nsString * locale) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetLocale(locale); } \
  NS_IMETHOD SetMailboxName(nsString * newBoxName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetMailboxName(newBoxName); } \
  NS_IMETHOD GetMailboxName(nsString * boxName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetMailboxName(boxName); } \
  NS_IMETHOD GetProperty(const char *propertyName, nsString * resultProperty) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetProperty(propertyName, resultProperty); } \
  NS_IMETHOD SetProperty(const char *propertyName, nsString * propertyStr) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetProperty(propertyName, propertyStr); } \
  NS_IMETHOD SetKnownArtsSet(nsString * newsArtSet) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetKnownArtsSet(newsArtSet); } \
  NS_IMETHOD GetKnownArtsSet(nsString * newsArtSet) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetKnownArtsSet(newsArtSet); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsDBFolderInfo : public nsIDBFolderInfo
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIDBFOLDERINFO

  nsDBFolderInfo();
  virtual ~nsDBFolderInfo();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsDBFolderInfo, nsIDBFolderInfo)

nsDBFolderInfo::nsDBFolderInfo()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsDBFolderInfo::~nsDBFolderInfo()
{
  /* destructor code */
}

/* attribute long Flags; */
NS_IMETHODIMP nsDBFolderInfo::GetFlags(PRInt32 *aFlags)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDBFolderInfo::SetFlags(PRInt32 aFlags)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* long OrFlags (in long flags); */
NS_IMETHODIMP nsDBFolderInfo::OrFlags(PRInt32 flags, PRInt32 *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* long AndFlags (in long flags); */
NS_IMETHODIMP nsDBFolderInfo::AndFlags(PRInt32 flags, PRInt32 *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void SetHighWater (in nsMsgKey highwater, in boolean force); */
NS_IMETHODIMP nsDBFolderInfo::SetHighWater(nsMsgKey highwater, PRBool force)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute nsMsgKey HighWater; */
NS_IMETHODIMP nsDBFolderInfo::GetHighWater(nsMsgKey *aHighWater)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDBFolderInfo::SetHighWater(nsMsgKey aHighWater)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute nsMsgKey ExpiredMark; */
NS_IMETHODIMP nsDBFolderInfo::GetExpiredMark(nsMsgKey *aExpiredMark)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDBFolderInfo::SetExpiredMark(nsMsgKey aExpiredMark)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute unsigned long FolderSize; */
NS_IMETHODIMP nsDBFolderInfo::GetFolderSize(PRUint32 *aFolderSize)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDBFolderInfo::SetFolderSize(PRUint32 aFolderSize)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute nsMsgKey LastMessageLoaded; */
NS_IMETHODIMP nsDBFolderInfo::GetLastMessageLoaded(nsMsgKey *aLastMessageLoaded)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDBFolderInfo::SetLastMessageLoaded(nsMsgKey aLastMessageLoaded)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute unsigned long FolderDate; */
NS_IMETHODIMP nsDBFolderInfo::GetFolderDate(PRUint32 *aFolderDate)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDBFolderInfo::SetFolderDate(PRUint32 aFolderDate)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void ChangeNumNewMessages (in long delta); */
NS_IMETHODIMP nsDBFolderInfo::ChangeNumNewMessages(PRInt32 delta)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void ChangeNumMessages (in long delta); */
NS_IMETHODIMP nsDBFolderInfo::ChangeNumMessages(PRInt32 delta)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void ChangeNumVisibleMessages (in long delta); */
NS_IMETHODIMP nsDBFolderInfo::ChangeNumVisibleMessages(PRInt32 delta)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute long NumNewMessages; */
NS_IMETHODIMP nsDBFolderInfo::GetNumNewMessages(PRInt32 *aNumNewMessages)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDBFolderInfo::SetNumNewMessages(PRInt32 aNumNewMessages)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute long NumMessages; */
NS_IMETHODIMP nsDBFolderInfo::GetNumMessages(PRInt32 *aNumMessages)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDBFolderInfo::SetNumMessages(PRInt32 aNumMessages)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute long expungedBytes; */
NS_IMETHODIMP nsDBFolderInfo::GetExpungedBytes(PRInt32 *aExpungedBytes)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDBFolderInfo::SetExpungedBytes(PRInt32 aExpungedBytes)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute long NumVisibleMessages; */
NS_IMETHODIMP nsDBFolderInfo::GetNumVisibleMessages(PRInt32 *aNumVisibleMessages)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDBFolderInfo::SetNumVisibleMessages(PRInt32 aNumVisibleMessages)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute long ImapUidValidity; */
NS_IMETHODIMP nsDBFolderInfo::GetImapUidValidity(PRInt32 *aImapUidValidity)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDBFolderInfo::SetImapUidValidity(PRInt32 aImapUidValidity)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute unsigned long Version; */
NS_IMETHODIMP nsDBFolderInfo::GetVersion(PRUint32 *aVersion)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDBFolderInfo::SetVersion(PRUint32 aVersion)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute long ImapTotalPendingMessages; */
NS_IMETHODIMP nsDBFolderInfo::GetImapTotalPendingMessages(PRInt32 *aImapTotalPendingMessages)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDBFolderInfo::SetImapTotalPendingMessages(PRInt32 aImapTotalPendingMessages)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute long ImapUnreadPendingMessages; */
NS_IMETHODIMP nsDBFolderInfo::GetImapUnreadPendingMessages(PRInt32 *aImapUnreadPendingMessages)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDBFolderInfo::SetImapUnreadPendingMessages(PRInt32 aImapUnreadPendingMessages)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wchar IMAPHierarchySeparator; */
NS_IMETHODIMP nsDBFolderInfo::GetIMAPHierarchySeparator(PRUnichar *aIMAPHierarchySeparator)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDBFolderInfo::SetIMAPHierarchySeparator(PRUnichar aIMAPHierarchySeparator)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute nsMsgViewTypeValue viewType; */
NS_IMETHODIMP nsDBFolderInfo::GetViewType(nsMsgViewTypeValue *aViewType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDBFolderInfo::SetViewType(nsMsgViewTypeValue aViewType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute nsMsgViewFlagsTypeValue viewFlags; */
NS_IMETHODIMP nsDBFolderInfo::GetViewFlags(nsMsgViewFlagsTypeValue *aViewFlags)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDBFolderInfo::SetViewFlags(nsMsgViewFlagsTypeValue aViewFlags)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute nsMsgViewSortTypeValue sortType; */
NS_IMETHODIMP nsDBFolderInfo::GetSortType(nsMsgViewSortTypeValue *aSortType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDBFolderInfo::SetSortType(nsMsgViewSortTypeValue aSortType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute nsMsgViewSortOrderValue sortOrder; */
NS_IMETHODIMP nsDBFolderInfo::GetSortOrder(nsMsgViewSortOrderValue *aSortOrder)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsDBFolderInfo::SetSortOrder(nsMsgViewSortOrderValue aSortOrder)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void ChangeExpungedBytes (in long delta); */
NS_IMETHODIMP nsDBFolderInfo::ChangeExpungedBytes(PRInt32 delta)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void GetCharPtrProperty (in string propertyName, out string resultProperty); */
NS_IMETHODIMP nsDBFolderInfo::GetCharPtrProperty(const char *propertyName, char **resultProperty)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void SetUint32Property (in string propertyName, in unsigned long propertyValue); */
NS_IMETHODIMP nsDBFolderInfo::SetUint32Property(const char *propertyName, PRUint32 propertyValue)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void GetUint32Property (in string propertyName, out unsigned long result, in unsigned long defaultValue); */
NS_IMETHODIMP nsDBFolderInfo::GetUint32Property(const char *propertyName, PRUint32 *result, PRUint32 defaultValue)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void getBooleanProperty (in string propertyName, out boolean result, in boolean defaultValue); */
NS_IMETHODIMP nsDBFolderInfo::GetBooleanProperty(const char *propertyName, PRBool *result, PRBool defaultValue)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setBooleanProperty (in string propertyName, in boolean aPropertyValue); */
NS_IMETHODIMP nsDBFolderInfo::SetBooleanProperty(const char *propertyName, PRBool aPropertyValue)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void GetTransferInfo (out nsIDBFolderInfo transferInfo); */
NS_IMETHODIMP nsDBFolderInfo::GetTransferInfo(nsIDBFolderInfo **transferInfo)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void InitFromTransferInfo (in nsIDBFolderInfo transferInfo); */
NS_IMETHODIMP nsDBFolderInfo::InitFromTransferInfo(nsIDBFolderInfo *transferInfo)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void GetCharacterSet (in nsString result, out boolean usedDefault); */
NS_IMETHODIMP nsDBFolderInfo::GetCharacterSet(nsString * result, PRBool *usedDefault)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void SetCharacterSet (in nsString result); */
NS_IMETHODIMP nsDBFolderInfo::SetCharacterSet(nsString * result)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void GetCharacterSetOverride (out boolean characterSetOverride); */
NS_IMETHODIMP nsDBFolderInfo::GetCharacterSetOverride(PRBool *characterSetOverride)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void SetCharacterSetOverride (in boolean characterSetOverride); */
NS_IMETHODIMP nsDBFolderInfo::SetCharacterSetOverride(PRBool characterSetOverride)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void GetCharPtrCharacterSet (out string result); */
NS_IMETHODIMP nsDBFolderInfo::GetCharPtrCharacterSet(char **result)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void GetLocale (in nsString result); */
NS_IMETHODIMP nsDBFolderInfo::GetLocale(nsString * result)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void SetLocale (in nsString locale); */
NS_IMETHODIMP nsDBFolderInfo::SetLocale(nsString * locale)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void SetMailboxName (in nsString newBoxName); */
NS_IMETHODIMP nsDBFolderInfo::SetMailboxName(nsString * newBoxName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void GetMailboxName (in nsString boxName); */
NS_IMETHODIMP nsDBFolderInfo::GetMailboxName(nsString * boxName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void GetProperty (in string propertyName, in nsString resultProperty); */
NS_IMETHODIMP nsDBFolderInfo::GetProperty(const char *propertyName, nsString * resultProperty)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void SetProperty (in string propertyName, in nsString propertyStr); */
NS_IMETHODIMP nsDBFolderInfo::SetProperty(const char *propertyName, nsString * propertyStr)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void SetKnownArtsSet (in nsString newsArtSet); */
NS_IMETHODIMP nsDBFolderInfo::SetKnownArtsSet(nsString * newsArtSet)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void GetKnownArtsSet (in nsString newsArtSet); */
NS_IMETHODIMP nsDBFolderInfo::GetKnownArtsSet(nsString * newsArtSet)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIDBFolderInfo_h__ */
