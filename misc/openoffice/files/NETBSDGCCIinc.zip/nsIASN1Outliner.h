/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIASN1Outliner.idl
 */

#ifndef __gen_nsIASN1Outliner_h__
#define __gen_nsIASN1Outliner_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIOutlinerView_h__
#include "nsIOutlinerView.h"
#endif

#ifndef __gen_nsIX509Cert_h__
#include "nsIX509Cert.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIASN1Outliner */
#define NS_IASN1OUTLINER_IID_STR "c727b2f2-1dd1-11b2-95df-f63c15b4cd35"

#define NS_IASN1OUTLINER_IID \
  {0xc727b2f2, 0x1dd1, 0x11b2, \
    { 0x95, 0xdf, 0xf6, 0x3c, 0x15, 0xb4, 0xcd, 0x35 }}

class NS_NO_VTABLE nsIASN1Outliner : public nsIOutlinerView {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IASN1OUTLINER_IID)

  /* void loadASN1Structure (in nsIASN1Object asn1Object); */
  NS_IMETHOD LoadASN1Structure(nsIASN1Object *asn1Object) = 0;

  /* wstring getDisplayData (in unsigned long index); */
  NS_IMETHOD GetDisplayData(PRUint32 index, PRUnichar **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIASN1OUTLINER \
  NS_IMETHOD LoadASN1Structure(nsIASN1Object *asn1Object); \
  NS_IMETHOD GetDisplayData(PRUint32 index, PRUnichar **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIASN1OUTLINER(_to) \
  NS_IMETHOD LoadASN1Structure(nsIASN1Object *asn1Object) { return _to LoadASN1Structure(asn1Object); } \
  NS_IMETHOD GetDisplayData(PRUint32 index, PRUnichar **_retval) { return _to GetDisplayData(index, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIASN1OUTLINER(_to) \
  NS_IMETHOD LoadASN1Structure(nsIASN1Object *asn1Object) { return !_to ? NS_ERROR_NULL_POINTER : _to->LoadASN1Structure(asn1Object); } \
  NS_IMETHOD GetDisplayData(PRUint32 index, PRUnichar **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDisplayData(index, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsASN1Outliner : public nsIASN1Outliner
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIASN1OUTLINER

  nsASN1Outliner();
  virtual ~nsASN1Outliner();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsASN1Outliner, nsIASN1Outliner)

nsASN1Outliner::nsASN1Outliner()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsASN1Outliner::~nsASN1Outliner()
{
  /* destructor code */
}

/* void loadASN1Structure (in nsIASN1Object asn1Object); */
NS_IMETHODIMP nsASN1Outliner::LoadASN1Structure(nsIASN1Object *asn1Object)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* wstring getDisplayData (in unsigned long index); */
NS_IMETHODIMP nsASN1Outliner::GetDisplayData(PRUint32 index, PRUnichar **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif

#define NS_ASN1OUTLINER_CONTRACTID "@mozilla.org/security/nsASN1Outliner;1"

#endif /* __gen_nsIASN1Outliner_h__ */
