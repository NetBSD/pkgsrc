/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAddressBook.idl
 */

#ifndef __gen_nsIAddressBook_h__
#define __gen_nsIAddressBook_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIRDFCompositeDataSource_h__
#include "nsIRDFCompositeDataSource.h"
#endif

#ifndef __gen_nsIAddrDatabase_h__
#include "nsIAddrDatabase.h"
#endif

#ifndef __gen_nsISupportsArray_h__
#include "nsISupportsArray.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIDOMWindowInternal; /* forward declaration */

class nsIDOMXULElement; /* forward declaration */

class nsIDOMNodeList; /* forward declaration */

class nsIFileSpec; /* forward declaration */


/* starting interface:    nsIAddressBook */
#define NS_IADDRESSBOOK_IID_STR "d60b84f1-2a8c-11d3-9e07-00a0c92b5f0d"

#define NS_IADDRESSBOOK_IID \
  {0xd60b84f1, 0x2a8c, 0x11d3, \
    { 0x9e, 0x07, 0x00, 0xa0, 0xc9, 0x2b, 0x5f, 0x0d }}

class NS_NO_VTABLE nsIAddressBook : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IADDRESSBOOK_IID)

  /* void deleteCards (in nsIDOMXULElement tree, in nsIDOMXULElement srcDir, in nsIDOMNodeList node); */
  NS_IMETHOD DeleteCards(nsIDOMXULElement *tree, nsIDOMXULElement *srcDir, nsIDOMNodeList *node) = 0;

  /* void newAddressBook (in nsIRDFCompositeDataSource db, in nsIDOMXULElement srcDir, in unsigned long prefCount, [array, size_is (prefCount)] in string prefName, [array, size_is (prefCount)] in wstring prefValue); */
  NS_IMETHOD NewAddressBook(nsIRDFCompositeDataSource *db, nsIDOMXULElement *srcDir, PRUint32 prefCount, const char **prefName, const PRUnichar **prefValue) = 0;

  /* void deleteAddressBooks (in nsIRDFCompositeDataSource db, in nsISupportsArray parentDir, in nsIDOMNodeList node); */
  NS_IMETHOD DeleteAddressBooks(nsIRDFCompositeDataSource *db, nsISupportsArray *parentDir, nsIDOMNodeList *node) = 0;

  /* void printCard (); */
  NS_IMETHOD PrintCard(void) = 0;

  /* void printAddressbook (); */
  NS_IMETHOD PrintAddressbook(void) = 0;

  /* void setDocShellWindow (in nsIDOMWindowInternal win); */
  NS_IMETHOD SetDocShellWindow(nsIDOMWindowInternal *win) = 0;

  /* void importAddressBook (); */
  NS_IMETHOD ImportAddressBook(void) = 0;

  /* void convertLDIFtoMAB (in nsIFileSpec fileSpec, in boolean migrating, in nsIAddrDatabase db, in boolean bStoreLocAsHome, in boolean bImportingComm4x); */
  NS_IMETHOD ConvertLDIFtoMAB(nsIFileSpec *fileSpec, PRBool migrating, nsIAddrDatabase *db, PRBool bStoreLocAsHome, PRBool bImportingComm4x) = 0;

  /* void convertNA2toLDIF (in nsIFileSpec srcFileSpec, in nsIFileSpec dstFileSpec); */
  NS_IMETHOD ConvertNA2toLDIF(nsIFileSpec *srcFileSpec, nsIFileSpec *dstFileSpec) = 0;

  /* void getAbDatabaseFromURI (in string URI, out nsIAddrDatabase db); */
  NS_IMETHOD GetAbDatabaseFromURI(const char *URI, nsIAddrDatabase **db) = 0;

  /* boolean mailListNameExistsInDB (in wstring name, in string URI); */
  NS_IMETHOD MailListNameExistsInDB(const PRUnichar *name, const char *URI, PRBool *_retval) = 0;

  /* boolean mailListNameExists (in wstring name); */
  NS_IMETHOD MailListNameExists(const PRUnichar *name, PRBool *_retval) = 0;

  /* unsigned long getTotalCards (in string URI); */
  NS_IMETHOD GetTotalCards(const char *URI, PRUint32 *_retval) = 0;

  /* void createCollationKey (in wstring source, out wstring result); */
  NS_IMETHOD CreateCollationKey(const PRUnichar *source, PRUnichar **result) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIADDRESSBOOK \
  NS_IMETHOD DeleteCards(nsIDOMXULElement *tree, nsIDOMXULElement *srcDir, nsIDOMNodeList *node); \
  NS_IMETHOD NewAddressBook(nsIRDFCompositeDataSource *db, nsIDOMXULElement *srcDir, PRUint32 prefCount, const char **prefName, const PRUnichar **prefValue); \
  NS_IMETHOD DeleteAddressBooks(nsIRDFCompositeDataSource *db, nsISupportsArray *parentDir, nsIDOMNodeList *node); \
  NS_IMETHOD PrintCard(void); \
  NS_IMETHOD PrintAddressbook(void); \
  NS_IMETHOD SetDocShellWindow(nsIDOMWindowInternal *win); \
  NS_IMETHOD ImportAddressBook(void); \
  NS_IMETHOD ConvertLDIFtoMAB(nsIFileSpec *fileSpec, PRBool migrating, nsIAddrDatabase *db, PRBool bStoreLocAsHome, PRBool bImportingComm4x); \
  NS_IMETHOD ConvertNA2toLDIF(nsIFileSpec *srcFileSpec, nsIFileSpec *dstFileSpec); \
  NS_IMETHOD GetAbDatabaseFromURI(const char *URI, nsIAddrDatabase **db); \
  NS_IMETHOD MailListNameExistsInDB(const PRUnichar *name, const char *URI, PRBool *_retval); \
  NS_IMETHOD MailListNameExists(const PRUnichar *name, PRBool *_retval); \
  NS_IMETHOD GetTotalCards(const char *URI, PRUint32 *_retval); \
  NS_IMETHOD CreateCollationKey(const PRUnichar *source, PRUnichar **result); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIADDRESSBOOK(_to) \
  NS_IMETHOD DeleteCards(nsIDOMXULElement *tree, nsIDOMXULElement *srcDir, nsIDOMNodeList *node) { return _to DeleteCards(tree, srcDir, node); } \
  NS_IMETHOD NewAddressBook(nsIRDFCompositeDataSource *db, nsIDOMXULElement *srcDir, PRUint32 prefCount, const char **prefName, const PRUnichar **prefValue) { return _to NewAddressBook(db, srcDir, prefCount, prefName, prefValue); } \
  NS_IMETHOD DeleteAddressBooks(nsIRDFCompositeDataSource *db, nsISupportsArray *parentDir, nsIDOMNodeList *node) { return _to DeleteAddressBooks(db, parentDir, node); } \
  NS_IMETHOD PrintCard(void) { return _to PrintCard(); } \
  NS_IMETHOD PrintAddressbook(void) { return _to PrintAddressbook(); } \
  NS_IMETHOD SetDocShellWindow(nsIDOMWindowInternal *win) { return _to SetDocShellWindow(win); } \
  NS_IMETHOD ImportAddressBook(void) { return _to ImportAddressBook(); } \
  NS_IMETHOD ConvertLDIFtoMAB(nsIFileSpec *fileSpec, PRBool migrating, nsIAddrDatabase *db, PRBool bStoreLocAsHome, PRBool bImportingComm4x) { return _to ConvertLDIFtoMAB(fileSpec, migrating, db, bStoreLocAsHome, bImportingComm4x); } \
  NS_IMETHOD ConvertNA2toLDIF(nsIFileSpec *srcFileSpec, nsIFileSpec *dstFileSpec) { return _to ConvertNA2toLDIF(srcFileSpec, dstFileSpec); } \
  NS_IMETHOD GetAbDatabaseFromURI(const char *URI, nsIAddrDatabase **db) { return _to GetAbDatabaseFromURI(URI, db); } \
  NS_IMETHOD MailListNameExistsInDB(const PRUnichar *name, const char *URI, PRBool *_retval) { return _to MailListNameExistsInDB(name, URI, _retval); } \
  NS_IMETHOD MailListNameExists(const PRUnichar *name, PRBool *_retval) { return _to MailListNameExists(name, _retval); } \
  NS_IMETHOD GetTotalCards(const char *URI, PRUint32 *_retval) { return _to GetTotalCards(URI, _retval); } \
  NS_IMETHOD CreateCollationKey(const PRUnichar *source, PRUnichar **result) { return _to CreateCollationKey(source, result); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIADDRESSBOOK(_to) \
  NS_IMETHOD DeleteCards(nsIDOMXULElement *tree, nsIDOMXULElement *srcDir, nsIDOMNodeList *node) { return !_to ? NS_ERROR_NULL_POINTER : _to->DeleteCards(tree, srcDir, node); } \
  NS_IMETHOD NewAddressBook(nsIRDFCompositeDataSource *db, nsIDOMXULElement *srcDir, PRUint32 prefCount, const char **prefName, const PRUnichar **prefValue) { return !_to ? NS_ERROR_NULL_POINTER : _to->NewAddressBook(db, srcDir, prefCount, prefName, prefValue); } \
  NS_IMETHOD DeleteAddressBooks(nsIRDFCompositeDataSource *db, nsISupportsArray *parentDir, nsIDOMNodeList *node) { return !_to ? NS_ERROR_NULL_POINTER : _to->DeleteAddressBooks(db, parentDir, node); } \
  NS_IMETHOD PrintCard(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->PrintCard(); } \
  NS_IMETHOD PrintAddressbook(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->PrintAddressbook(); } \
  NS_IMETHOD SetDocShellWindow(nsIDOMWindowInternal *win) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDocShellWindow(win); } \
  NS_IMETHOD ImportAddressBook(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->ImportAddressBook(); } \
  NS_IMETHOD ConvertLDIFtoMAB(nsIFileSpec *fileSpec, PRBool migrating, nsIAddrDatabase *db, PRBool bStoreLocAsHome, PRBool bImportingComm4x) { return !_to ? NS_ERROR_NULL_POINTER : _to->ConvertLDIFtoMAB(fileSpec, migrating, db, bStoreLocAsHome, bImportingComm4x); } \
  NS_IMETHOD ConvertNA2toLDIF(nsIFileSpec *srcFileSpec, nsIFileSpec *dstFileSpec) { return !_to ? NS_ERROR_NULL_POINTER : _to->ConvertNA2toLDIF(srcFileSpec, dstFileSpec); } \
  NS_IMETHOD GetAbDatabaseFromURI(const char *URI, nsIAddrDatabase **db) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAbDatabaseFromURI(URI, db); } \
  NS_IMETHOD MailListNameExistsInDB(const PRUnichar *name, const char *URI, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->MailListNameExistsInDB(name, URI, _retval); } \
  NS_IMETHOD MailListNameExists(const PRUnichar *name, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->MailListNameExists(name, _retval); } \
  NS_IMETHOD GetTotalCards(const char *URI, PRUint32 *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetTotalCards(URI, _retval); } \
  NS_IMETHOD CreateCollationKey(const PRUnichar *source, PRUnichar **result) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateCollationKey(source, result); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAddressBook : public nsIAddressBook
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIADDRESSBOOK

  nsAddressBook();
  virtual ~nsAddressBook();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAddressBook, nsIAddressBook)

nsAddressBook::nsAddressBook()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAddressBook::~nsAddressBook()
{
  /* destructor code */
}

/* void deleteCards (in nsIDOMXULElement tree, in nsIDOMXULElement srcDir, in nsIDOMNodeList node); */
NS_IMETHODIMP nsAddressBook::DeleteCards(nsIDOMXULElement *tree, nsIDOMXULElement *srcDir, nsIDOMNodeList *node)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void newAddressBook (in nsIRDFCompositeDataSource db, in nsIDOMXULElement srcDir, in unsigned long prefCount, [array, size_is (prefCount)] in string prefName, [array, size_is (prefCount)] in wstring prefValue); */
NS_IMETHODIMP nsAddressBook::NewAddressBook(nsIRDFCompositeDataSource *db, nsIDOMXULElement *srcDir, PRUint32 prefCount, const char **prefName, const PRUnichar **prefValue)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void deleteAddressBooks (in nsIRDFCompositeDataSource db, in nsISupportsArray parentDir, in nsIDOMNodeList node); */
NS_IMETHODIMP nsAddressBook::DeleteAddressBooks(nsIRDFCompositeDataSource *db, nsISupportsArray *parentDir, nsIDOMNodeList *node)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void printCard (); */
NS_IMETHODIMP nsAddressBook::PrintCard()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void printAddressbook (); */
NS_IMETHODIMP nsAddressBook::PrintAddressbook()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setDocShellWindow (in nsIDOMWindowInternal win); */
NS_IMETHODIMP nsAddressBook::SetDocShellWindow(nsIDOMWindowInternal *win)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void importAddressBook (); */
NS_IMETHODIMP nsAddressBook::ImportAddressBook()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void convertLDIFtoMAB (in nsIFileSpec fileSpec, in boolean migrating, in nsIAddrDatabase db, in boolean bStoreLocAsHome, in boolean bImportingComm4x); */
NS_IMETHODIMP nsAddressBook::ConvertLDIFtoMAB(nsIFileSpec *fileSpec, PRBool migrating, nsIAddrDatabase *db, PRBool bStoreLocAsHome, PRBool bImportingComm4x)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void convertNA2toLDIF (in nsIFileSpec srcFileSpec, in nsIFileSpec dstFileSpec); */
NS_IMETHODIMP nsAddressBook::ConvertNA2toLDIF(nsIFileSpec *srcFileSpec, nsIFileSpec *dstFileSpec)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void getAbDatabaseFromURI (in string URI, out nsIAddrDatabase db); */
NS_IMETHODIMP nsAddressBook::GetAbDatabaseFromURI(const char *URI, nsIAddrDatabase **db)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean mailListNameExistsInDB (in wstring name, in string URI); */
NS_IMETHODIMP nsAddressBook::MailListNameExistsInDB(const PRUnichar *name, const char *URI, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean mailListNameExists (in wstring name); */
NS_IMETHODIMP nsAddressBook::MailListNameExists(const PRUnichar *name, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* unsigned long getTotalCards (in string URI); */
NS_IMETHODIMP nsAddressBook::GetTotalCards(const char *URI, PRUint32 *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void createCollationKey (in wstring source, out wstring result); */
NS_IMETHODIMP nsAddressBook::CreateCollationKey(const PRUnichar *source, PRUnichar **result)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAddressBook_h__ */
