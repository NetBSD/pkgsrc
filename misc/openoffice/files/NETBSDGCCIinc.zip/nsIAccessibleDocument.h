/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAccessibleDocument.idl
 */

#ifndef __gen_nsIAccessibleDocument_h__
#define __gen_nsIAccessibleDocument_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIAccessible_h__
#include "nsIAccessible.h"
#endif

#ifndef __gen_domstubs_h__
#include "domstubs.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIDocument; /* forward declaration */


/* starting interface:    nsIAccessibleDocument */
#define NS_IACCESSIBLEDOCUMENT_IID_STR "8781fc88-355f-4439-881f-6504a0a1ceb6"

#define NS_IACCESSIBLEDOCUMENT_IID \
  {0x8781fc88, 0x355f, 0x4439, \
    { 0x88, 0x1f, 0x65, 0x04, 0xa0, 0xa1, 0xce, 0xb6 }}

class NS_NO_VTABLE nsIAccessibleDocument : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IACCESSIBLEDOCUMENT_IID)

  /* readonly attribute DOMString URL; */
  NS_IMETHOD GetURL(nsAWritableString & aURL) = 0;

  /* readonly attribute DOMString title; */
  NS_IMETHOD GetTitle(nsAWritableString & aTitle) = 0;

  /* readonly attribute DOMString mimeType; */
  NS_IMETHOD GetMimeType(nsAWritableString & aMimeType) = 0;

  /* readonly attribute DOMString docType; */
  NS_IMETHOD GetDocType(nsAWritableString & aDocType) = 0;

  /* DOMString getNameSpaceURIForID (in short nameSpaceID); */
  NS_IMETHOD GetNameSpaceURIForID(PRInt16 nameSpaceID, nsAWritableString & _retval) = 0;

  /* [noscript] nsIDocument getDocument (); */
  NS_IMETHOD GetDocument(nsIDocument **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIACCESSIBLEDOCUMENT \
  NS_IMETHOD GetURL(nsAWritableString & aURL); \
  NS_IMETHOD GetTitle(nsAWritableString & aTitle); \
  NS_IMETHOD GetMimeType(nsAWritableString & aMimeType); \
  NS_IMETHOD GetDocType(nsAWritableString & aDocType); \
  NS_IMETHOD GetNameSpaceURIForID(PRInt16 nameSpaceID, nsAWritableString & _retval); \
  NS_IMETHOD GetDocument(nsIDocument **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIACCESSIBLEDOCUMENT(_to) \
  NS_IMETHOD GetURL(nsAWritableString & aURL) { return _to GetURL(aURL); } \
  NS_IMETHOD GetTitle(nsAWritableString & aTitle) { return _to GetTitle(aTitle); } \
  NS_IMETHOD GetMimeType(nsAWritableString & aMimeType) { return _to GetMimeType(aMimeType); } \
  NS_IMETHOD GetDocType(nsAWritableString & aDocType) { return _to GetDocType(aDocType); } \
  NS_IMETHOD GetNameSpaceURIForID(PRInt16 nameSpaceID, nsAWritableString & _retval) { return _to GetNameSpaceURIForID(nameSpaceID, _retval); } \
  NS_IMETHOD GetDocument(nsIDocument **_retval) { return _to GetDocument(_retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIACCESSIBLEDOCUMENT(_to) \
  NS_IMETHOD GetURL(nsAWritableString & aURL) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetURL(aURL); } \
  NS_IMETHOD GetTitle(nsAWritableString & aTitle) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetTitle(aTitle); } \
  NS_IMETHOD GetMimeType(nsAWritableString & aMimeType) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetMimeType(aMimeType); } \
  NS_IMETHOD GetDocType(nsAWritableString & aDocType) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDocType(aDocType); } \
  NS_IMETHOD GetNameSpaceURIForID(PRInt16 nameSpaceID, nsAWritableString & _retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetNameSpaceURIForID(nameSpaceID, _retval); } \
  NS_IMETHOD GetDocument(nsIDocument **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDocument(_retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAccessibleDocument : public nsIAccessibleDocument
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIACCESSIBLEDOCUMENT

  nsAccessibleDocument();
  virtual ~nsAccessibleDocument();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAccessibleDocument, nsIAccessibleDocument)

nsAccessibleDocument::nsAccessibleDocument()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAccessibleDocument::~nsAccessibleDocument()
{
  /* destructor code */
}

/* readonly attribute DOMString URL; */
NS_IMETHODIMP nsAccessibleDocument::GetURL(nsAWritableString & aURL)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute DOMString title; */
NS_IMETHODIMP nsAccessibleDocument::GetTitle(nsAWritableString & aTitle)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute DOMString mimeType; */
NS_IMETHODIMP nsAccessibleDocument::GetMimeType(nsAWritableString & aMimeType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute DOMString docType; */
NS_IMETHODIMP nsAccessibleDocument::GetDocType(nsAWritableString & aDocType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* DOMString getNameSpaceURIForID (in short nameSpaceID); */
NS_IMETHODIMP nsAccessibleDocument::GetNameSpaceURIForID(PRInt16 nameSpaceID, nsAWritableString & _retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] nsIDocument getDocument (); */
NS_IMETHODIMP nsAccessibleDocument::GetDocument(nsIDocument **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAccessibleDocument_h__ */
