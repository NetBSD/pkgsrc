/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIControllerCommand.idl
 */

#ifndef __gen_nsIControllerCommand_h__
#define __gen_nsIControllerCommand_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIControllerCommand */
#define NS_ICONTROLLERCOMMAND_IID_STR "0eae9a46-1dd2-11b2-aca0-9176f05fe9db"

#define NS_ICONTROLLERCOMMAND_IID \
  {0x0eae9a46, 0x1dd2, 0x11b2, \
    { 0xac, 0xa0, 0x91, 0x76, 0xf0, 0x5f, 0xe9, 0xdb }}

/**
 * nsIControllerCommand
 *
 * A generic command interface. You can register an nsIControllerCommand
 * with the nsIControllerCommandManager.
 */
class NS_NO_VTABLE nsIControllerCommand : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ICONTROLLERCOMMAND_IID)

  /**
   * Returns true if the command is currently enabled. An nsIControllerCommand
   * can implement more than one commands; say, a group of related commands
   * (e.g. delete left/delete right). Because of this, the command name is
   * passed to each method.
   *
   * @param aCommandName  the name of the command for which we want the enabled
   *                      state.
   * @param aCommandRefCon    a cookie held by the nsIControllerCommandManager,
   *                  allowing the command to get some context information.
   *                  The contents of this cookie are implementation-defined.
   */
  /* boolean isCommandEnabled (in DOMString aCommandName, in nsISupports aCommandRefCon); */
  NS_IMETHOD IsCommandEnabled(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon, PRBool *_retval) = 0;

  /**
   * Execute the name command.
   *
   * @param aCommandName  the name of the command to execute.
   * 
   * @param aCommandRefCon    a cookie held by the nsIControllerCommandManager,
   *                  allowing the command to get some context information.
   *                  The contents of this cookie are implementation-defined.
   */
  /* void doCommand (in DOMString aCommandName, in nsISupports aCommandRefCon); */
  NS_IMETHOD DoCommand(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSICONTROLLERCOMMAND \
  NS_IMETHOD IsCommandEnabled(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon, PRBool *_retval); \
  NS_IMETHOD DoCommand(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSICONTROLLERCOMMAND(_to) \
  NS_IMETHOD IsCommandEnabled(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon, PRBool *_retval) { return _to IsCommandEnabled(aCommandName, aCommandRefCon, _retval); } \
  NS_IMETHOD DoCommand(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon) { return _to DoCommand(aCommandName, aCommandRefCon); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSICONTROLLERCOMMAND(_to) \
  NS_IMETHOD IsCommandEnabled(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->IsCommandEnabled(aCommandName, aCommandRefCon, _retval); } \
  NS_IMETHOD DoCommand(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon) { return !_to ? NS_ERROR_NULL_POINTER : _to->DoCommand(aCommandName, aCommandRefCon); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsControllerCommand : public nsIControllerCommand
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSICONTROLLERCOMMAND

  nsControllerCommand();
  virtual ~nsControllerCommand();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsControllerCommand, nsIControllerCommand)

nsControllerCommand::nsControllerCommand()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsControllerCommand::~nsControllerCommand()
{
  /* destructor code */
}

/* boolean isCommandEnabled (in DOMString aCommandName, in nsISupports aCommandRefCon); */
NS_IMETHODIMP nsControllerCommand::IsCommandEnabled(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void doCommand (in DOMString aCommandName, in nsISupports aCommandRefCon); */
NS_IMETHODIMP nsControllerCommand::DoCommand(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIStateUpdatingControllerCommand */
#define NS_ISTATEUPDATINGCONTROLLERCOMMAND_IID_STR "78ad2381-1ae6-11d4-9f7e-a6d3f6dffffc"

#define NS_ISTATEUPDATINGCONTROLLERCOMMAND_IID \
  {0x78ad2381, 0x1ae6, 0x11d4, \
    { 0x9f, 0x7e, 0xa6, 0xd3, 0xf6, 0xdf, 0xff, 0xfc }}

/**
 * nsIStatefulControllerCommand
 *
 * An extension of the basic nsIControllerCommand interface, for commands
 * that have to update state (e.g. "bold" in an editor). Note that the 
 * implementation of the command *must* be stateless (since a given command
 * can be shared between clients of the controller command manager). State
 * must be stored/update via the refCon.
 */
class NS_NO_VTABLE nsIStateUpdatingControllerCommand : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ISTATEUPDATINGCONTROLLERCOMMAND_IID)

  /**
   * Update the state of the named command.
   *
   * @param aCommandName     the name of the command for which we want to update state.
   * 
   * @param aCommandRefCon    a cookie held by the nsIControllerCommandManager,
   *                  allowing the command to get some context information.
   *                  The contents of this cookie are implementation-defined.
   */
  /* void updateCommandState (in DOMString aCommandName, in nsISupports aCommandRefCon); */
  NS_IMETHOD UpdateCommandState(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSISTATEUPDATINGCONTROLLERCOMMAND \
  NS_IMETHOD UpdateCommandState(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSISTATEUPDATINGCONTROLLERCOMMAND(_to) \
  NS_IMETHOD UpdateCommandState(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon) { return _to UpdateCommandState(aCommandName, aCommandRefCon); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSISTATEUPDATINGCONTROLLERCOMMAND(_to) \
  NS_IMETHOD UpdateCommandState(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon) { return !_to ? NS_ERROR_NULL_POINTER : _to->UpdateCommandState(aCommandName, aCommandRefCon); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsStateUpdatingControllerCommand : public nsIStateUpdatingControllerCommand
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSISTATEUPDATINGCONTROLLERCOMMAND

  nsStateUpdatingControllerCommand();
  virtual ~nsStateUpdatingControllerCommand();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsStateUpdatingControllerCommand, nsIStateUpdatingControllerCommand)

nsStateUpdatingControllerCommand::nsStateUpdatingControllerCommand()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsStateUpdatingControllerCommand::~nsStateUpdatingControllerCommand()
{
  /* destructor code */
}

/* void updateCommandState (in DOMString aCommandName, in nsISupports aCommandRefCon); */
NS_IMETHODIMP nsStateUpdatingControllerCommand::UpdateCommandState(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIControllerCommandManager */
#define NS_ICONTROLLERCOMMANDMANAGER_IID_STR "65a2f51a-1dd2-11b2-889f-d886b255ffe7"

#define NS_ICONTROLLERCOMMANDMANAGER_IID \
  {0x65a2f51a, 0x1dd2, 0x11b2, \
    { 0x88, 0x9f, 0xd8, 0x86, 0xb2, 0x55, 0xff, 0xe7 }}

/**
 * nsIControllerCommandManager
 * 
 * An interface via which a controller can maintain a series of commands,
 * and efficiently dispatch commands to their respective handlers.
 *
 * Controllers that use an nsIControllerCommandManager should support
 * nsIInterfaceRequestor, and be able to return an interface to their
 * controller command manager via getInterface().
 * 
 */
class NS_NO_VTABLE nsIControllerCommandManager : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ICONTROLLERCOMMANDMANAGER_IID)

  /**
   * Register and unregister commands with the command manager.
   *
   * @param aCommandName  the name of the command under which to register or
   *                      unregister the given command handler.
   *
   * @param aCommand      the handler for this command.
   */
  /* void registerCommand (in DOMString aCommandName, in nsIControllerCommand aCommand); */
  NS_IMETHOD RegisterCommand(const nsAReadableString & aCommandName, nsIControllerCommand *aCommand) = 0;

  /* void unregisterCommand (in DOMString aCommandName, in nsIControllerCommand aCommand); */
  NS_IMETHOD UnregisterCommand(const nsAReadableString & aCommandName, nsIControllerCommand *aCommand) = 0;

  /**
   * Find the command handler which has been registered to handle the named command.
   *
   * @param aCommandName  the name of the command to find the handler for.
   */
  /* nsIControllerCommand findCommandHandler (in DOMString aCommandName); */
  NS_IMETHOD FindCommandHandler(const nsAReadableString & aCommandName, nsIControllerCommand **_retval) = 0;

  /**
   * Get whether the named command is enabled.
   *
   * @param aCommandName    the name of the command to test
   * @param aCommandRefCon  the command context data
   */
  /* boolean isCommandEnabled (in DOMString aCommandName, in nsISupports aCommandRefCon); */
  NS_IMETHOD IsCommandEnabled(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon, PRBool *_retval) = 0;

  /**
   * Tell the command to udpate its state (if it is a state updating command)
   *
   * @param aCommandName    the name of the command to update
   * @param aCommandRefCon  the command context data
   */
  /* void updateCommandState (in DOMString aCommandName, in nsISupports aCommandRefCon); */
  NS_IMETHOD UpdateCommandState(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon) = 0;

  /**
   * Get whether the named command is supported.
   *
   * @param aCommandName    the name of the command to test
   * @param aCommandRefCon  the command context data
   */
  /* boolean supportsCommand (in DOMString aCommandName, in nsISupports aCommandRefCon); */
  NS_IMETHOD SupportsCommand(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon, PRBool *_retval) = 0;

  /**
   * Execute the named command.
   *
   * @param aCommandName    the name of the command to execute
   * @param aCommandRefCon  the command context data
   */
  /* void doCommand (in DOMString aCommandName, in nsISupports aCommandRefCon); */
  NS_IMETHOD DoCommand(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSICONTROLLERCOMMANDMANAGER \
  NS_IMETHOD RegisterCommand(const nsAReadableString & aCommandName, nsIControllerCommand *aCommand); \
  NS_IMETHOD UnregisterCommand(const nsAReadableString & aCommandName, nsIControllerCommand *aCommand); \
  NS_IMETHOD FindCommandHandler(const nsAReadableString & aCommandName, nsIControllerCommand **_retval); \
  NS_IMETHOD IsCommandEnabled(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon, PRBool *_retval); \
  NS_IMETHOD UpdateCommandState(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon); \
  NS_IMETHOD SupportsCommand(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon, PRBool *_retval); \
  NS_IMETHOD DoCommand(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSICONTROLLERCOMMANDMANAGER(_to) \
  NS_IMETHOD RegisterCommand(const nsAReadableString & aCommandName, nsIControllerCommand *aCommand) { return _to RegisterCommand(aCommandName, aCommand); } \
  NS_IMETHOD UnregisterCommand(const nsAReadableString & aCommandName, nsIControllerCommand *aCommand) { return _to UnregisterCommand(aCommandName, aCommand); } \
  NS_IMETHOD FindCommandHandler(const nsAReadableString & aCommandName, nsIControllerCommand **_retval) { return _to FindCommandHandler(aCommandName, _retval); } \
  NS_IMETHOD IsCommandEnabled(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon, PRBool *_retval) { return _to IsCommandEnabled(aCommandName, aCommandRefCon, _retval); } \
  NS_IMETHOD UpdateCommandState(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon) { return _to UpdateCommandState(aCommandName, aCommandRefCon); } \
  NS_IMETHOD SupportsCommand(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon, PRBool *_retval) { return _to SupportsCommand(aCommandName, aCommandRefCon, _retval); } \
  NS_IMETHOD DoCommand(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon) { return _to DoCommand(aCommandName, aCommandRefCon); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSICONTROLLERCOMMANDMANAGER(_to) \
  NS_IMETHOD RegisterCommand(const nsAReadableString & aCommandName, nsIControllerCommand *aCommand) { return !_to ? NS_ERROR_NULL_POINTER : _to->RegisterCommand(aCommandName, aCommand); } \
  NS_IMETHOD UnregisterCommand(const nsAReadableString & aCommandName, nsIControllerCommand *aCommand) { return !_to ? NS_ERROR_NULL_POINTER : _to->UnregisterCommand(aCommandName, aCommand); } \
  NS_IMETHOD FindCommandHandler(const nsAReadableString & aCommandName, nsIControllerCommand **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->FindCommandHandler(aCommandName, _retval); } \
  NS_IMETHOD IsCommandEnabled(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->IsCommandEnabled(aCommandName, aCommandRefCon, _retval); } \
  NS_IMETHOD UpdateCommandState(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon) { return !_to ? NS_ERROR_NULL_POINTER : _to->UpdateCommandState(aCommandName, aCommandRefCon); } \
  NS_IMETHOD SupportsCommand(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->SupportsCommand(aCommandName, aCommandRefCon, _retval); } \
  NS_IMETHOD DoCommand(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon) { return !_to ? NS_ERROR_NULL_POINTER : _to->DoCommand(aCommandName, aCommandRefCon); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsControllerCommandManager : public nsIControllerCommandManager
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSICONTROLLERCOMMANDMANAGER

  nsControllerCommandManager();
  virtual ~nsControllerCommandManager();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsControllerCommandManager, nsIControllerCommandManager)

nsControllerCommandManager::nsControllerCommandManager()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsControllerCommandManager::~nsControllerCommandManager()
{
  /* destructor code */
}

/* void registerCommand (in DOMString aCommandName, in nsIControllerCommand aCommand); */
NS_IMETHODIMP nsControllerCommandManager::RegisterCommand(const nsAReadableString & aCommandName, nsIControllerCommand *aCommand)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void unregisterCommand (in DOMString aCommandName, in nsIControllerCommand aCommand); */
NS_IMETHODIMP nsControllerCommandManager::UnregisterCommand(const nsAReadableString & aCommandName, nsIControllerCommand *aCommand)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIControllerCommand findCommandHandler (in DOMString aCommandName); */
NS_IMETHODIMP nsControllerCommandManager::FindCommandHandler(const nsAReadableString & aCommandName, nsIControllerCommand **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean isCommandEnabled (in DOMString aCommandName, in nsISupports aCommandRefCon); */
NS_IMETHODIMP nsControllerCommandManager::IsCommandEnabled(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void updateCommandState (in DOMString aCommandName, in nsISupports aCommandRefCon); */
NS_IMETHODIMP nsControllerCommandManager::UpdateCommandState(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean supportsCommand (in DOMString aCommandName, in nsISupports aCommandRefCon); */
NS_IMETHODIMP nsControllerCommandManager::SupportsCommand(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void doCommand (in DOMString aCommandName, in nsISupports aCommandRefCon); */
NS_IMETHODIMP nsControllerCommandManager::DoCommand(const nsAReadableString & aCommandName, nsISupports *aCommandRefCon)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif

nsresult
NS_NewControllerCommandManager(nsIControllerCommandManager** aResult);

#endif /* __gen_nsIControllerCommand_h__ */
