/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIController.idl
 */

#ifndef __gen_nsIController_h__
#define __gen_nsIController_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIController */
#define NS_ICONTROLLER_IID_STR "d5b61b82-1da4-11d3-bf87-00105a1b0627"

#define NS_ICONTROLLER_IID \
  {0xd5b61b82, 0x1da4, 0x11d3, \
    { 0xbf, 0x87, 0x00, 0x10, 0x5a, 0x1b, 0x06, 0x27 }}

class NS_NO_VTABLE nsIController : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ICONTROLLER_IID)

  /* boolean isCommandEnabled (in DOMString command); */
  NS_IMETHOD IsCommandEnabled(const nsAReadableString & command, PRBool *_retval) = 0;

  /* boolean supportsCommand (in DOMString command); */
  NS_IMETHOD SupportsCommand(const nsAReadableString & command, PRBool *_retval) = 0;

  /* void doCommand (in DOMString command); */
  NS_IMETHOD DoCommand(const nsAReadableString & command) = 0;

  /* void onEvent (in DOMString eventName); */
  NS_IMETHOD OnEvent(const nsAReadableString & eventName) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSICONTROLLER \
  NS_IMETHOD IsCommandEnabled(const nsAReadableString & command, PRBool *_retval); \
  NS_IMETHOD SupportsCommand(const nsAReadableString & command, PRBool *_retval); \
  NS_IMETHOD DoCommand(const nsAReadableString & command); \
  NS_IMETHOD OnEvent(const nsAReadableString & eventName); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSICONTROLLER(_to) \
  NS_IMETHOD IsCommandEnabled(const nsAReadableString & command, PRBool *_retval) { return _to IsCommandEnabled(command, _retval); } \
  NS_IMETHOD SupportsCommand(const nsAReadableString & command, PRBool *_retval) { return _to SupportsCommand(command, _retval); } \
  NS_IMETHOD DoCommand(const nsAReadableString & command) { return _to DoCommand(command); } \
  NS_IMETHOD OnEvent(const nsAReadableString & eventName) { return _to OnEvent(eventName); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSICONTROLLER(_to) \
  NS_IMETHOD IsCommandEnabled(const nsAReadableString & command, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->IsCommandEnabled(command, _retval); } \
  NS_IMETHOD SupportsCommand(const nsAReadableString & command, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->SupportsCommand(command, _retval); } \
  NS_IMETHOD DoCommand(const nsAReadableString & command) { return !_to ? NS_ERROR_NULL_POINTER : _to->DoCommand(command); } \
  NS_IMETHOD OnEvent(const nsAReadableString & eventName) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnEvent(eventName); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsController : public nsIController
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSICONTROLLER

  nsController();
  virtual ~nsController();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsController, nsIController)

nsController::nsController()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsController::~nsController()
{
  /* destructor code */
}

/* boolean isCommandEnabled (in DOMString command); */
NS_IMETHODIMP nsController::IsCommandEnabled(const nsAReadableString & command, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean supportsCommand (in DOMString command); */
NS_IMETHODIMP nsController::SupportsCommand(const nsAReadableString & command, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void doCommand (in DOMString command); */
NS_IMETHODIMP nsController::DoCommand(const nsAReadableString & command)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void onEvent (in DOMString eventName); */
NS_IMETHODIMP nsController::OnEvent(const nsAReadableString & eventName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIController_h__ */
