/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM imgILoader.idl
 */

#ifndef __gen_imgILoader_h__
#define __gen_imgILoader_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_gfxtypes_h__
#include "gfxtypes.h"
#endif

#ifndef __gen_nsIRequest_h__
#include "nsIRequest.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class imgIDecoderObserver; /* forward declaration */

class imgIRequest; /* forward declaration */

class nsIChannel; /* forward declaration */

class nsILoadGroup; /* forward declaration */

class nsIStreamListener; /* forward declaration */

class nsIURI; /* forward declaration */

class nsISimpleEnumerator; /* forward declaration */


/* starting interface:    imgILoader */
#define IMGILOADER_IID_STR "4c8cf1e0-1dd2-11b2-aff9-c51cdbfcb6da"

#define IMGILOADER_IID \
  {0x4c8cf1e0, 0x1dd2, 0x11b2, \
    { 0xaf, 0xf9, 0xc5, 0x1c, 0xdb, 0xfc, 0xb6, 0xda }}

/**
 * imgILoader interface
 *
 * @author Stuart Parmenter <pavlov@netscape.com>
 * @version 0.2
 * @see imagelib2
 */
class NS_NO_VTABLE imgILoader : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(IMGILOADER_IID)

  /**
   * Start the load and decode of an image.
   * @param aURI the URI to load
   * @param aLoadGroup Loadgroup to put the image load into
   * @param aObserver the observer
   * @param aCX some random data
   * @param aLoadFlags Load flags for the request
   */
  /* imgIRequest loadImage (in nsIURI aURI, in nsILoadGroup aLoadGroup, in imgIDecoderObserver aObserver, in nsISupports aCX, in nsLoadFlags aLoadFlags); */
  NS_IMETHOD LoadImage(nsIURI *aURI, nsILoadGroup *aLoadGroup, imgIDecoderObserver *aObserver, nsISupports *aCX, nsLoadFlags aLoadFlags, imgIRequest **_retval) = 0;

  /**
   * Start the load and decode of an image.
   * @param uri the URI to load
   * @param aObserver the observer
   * @param cx some random data
   */
  /* imgIRequest loadImageWithChannel (in nsIChannel aChannel, in imgIDecoderObserver aObserver, in nsISupports cx, out nsIStreamListener aListener); */
  NS_IMETHOD LoadImageWithChannel(nsIChannel *aChannel, imgIDecoderObserver *aObserver, nsISupports *cx, nsIStreamListener **aListener, imgIRequest **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_IMGILOADER \
  NS_IMETHOD LoadImage(nsIURI *aURI, nsILoadGroup *aLoadGroup, imgIDecoderObserver *aObserver, nsISupports *aCX, nsLoadFlags aLoadFlags, imgIRequest **_retval); \
  NS_IMETHOD LoadImageWithChannel(nsIChannel *aChannel, imgIDecoderObserver *aObserver, nsISupports *cx, nsIStreamListener **aListener, imgIRequest **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_IMGILOADER(_to) \
  NS_IMETHOD LoadImage(nsIURI *aURI, nsILoadGroup *aLoadGroup, imgIDecoderObserver *aObserver, nsISupports *aCX, nsLoadFlags aLoadFlags, imgIRequest **_retval) { return _to LoadImage(aURI, aLoadGroup, aObserver, aCX, aLoadFlags, _retval); } \
  NS_IMETHOD LoadImageWithChannel(nsIChannel *aChannel, imgIDecoderObserver *aObserver, nsISupports *cx, nsIStreamListener **aListener, imgIRequest **_retval) { return _to LoadImageWithChannel(aChannel, aObserver, cx, aListener, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_IMGILOADER(_to) \
  NS_IMETHOD LoadImage(nsIURI *aURI, nsILoadGroup *aLoadGroup, imgIDecoderObserver *aObserver, nsISupports *aCX, nsLoadFlags aLoadFlags, imgIRequest **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->LoadImage(aURI, aLoadGroup, aObserver, aCX, aLoadFlags, _retval); } \
  NS_IMETHOD LoadImageWithChannel(nsIChannel *aChannel, imgIDecoderObserver *aObserver, nsISupports *cx, nsIStreamListener **aListener, imgIRequest **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->LoadImageWithChannel(aChannel, aObserver, cx, aListener, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class _MYCLASS_ : public imgILoader
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_IMGILOADER

  _MYCLASS_();
  virtual ~_MYCLASS_();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(_MYCLASS_, imgILoader)

_MYCLASS_::_MYCLASS_()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

_MYCLASS_::~_MYCLASS_()
{
  /* destructor code */
}

/* imgIRequest loadImage (in nsIURI aURI, in nsILoadGroup aLoadGroup, in imgIDecoderObserver aObserver, in nsISupports aCX, in nsLoadFlags aLoadFlags); */
NS_IMETHODIMP _MYCLASS_::LoadImage(nsIURI *aURI, nsILoadGroup *aLoadGroup, imgIDecoderObserver *aObserver, nsISupports *aCX, nsLoadFlags aLoadFlags, imgIRequest **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* imgIRequest loadImageWithChannel (in nsIChannel aChannel, in imgIDecoderObserver aObserver, in nsISupports cx, out nsIStreamListener aListener); */
NS_IMETHODIMP _MYCLASS_::LoadImageWithChannel(nsIChannel *aChannel, imgIDecoderObserver *aObserver, nsISupports *cx, nsIStreamListener **aListener, imgIRequest **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_imgILoader_h__ */
