/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAddrDBAnnouncer.idl
 */

#ifndef __gen_nsIAddrDBAnnouncer_h__
#define __gen_nsIAddrDBAnnouncer_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIAbCard_h__
#include "nsIAbCard.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIAddrDBListener; /* forward declaration */


/* starting interface:    nsIAddrDBAnnouncer */
#define NS_IADDRDBANNOUNCER_IID_STR "a4186d8a-1dd0-11d3-a303-001083003d0c"

#define NS_IADDRDBANNOUNCER_IID \
  {0xa4186d8a, 0x1dd0, 0x11d3, \
    { 0xa3, 0x03, 0x00, 0x10, 0x83, 0x00, 0x3d, 0x0c }}

class NS_NO_VTABLE nsIAddrDBAnnouncer : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IADDRDBANNOUNCER_IID)

  /* void addListener (in nsIAddrDBListener listener); */
  NS_IMETHOD AddListener(nsIAddrDBListener *listener) = 0;

  /* void removeListener (in nsIAddrDBListener listener); */
  NS_IMETHOD RemoveListener(nsIAddrDBListener *listener) = 0;

  /* void notifyCardAttribChange (in unsigned long abCode, in nsIAddrDBListener instigator); */
  NS_IMETHOD NotifyCardAttribChange(PRUint32 abCode, nsIAddrDBListener *instigator) = 0;

  /* void notifyCardEntryChange (in unsigned long abCode, in nsIAbCard card, in nsIAddrDBListener instigator); */
  NS_IMETHOD NotifyCardEntryChange(PRUint32 abCode, nsIAbCard *card, nsIAddrDBListener *instigator) = 0;

  /* void notifyAnnouncerGoingAway (); */
  NS_IMETHOD NotifyAnnouncerGoingAway(void) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIADDRDBANNOUNCER \
  NS_IMETHOD AddListener(nsIAddrDBListener *listener); \
  NS_IMETHOD RemoveListener(nsIAddrDBListener *listener); \
  NS_IMETHOD NotifyCardAttribChange(PRUint32 abCode, nsIAddrDBListener *instigator); \
  NS_IMETHOD NotifyCardEntryChange(PRUint32 abCode, nsIAbCard *card, nsIAddrDBListener *instigator); \
  NS_IMETHOD NotifyAnnouncerGoingAway(void); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIADDRDBANNOUNCER(_to) \
  NS_IMETHOD AddListener(nsIAddrDBListener *listener) { return _to AddListener(listener); } \
  NS_IMETHOD RemoveListener(nsIAddrDBListener *listener) { return _to RemoveListener(listener); } \
  NS_IMETHOD NotifyCardAttribChange(PRUint32 abCode, nsIAddrDBListener *instigator) { return _to NotifyCardAttribChange(abCode, instigator); } \
  NS_IMETHOD NotifyCardEntryChange(PRUint32 abCode, nsIAbCard *card, nsIAddrDBListener *instigator) { return _to NotifyCardEntryChange(abCode, card, instigator); } \
  NS_IMETHOD NotifyAnnouncerGoingAway(void) { return _to NotifyAnnouncerGoingAway(); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIADDRDBANNOUNCER(_to) \
  NS_IMETHOD AddListener(nsIAddrDBListener *listener) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddListener(listener); } \
  NS_IMETHOD RemoveListener(nsIAddrDBListener *listener) { return !_to ? NS_ERROR_NULL_POINTER : _to->RemoveListener(listener); } \
  NS_IMETHOD NotifyCardAttribChange(PRUint32 abCode, nsIAddrDBListener *instigator) { return !_to ? NS_ERROR_NULL_POINTER : _to->NotifyCardAttribChange(abCode, instigator); } \
  NS_IMETHOD NotifyCardEntryChange(PRUint32 abCode, nsIAbCard *card, nsIAddrDBListener *instigator) { return !_to ? NS_ERROR_NULL_POINTER : _to->NotifyCardEntryChange(abCode, card, instigator); } \
  NS_IMETHOD NotifyAnnouncerGoingAway(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->NotifyAnnouncerGoingAway(); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAddrDBAnnouncer : public nsIAddrDBAnnouncer
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIADDRDBANNOUNCER

  nsAddrDBAnnouncer();
  virtual ~nsAddrDBAnnouncer();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAddrDBAnnouncer, nsIAddrDBAnnouncer)

nsAddrDBAnnouncer::nsAddrDBAnnouncer()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAddrDBAnnouncer::~nsAddrDBAnnouncer()
{
  /* destructor code */
}

/* void addListener (in nsIAddrDBListener listener); */
NS_IMETHODIMP nsAddrDBAnnouncer::AddListener(nsIAddrDBListener *listener)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void removeListener (in nsIAddrDBListener listener); */
NS_IMETHODIMP nsAddrDBAnnouncer::RemoveListener(nsIAddrDBListener *listener)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void notifyCardAttribChange (in unsigned long abCode, in nsIAddrDBListener instigator); */
NS_IMETHODIMP nsAddrDBAnnouncer::NotifyCardAttribChange(PRUint32 abCode, nsIAddrDBListener *instigator)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void notifyCardEntryChange (in unsigned long abCode, in nsIAbCard card, in nsIAddrDBListener instigator); */
NS_IMETHODIMP nsAddrDBAnnouncer::NotifyCardEntryChange(PRUint32 abCode, nsIAbCard *card, nsIAddrDBListener *instigator)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void notifyAnnouncerGoingAway (); */
NS_IMETHODIMP nsAddrDBAnnouncer::NotifyAnnouncerGoingAway()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAddrDBAnnouncer_h__ */
