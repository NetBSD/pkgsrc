/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsICopyMessageListener.idl
 */

#ifndef __gen_nsICopyMessageListener_h__
#define __gen_nsICopyMessageListener_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_MailNewsTypes2_h__
#include "MailNewsTypes2.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIMsgDBHdr; /* forward declaration */

class nsIInputStream; /* forward declaration */

#include "nsIInputStream.h"

/* starting interface:    nsICopyMessageListener */
#define NS_ICOPYMESSAGELISTENER_IID_STR "53ca78fe-e231-11d2-8a4d-0060b0fc04d2"

#define NS_ICOPYMESSAGELISTENER_IID \
  {0x53ca78fe, 0xe231, 0x11d2, \
    { 0x8a, 0x4d, 0x00, 0x60, 0xb0, 0xfc, 0x04, 0xd2 }}

class NS_NO_VTABLE nsICopyMessageListener : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ICOPYMESSAGELISTENER_IID)

  /* void beginCopy (in nsIMsgDBHdr message); */
  NS_IMETHOD BeginCopy(nsIMsgDBHdr *message) = 0;

  /* void startMessage (); */
  NS_IMETHOD StartMessage(void) = 0;

  /* void copyData (in nsIInputStream aIStream, in long aLength); */
  NS_IMETHOD CopyData(nsIInputStream *aIStream, PRInt32 aLength) = 0;

  /* void endMessage (in nsMsgKey key); */
  NS_IMETHOD EndMessage(nsMsgKey key) = 0;

  /* void endCopy (in boolean copySucceeded); */
  NS_IMETHOD EndCopy(PRBool copySucceeded) = 0;

  /* void endMove (); */
  NS_IMETHOD EndMove(void) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSICOPYMESSAGELISTENER \
  NS_IMETHOD BeginCopy(nsIMsgDBHdr *message); \
  NS_IMETHOD StartMessage(void); \
  NS_IMETHOD CopyData(nsIInputStream *aIStream, PRInt32 aLength); \
  NS_IMETHOD EndMessage(nsMsgKey key); \
  NS_IMETHOD EndCopy(PRBool copySucceeded); \
  NS_IMETHOD EndMove(void); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSICOPYMESSAGELISTENER(_to) \
  NS_IMETHOD BeginCopy(nsIMsgDBHdr *message) { return _to BeginCopy(message); } \
  NS_IMETHOD StartMessage(void) { return _to StartMessage(); } \
  NS_IMETHOD CopyData(nsIInputStream *aIStream, PRInt32 aLength) { return _to CopyData(aIStream, aLength); } \
  NS_IMETHOD EndMessage(nsMsgKey key) { return _to EndMessage(key); } \
  NS_IMETHOD EndCopy(PRBool copySucceeded) { return _to EndCopy(copySucceeded); } \
  NS_IMETHOD EndMove(void) { return _to EndMove(); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSICOPYMESSAGELISTENER(_to) \
  NS_IMETHOD BeginCopy(nsIMsgDBHdr *message) { return !_to ? NS_ERROR_NULL_POINTER : _to->BeginCopy(message); } \
  NS_IMETHOD StartMessage(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->StartMessage(); } \
  NS_IMETHOD CopyData(nsIInputStream *aIStream, PRInt32 aLength) { return !_to ? NS_ERROR_NULL_POINTER : _to->CopyData(aIStream, aLength); } \
  NS_IMETHOD EndMessage(nsMsgKey key) { return !_to ? NS_ERROR_NULL_POINTER : _to->EndMessage(key); } \
  NS_IMETHOD EndCopy(PRBool copySucceeded) { return !_to ? NS_ERROR_NULL_POINTER : _to->EndCopy(copySucceeded); } \
  NS_IMETHOD EndMove(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->EndMove(); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsCopyMessageListener : public nsICopyMessageListener
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSICOPYMESSAGELISTENER

  nsCopyMessageListener();
  virtual ~nsCopyMessageListener();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsCopyMessageListener, nsICopyMessageListener)

nsCopyMessageListener::nsCopyMessageListener()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsCopyMessageListener::~nsCopyMessageListener()
{
  /* destructor code */
}

/* void beginCopy (in nsIMsgDBHdr message); */
NS_IMETHODIMP nsCopyMessageListener::BeginCopy(nsIMsgDBHdr *message)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void startMessage (); */
NS_IMETHODIMP nsCopyMessageListener::StartMessage()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void copyData (in nsIInputStream aIStream, in long aLength); */
NS_IMETHODIMP nsCopyMessageListener::CopyData(nsIInputStream *aIStream, PRInt32 aLength)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void endMessage (in nsMsgKey key); */
NS_IMETHODIMP nsCopyMessageListener::EndMessage(nsMsgKey key)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void endCopy (in boolean copySucceeded); */
NS_IMETHODIMP nsCopyMessageListener::EndCopy(PRBool copySucceeded)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void endMove (); */
NS_IMETHODIMP nsCopyMessageListener::EndMove()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsICopyMessageListener_h__ */
