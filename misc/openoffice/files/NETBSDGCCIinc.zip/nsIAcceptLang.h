/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAcceptLang.idl
 */

#ifndef __gen_nsIAcceptLang_h__
#define __gen_nsIAcceptLang_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
// Define Contractid and CID
// {383F6C15-2797-11d4-BA1C-001083344DE7} 
#define NS_ACCEPTLANG_CID \
{ 0x383f6c15, 0x2797, 0x11d4, \
	{ 0xba, 0x1c, 0x0, 0x10, 0x83, 0x34, 0x4d, 0xe7 }}
#define NS_ACCEPTLANG_CONTRACTID "@mozilla.org/intl/acceptlang;1"

/* starting interface:    nsIAcceptLang */
#define NS_IACCEPTLANG_IID_STR "383f6c16-2797-11d4-ba1c-001083344de7"

#define NS_IACCEPTLANG_IID \
  {0x383f6c16, 0x2797, 0x11d4, \
    { 0xba, 0x1c, 0x00, 0x10, 0x83, 0x34, 0x4d, 0xe7 }}

class NS_NO_VTABLE nsIAcceptLang : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IACCEPTLANG_IID)

  /* wstring getAcceptLangFromLocale ([const] in wstring aLocale); */
  NS_IMETHOD GetAcceptLangFromLocale(const PRUnichar *aLocale, PRUnichar **_retval) = 0;

  /* wstring getLocaleFromAcceptLang ([const] in wstring aName); */
  NS_IMETHOD GetLocaleFromAcceptLang(const PRUnichar *aName, PRUnichar **_retval) = 0;

  /* wstring acceptLang2List ([const] in wstring aName, [const] in wstring aList); */
  NS_IMETHOD AcceptLang2List(const PRUnichar *aName, const PRUnichar *aList, PRUnichar **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIACCEPTLANG \
  NS_IMETHOD GetAcceptLangFromLocale(const PRUnichar *aLocale, PRUnichar **_retval); \
  NS_IMETHOD GetLocaleFromAcceptLang(const PRUnichar *aName, PRUnichar **_retval); \
  NS_IMETHOD AcceptLang2List(const PRUnichar *aName, const PRUnichar *aList, PRUnichar **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIACCEPTLANG(_to) \
  NS_IMETHOD GetAcceptLangFromLocale(const PRUnichar *aLocale, PRUnichar **_retval) { return _to GetAcceptLangFromLocale(aLocale, _retval); } \
  NS_IMETHOD GetLocaleFromAcceptLang(const PRUnichar *aName, PRUnichar **_retval) { return _to GetLocaleFromAcceptLang(aName, _retval); } \
  NS_IMETHOD AcceptLang2List(const PRUnichar *aName, const PRUnichar *aList, PRUnichar **_retval) { return _to AcceptLang2List(aName, aList, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIACCEPTLANG(_to) \
  NS_IMETHOD GetAcceptLangFromLocale(const PRUnichar *aLocale, PRUnichar **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAcceptLangFromLocale(aLocale, _retval); } \
  NS_IMETHOD GetLocaleFromAcceptLang(const PRUnichar *aName, PRUnichar **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetLocaleFromAcceptLang(aName, _retval); } \
  NS_IMETHOD AcceptLang2List(const PRUnichar *aName, const PRUnichar *aList, PRUnichar **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->AcceptLang2List(aName, aList, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAcceptLang : public nsIAcceptLang
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIACCEPTLANG

  nsAcceptLang();
  virtual ~nsAcceptLang();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAcceptLang, nsIAcceptLang)

nsAcceptLang::nsAcceptLang()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAcceptLang::~nsAcceptLang()
{
  /* destructor code */
}

/* wstring getAcceptLangFromLocale ([const] in wstring aLocale); */
NS_IMETHODIMP nsAcceptLang::GetAcceptLangFromLocale(const PRUnichar *aLocale, PRUnichar **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* wstring getLocaleFromAcceptLang ([const] in wstring aName); */
NS_IMETHODIMP nsAcceptLang::GetLocaleFromAcceptLang(const PRUnichar *aName, PRUnichar **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* wstring acceptLang2List ([const] in wstring aName, [const] in wstring aList); */
NS_IMETHODIMP nsAcceptLang::AcceptLang2List(const PRUnichar *aName, const PRUnichar *aList, PRUnichar **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAcceptLang_h__ */
