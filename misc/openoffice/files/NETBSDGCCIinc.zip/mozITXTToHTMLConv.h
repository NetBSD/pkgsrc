/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM mozITXTToHTMLConv.idl
 */

#ifndef __gen_mozITXTToHTMLConv_h__
#define __gen_mozITXTToHTMLConv_h__


#ifndef __gen_nsIStreamConverter_h__
#include "nsIStreamConverter.h"
#endif

#ifndef __gen_nsrootidl_h__
#include "nsrootidl.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
// {77c0e42a-1dd2-11b2-8ebf-edc6606f2f4b}
#define MOZITXTTOHTMLCONV_CID \
    { 0x77c0e42a, 0x1dd2, 0x11b2, \
    { 0x8e, 0xbf, 0xed, 0xc6, 0x60, 0x6f, 0x2f, 0x4b } }

/* starting interface:    mozITXTToHTMLConv */
#define MOZITXTTOHTMLCONV_IID_STR "77c0e42a-1dd2-11b2-8ebf-edc6606f2f4b"

#define MOZITXTTOHTMLCONV_IID \
  {0x77c0e42a, 0x1dd2, 0x11b2, \
    { 0x8e, 0xbf, 0xed, 0xc6, 0x60, 0x6f, 0x2f, 0x4b }}

class NS_NO_VTABLE mozITXTToHTMLConv : public nsIStreamConverter {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(MOZITXTTOHTMLCONV_IID)

  enum { kURLs = 2U };

  enum { kGlyphSubstitution = 4U };

  enum { kStructPhrase = 8U };

  /**
  @param text: plain text to scan. May be a line, paragraph (recommended)
               or just a substring.<p>
               Must be non-escaped, pure unicode.<p>
               <em>Note:</em> ScanTXT(a, o) + ScanTXT(b, o) may be !=
               Scan(a + b, o)
  @param whattodo: Bitfield describing the modes of operation
  @result      "<", ">" and "&" are escaped and HTML tags are inserted where
               appropriate.
 */
  /* wstring scanTXT ([const] in wstring text, in unsigned long whattodo); */
  NS_IMETHOD ScanTXT(const PRUnichar *text, PRUint32 whattodo, PRUnichar **_retval) = 0;

  /**
  Adds additional formatting to user edited text, that the user was too lazy
  or "unknowledged" (DELETEME: is that a word?) to make.
  <p>
  <em>Note:</em> Don't use kGlyphSubstitution with this function. This option
  generates tags, that are unuseable for UAs other than Mozilla. This would
  be a data loss bug.

  @param text: HTML source to scan. May be a line, paragraph (recommended)
               or just a substring.<p>
               Must be correct HTML. "<", ">" and "&" must be escaped,
               other chars must be pure unicode.<p>
               <em>Note:</em> ScanTXT(a, o) + ScanTXT(b, o) may be !=
               Scan(a + b, o)
  @param whattodo: Bitfield describing the modes of operation
  @result      Additional HTML tags are inserted where appropriate.
 */
  /* wstring scanHTML ([const] in wstring text, in unsigned long whattodo); */
  NS_IMETHOD ScanHTML(const PRUnichar *text, PRUint32 whattodo, PRUnichar **_retval) = 0;

  /**
  @param line: line in original msg, possibly starting starting with
               txt quote tags like ">"
  @param logLineStart: pos in line, where the real content (logical line)
               begins, i.e. pos after all txt quote tags.
               E.g. position of "t" in "> > text".
               Initial value must be 0, unless line is not real line.
  @return      Cite Level, i.e. number of txt quote tags found, i.e. number of
               nested quotes.
 */
  /* unsigned long citeLevelTXT ([const] in wstring line, out unsigned long logLineStart); */
  NS_IMETHOD CiteLevelTXT(const PRUnichar *line, PRUint32 *logLineStart, PRUint32 *_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_MOZITXTTOHTMLCONV \
  NS_IMETHOD ScanTXT(const PRUnichar *text, PRUint32 whattodo, PRUnichar **_retval); \
  NS_IMETHOD ScanHTML(const PRUnichar *text, PRUint32 whattodo, PRUnichar **_retval); \
  NS_IMETHOD CiteLevelTXT(const PRUnichar *line, PRUint32 *logLineStart, PRUint32 *_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_MOZITXTTOHTMLCONV(_to) \
  NS_IMETHOD ScanTXT(const PRUnichar *text, PRUint32 whattodo, PRUnichar **_retval) { return _to ScanTXT(text, whattodo, _retval); } \
  NS_IMETHOD ScanHTML(const PRUnichar *text, PRUint32 whattodo, PRUnichar **_retval) { return _to ScanHTML(text, whattodo, _retval); } \
  NS_IMETHOD CiteLevelTXT(const PRUnichar *line, PRUint32 *logLineStart, PRUint32 *_retval) { return _to CiteLevelTXT(line, logLineStart, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_MOZITXTTOHTMLCONV(_to) \
  NS_IMETHOD ScanTXT(const PRUnichar *text, PRUint32 whattodo, PRUnichar **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->ScanTXT(text, whattodo, _retval); } \
  NS_IMETHOD ScanHTML(const PRUnichar *text, PRUint32 whattodo, PRUnichar **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->ScanHTML(text, whattodo, _retval); } \
  NS_IMETHOD CiteLevelTXT(const PRUnichar *line, PRUint32 *logLineStart, PRUint32 *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CiteLevelTXT(line, logLineStart, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class _MYCLASS_ : public mozITXTToHTMLConv
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_MOZITXTTOHTMLCONV

  _MYCLASS_();
  virtual ~_MYCLASS_();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(_MYCLASS_, mozITXTToHTMLConv)

_MYCLASS_::_MYCLASS_()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

_MYCLASS_::~_MYCLASS_()
{
  /* destructor code */
}

/* wstring scanTXT ([const] in wstring text, in unsigned long whattodo); */
NS_IMETHODIMP _MYCLASS_::ScanTXT(const PRUnichar *text, PRUint32 whattodo, PRUnichar **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* wstring scanHTML ([const] in wstring text, in unsigned long whattodo); */
NS_IMETHODIMP _MYCLASS_::ScanHTML(const PRUnichar *text, PRUint32 whattodo, PRUnichar **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* unsigned long citeLevelTXT ([const] in wstring line, out unsigned long logLineStart); */
NS_IMETHODIMP _MYCLASS_::CiteLevelTXT(const PRUnichar *line, PRUint32 *logLineStart, PRUint32 *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_mozITXTToHTMLConv_h__ */
