/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIBadCertListener.idl
 */

#ifndef __gen_nsIBadCertListener_h__
#define __gen_nsIBadCertListener_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIX509Cert; /* forward declaration */

class nsITransportSecurityInfo; /* forward declaration */


/* starting interface:    nsIBadCertListener */
#define NS_IBADCERTLISTENER_IID_STR "86960956-edb0-11d4-998b-00b0d02354a0"

#define NS_IBADCERTLISTENER_IID \
  {0x86960956, 0xedb0, 0x11d4, \
    { 0x99, 0x8b, 0x00, 0xb0, 0xd0, 0x23, 0x54, 0xa0 }}

class NS_NO_VTABLE nsIBadCertListener : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IBADCERTLISTENER_IID)

  enum { UNINIT_ADD_FLAG = -1 };

  enum { ADD_TRUSTED_FOR_SESSION = 1 };

  enum { ADD_TRUSTED_PERMANENTLY = 2 };

  /* boolean unknownIssuer (in nsITransportSecurityInfo socketInfo, in nsIX509Cert cert, out short certAddType); */
  NS_IMETHOD UnknownIssuer(nsITransportSecurityInfo *socketInfo, nsIX509Cert *cert, PRInt16 *certAddType, PRBool *_retval) = 0;

  /* boolean mismatchDomain (in nsITransportSecurityInfo socketInfo, in wstring targetURL, in nsIX509Cert cert); */
  NS_IMETHOD MismatchDomain(nsITransportSecurityInfo *socketInfo, const PRUnichar *targetURL, nsIX509Cert *cert, PRBool *_retval) = 0;

  /* boolean certExpired (in nsITransportSecurityInfo socketInfo, in nsIX509Cert cert); */
  NS_IMETHOD CertExpired(nsITransportSecurityInfo *socketInfo, nsIX509Cert *cert, PRBool *_retval) = 0;

  /* void crlNextupdate (in nsITransportSecurityInfo socketInfo, in wstring targetURL, in nsIX509Cert cert); */
  NS_IMETHOD CrlNextupdate(nsITransportSecurityInfo *socketInfo, const PRUnichar *targetURL, nsIX509Cert *cert) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIBADCERTLISTENER \
  NS_IMETHOD UnknownIssuer(nsITransportSecurityInfo *socketInfo, nsIX509Cert *cert, PRInt16 *certAddType, PRBool *_retval); \
  NS_IMETHOD MismatchDomain(nsITransportSecurityInfo *socketInfo, const PRUnichar *targetURL, nsIX509Cert *cert, PRBool *_retval); \
  NS_IMETHOD CertExpired(nsITransportSecurityInfo *socketInfo, nsIX509Cert *cert, PRBool *_retval); \
  NS_IMETHOD CrlNextupdate(nsITransportSecurityInfo *socketInfo, const PRUnichar *targetURL, nsIX509Cert *cert); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIBADCERTLISTENER(_to) \
  NS_IMETHOD UnknownIssuer(nsITransportSecurityInfo *socketInfo, nsIX509Cert *cert, PRInt16 *certAddType, PRBool *_retval) { return _to UnknownIssuer(socketInfo, cert, certAddType, _retval); } \
  NS_IMETHOD MismatchDomain(nsITransportSecurityInfo *socketInfo, const PRUnichar *targetURL, nsIX509Cert *cert, PRBool *_retval) { return _to MismatchDomain(socketInfo, targetURL, cert, _retval); } \
  NS_IMETHOD CertExpired(nsITransportSecurityInfo *socketInfo, nsIX509Cert *cert, PRBool *_retval) { return _to CertExpired(socketInfo, cert, _retval); } \
  NS_IMETHOD CrlNextupdate(nsITransportSecurityInfo *socketInfo, const PRUnichar *targetURL, nsIX509Cert *cert) { return _to CrlNextupdate(socketInfo, targetURL, cert); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIBADCERTLISTENER(_to) \
  NS_IMETHOD UnknownIssuer(nsITransportSecurityInfo *socketInfo, nsIX509Cert *cert, PRInt16 *certAddType, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->UnknownIssuer(socketInfo, cert, certAddType, _retval); } \
  NS_IMETHOD MismatchDomain(nsITransportSecurityInfo *socketInfo, const PRUnichar *targetURL, nsIX509Cert *cert, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->MismatchDomain(socketInfo, targetURL, cert, _retval); } \
  NS_IMETHOD CertExpired(nsITransportSecurityInfo *socketInfo, nsIX509Cert *cert, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CertExpired(socketInfo, cert, _retval); } \
  NS_IMETHOD CrlNextupdate(nsITransportSecurityInfo *socketInfo, const PRUnichar *targetURL, nsIX509Cert *cert) { return !_to ? NS_ERROR_NULL_POINTER : _to->CrlNextupdate(socketInfo, targetURL, cert); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsBadCertListener : public nsIBadCertListener
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIBADCERTLISTENER

  nsBadCertListener();
  virtual ~nsBadCertListener();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsBadCertListener, nsIBadCertListener)

nsBadCertListener::nsBadCertListener()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsBadCertListener::~nsBadCertListener()
{
  /* destructor code */
}

/* boolean unknownIssuer (in nsITransportSecurityInfo socketInfo, in nsIX509Cert cert, out short certAddType); */
NS_IMETHODIMP nsBadCertListener::UnknownIssuer(nsITransportSecurityInfo *socketInfo, nsIX509Cert *cert, PRInt16 *certAddType, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean mismatchDomain (in nsITransportSecurityInfo socketInfo, in wstring targetURL, in nsIX509Cert cert); */
NS_IMETHODIMP nsBadCertListener::MismatchDomain(nsITransportSecurityInfo *socketInfo, const PRUnichar *targetURL, nsIX509Cert *cert, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean certExpired (in nsITransportSecurityInfo socketInfo, in nsIX509Cert cert); */
NS_IMETHODIMP nsBadCertListener::CertExpired(nsITransportSecurityInfo *socketInfo, nsIX509Cert *cert, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void crlNextupdate (in nsITransportSecurityInfo socketInfo, in wstring targetURL, in nsIX509Cert cert); */
NS_IMETHODIMP nsBadCertListener::CrlNextupdate(nsITransportSecurityInfo *socketInfo, const PRUnichar *targetURL, nsIX509Cert *cert)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIBadCertListener_h__ */
