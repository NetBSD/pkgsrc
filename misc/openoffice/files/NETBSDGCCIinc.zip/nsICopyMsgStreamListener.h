/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsICopyMsgStreamListener.idl
 */

#ifndef __gen_nsICopyMsgStreamListener_h__
#define __gen_nsICopyMsgStreamListener_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIMsgFolder_h__
#include "nsIMsgFolder.h"
#endif

#ifndef __gen_nsICopyMessageListener_h__
#include "nsICopyMessageListener.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsICopyMessageStreamListener */
#define NS_ICOPYMESSAGESTREAMLISTENER_IID_STR "7741daec-2125-11d3-8a90-0060b0fc04d2"

#define NS_ICOPYMESSAGESTREAMLISTENER_IID \
  {0x7741daec, 0x2125, 0x11d3, \
    { 0x8a, 0x90, 0x00, 0x60, 0xb0, 0xfc, 0x04, 0xd2 }}

class NS_NO_VTABLE nsICopyMessageStreamListener : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ICOPYMESSAGESTREAMLISTENER_IID)

  /* void Init (in nsIMsgFolder srcFolder, in nsICopyMessageListener destination, in nsISupports listenerData); */
  NS_IMETHOD Init(nsIMsgFolder *srcFolder, nsICopyMessageListener *destination, nsISupports *listenerData) = 0;

  /* void StartMessage (); */
  NS_IMETHOD StartMessage(void) = 0;

  /* void EndMessage (in nsMsgKey key); */
  NS_IMETHOD EndMessage(nsMsgKey key) = 0;

  /* void EndCopy (in nsISupports url, in nsresult aStatus); */
  NS_IMETHOD EndCopy(nsISupports *url, nsresult aStatus) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSICOPYMESSAGESTREAMLISTENER \
  NS_IMETHOD Init(nsIMsgFolder *srcFolder, nsICopyMessageListener *destination, nsISupports *listenerData); \
  NS_IMETHOD StartMessage(void); \
  NS_IMETHOD EndMessage(nsMsgKey key); \
  NS_IMETHOD EndCopy(nsISupports *url, nsresult aStatus); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSICOPYMESSAGESTREAMLISTENER(_to) \
  NS_IMETHOD Init(nsIMsgFolder *srcFolder, nsICopyMessageListener *destination, nsISupports *listenerData) { return _to Init(srcFolder, destination, listenerData); } \
  NS_IMETHOD StartMessage(void) { return _to StartMessage(); } \
  NS_IMETHOD EndMessage(nsMsgKey key) { return _to EndMessage(key); } \
  NS_IMETHOD EndCopy(nsISupports *url, nsresult aStatus) { return _to EndCopy(url, aStatus); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSICOPYMESSAGESTREAMLISTENER(_to) \
  NS_IMETHOD Init(nsIMsgFolder *srcFolder, nsICopyMessageListener *destination, nsISupports *listenerData) { return !_to ? NS_ERROR_NULL_POINTER : _to->Init(srcFolder, destination, listenerData); } \
  NS_IMETHOD StartMessage(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->StartMessage(); } \
  NS_IMETHOD EndMessage(nsMsgKey key) { return !_to ? NS_ERROR_NULL_POINTER : _to->EndMessage(key); } \
  NS_IMETHOD EndCopy(nsISupports *url, nsresult aStatus) { return !_to ? NS_ERROR_NULL_POINTER : _to->EndCopy(url, aStatus); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsCopyMessageStreamListener : public nsICopyMessageStreamListener
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSICOPYMESSAGESTREAMLISTENER

  nsCopyMessageStreamListener();
  virtual ~nsCopyMessageStreamListener();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsCopyMessageStreamListener, nsICopyMessageStreamListener)

nsCopyMessageStreamListener::nsCopyMessageStreamListener()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsCopyMessageStreamListener::~nsCopyMessageStreamListener()
{
  /* destructor code */
}

/* void Init (in nsIMsgFolder srcFolder, in nsICopyMessageListener destination, in nsISupports listenerData); */
NS_IMETHODIMP nsCopyMessageStreamListener::Init(nsIMsgFolder *srcFolder, nsICopyMessageListener *destination, nsISupports *listenerData)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void StartMessage (); */
NS_IMETHODIMP nsCopyMessageStreamListener::StartMessage()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void EndMessage (in nsMsgKey key); */
NS_IMETHODIMP nsCopyMessageStreamListener::EndMessage(nsMsgKey key)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void EndCopy (in nsISupports url, in nsresult aStatus); */
NS_IMETHODIMP nsCopyMessageStreamListener::EndCopy(nsISupports *url, nsresult aStatus)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsICopyMsgStreamListener_h__ */
