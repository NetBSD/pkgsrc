/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbSyncPostListener.idl
 */

#ifndef __gen_nsIAbSyncPostListener_h__
#define __gen_nsIAbSyncPostListener_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsrootidl_h__
#include "nsrootidl.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIAbSyncPostListener */
#define NS_IABSYNCPOSTLISTENER_IID_STR "e0ed29e0-098a-11d4-8fd6-00a024a7beef"

#define NS_IABSYNCPOSTLISTENER_IID \
  {0xe0ed29e0, 0x098a, 0x11d4, \
    { 0x8f, 0xd6, 0x00, 0xa0, 0x24, 0xa7, 0xbe, 0xef }}

class NS_NO_VTABLE nsIAbSyncPostListener : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABSYNCPOSTLISTENER_IID)

  /**
     * Notify the observer that the AB Sync Authorization operation has begun. 
     *
     */
  /* void OnStartAuthOperation (); */
  NS_IMETHOD OnStartAuthOperation(void) = 0;

  /**
     * Notify the observer that the AB Sync operation has been completed.  
     * 
     * This method is called regardless of whether the the operation was 
     * successful.
     * 
     *  aTransactionID    - the ID for this particular request
     *  aStatus           - Status code for the sync request
     *  aMsg              - A text string describing the error (if any).
     *  aCookie           - hmmm...cooookies!
     */
  /* void OnStopAuthOperation (in nsresult aStatus, in wstring aMsg, in string aCookie); */
  NS_IMETHOD OnStopAuthOperation(nsresult aStatus, const PRUnichar *aMsg, const char *aCookie) = 0;

  /**
     * Notify the observer that the AB Sync operation has begun. This method is
     * called only once, at the beginning of a sync transaction
     *
     */
  /* void OnStartOperation (in PRInt32 aTransactionID, in PRUint32 aMsgSize); */
  NS_IMETHOD OnStartOperation(PRInt32 aTransactionID, PRUint32 aMsgSize) = 0;

  /**
     * Notify the observer that progress as occurred for the AB Sync operation
     */
  /* void OnProgress (in PRInt32 aTransactionID, in PRUint32 aProgress, in PRUint32 aProgressMax); */
  NS_IMETHOD OnProgress(PRInt32 aTransactionID, PRUint32 aProgress, PRUint32 aProgressMax) = 0;

  /**
     * Notify the observer with a status message for sync operation
     */
  /* void OnStatus (in PRInt32 aTransactionID, in wstring aMsg); */
  NS_IMETHOD OnStatus(PRInt32 aTransactionID, const PRUnichar *aMsg) = 0;

  /**
     * Notify the observer that the AB Sync operation has been sent.  This 
     * method is called once when the networking library has finished processing 
     * the sync operation.
     * 
     * This method is called regardless of whether the the operation was 
     * successful.
     * 
     *  aTransactionID    - the ID for this particular request
     *  aStatus           - Status code for the sync request
     *  aMsg              - A text string describing the error (if any).
     *  aProtocolResponse - The protocol response sent by the AB server
     */
  /* void OnStopOperation (in PRInt32 aTransactionID, in nsresult aStatus, in wstring aMsg, in string aProtocolResponse); */
  NS_IMETHOD OnStopOperation(PRInt32 aTransactionID, nsresult aStatus, const PRUnichar *aMsg, const char *aProtocolResponse) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABSYNCPOSTLISTENER \
  NS_IMETHOD OnStartAuthOperation(void); \
  NS_IMETHOD OnStopAuthOperation(nsresult aStatus, const PRUnichar *aMsg, const char *aCookie); \
  NS_IMETHOD OnStartOperation(PRInt32 aTransactionID, PRUint32 aMsgSize); \
  NS_IMETHOD OnProgress(PRInt32 aTransactionID, PRUint32 aProgress, PRUint32 aProgressMax); \
  NS_IMETHOD OnStatus(PRInt32 aTransactionID, const PRUnichar *aMsg); \
  NS_IMETHOD OnStopOperation(PRInt32 aTransactionID, nsresult aStatus, const PRUnichar *aMsg, const char *aProtocolResponse); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABSYNCPOSTLISTENER(_to) \
  NS_IMETHOD OnStartAuthOperation(void) { return _to OnStartAuthOperation(); } \
  NS_IMETHOD OnStopAuthOperation(nsresult aStatus, const PRUnichar *aMsg, const char *aCookie) { return _to OnStopAuthOperation(aStatus, aMsg, aCookie); } \
  NS_IMETHOD OnStartOperation(PRInt32 aTransactionID, PRUint32 aMsgSize) { return _to OnStartOperation(aTransactionID, aMsgSize); } \
  NS_IMETHOD OnProgress(PRInt32 aTransactionID, PRUint32 aProgress, PRUint32 aProgressMax) { return _to OnProgress(aTransactionID, aProgress, aProgressMax); } \
  NS_IMETHOD OnStatus(PRInt32 aTransactionID, const PRUnichar *aMsg) { return _to OnStatus(aTransactionID, aMsg); } \
  NS_IMETHOD OnStopOperation(PRInt32 aTransactionID, nsresult aStatus, const PRUnichar *aMsg, const char *aProtocolResponse) { return _to OnStopOperation(aTransactionID, aStatus, aMsg, aProtocolResponse); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABSYNCPOSTLISTENER(_to) \
  NS_IMETHOD OnStartAuthOperation(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnStartAuthOperation(); } \
  NS_IMETHOD OnStopAuthOperation(nsresult aStatus, const PRUnichar *aMsg, const char *aCookie) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnStopAuthOperation(aStatus, aMsg, aCookie); } \
  NS_IMETHOD OnStartOperation(PRInt32 aTransactionID, PRUint32 aMsgSize) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnStartOperation(aTransactionID, aMsgSize); } \
  NS_IMETHOD OnProgress(PRInt32 aTransactionID, PRUint32 aProgress, PRUint32 aProgressMax) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnProgress(aTransactionID, aProgress, aProgressMax); } \
  NS_IMETHOD OnStatus(PRInt32 aTransactionID, const PRUnichar *aMsg) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnStatus(aTransactionID, aMsg); } \
  NS_IMETHOD OnStopOperation(PRInt32 aTransactionID, nsresult aStatus, const PRUnichar *aMsg, const char *aProtocolResponse) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnStopOperation(aTransactionID, aStatus, aMsg, aProtocolResponse); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbSyncPostListener : public nsIAbSyncPostListener
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABSYNCPOSTLISTENER

  nsAbSyncPostListener();
  virtual ~nsAbSyncPostListener();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbSyncPostListener, nsIAbSyncPostListener)

nsAbSyncPostListener::nsAbSyncPostListener()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAbSyncPostListener::~nsAbSyncPostListener()
{
  /* destructor code */
}

/* void OnStartAuthOperation (); */
NS_IMETHODIMP nsAbSyncPostListener::OnStartAuthOperation()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void OnStopAuthOperation (in nsresult aStatus, in wstring aMsg, in string aCookie); */
NS_IMETHODIMP nsAbSyncPostListener::OnStopAuthOperation(nsresult aStatus, const PRUnichar *aMsg, const char *aCookie)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void OnStartOperation (in PRInt32 aTransactionID, in PRUint32 aMsgSize); */
NS_IMETHODIMP nsAbSyncPostListener::OnStartOperation(PRInt32 aTransactionID, PRUint32 aMsgSize)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void OnProgress (in PRInt32 aTransactionID, in PRUint32 aProgress, in PRUint32 aProgressMax); */
NS_IMETHODIMP nsAbSyncPostListener::OnProgress(PRInt32 aTransactionID, PRUint32 aProgress, PRUint32 aProgressMax)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void OnStatus (in PRInt32 aTransactionID, in wstring aMsg); */
NS_IMETHODIMP nsAbSyncPostListener::OnStatus(PRInt32 aTransactionID, const PRUnichar *aMsg)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void OnStopOperation (in PRInt32 aTransactionID, in nsresult aStatus, in wstring aMsg, in string aProtocolResponse); */
NS_IMETHODIMP nsAbSyncPostListener::OnStopOperation(PRInt32 aTransactionID, nsresult aStatus, const PRUnichar *aMsg, const char *aProtocolResponse)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbSyncPostListener_h__ */
