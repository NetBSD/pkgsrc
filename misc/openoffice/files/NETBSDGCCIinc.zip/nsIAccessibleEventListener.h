/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAccessibleEventListener.idl
 */

#ifndef __gen_nsIAccessibleEventListener_h__
#define __gen_nsIAccessibleEventListener_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIAccessible_h__
#include "nsIAccessible.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIAccessibleEventListener */
#define NS_IACCESSIBLEEVENTLISTENER_IID_STR "bee49e7d-9d06-49bf-8984-1694c697d74f"

#define NS_IACCESSIBLEEVENTLISTENER_IID \
  {0xbee49e7d, 0x9d06, 0x49bf, \
    { 0x89, 0x84, 0x16, 0x94, 0xc6, 0x97, 0xd7, 0x4f }}

class NS_NO_VTABLE nsIAccessibleEventListener : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IACCESSIBLEEVENTLISTENER_IID)

  enum { EVENT_FOCUS = 32773U };

  enum { EVENT_STATE_CHANGE = 32778U };

  enum { EVENT_NAME_CHANGE = 32780U };

  enum { EVENT_SELECTION = 32774U };

  enum { EVENT_SELECTION_ADD = 32775U };

  enum { EVENT_SELECTION_REMOVE = 32776U };

  enum { EVENT_SELECTION_WITHIN = 32777U };

  /* void handleEvent (in unsigned long aEvent, in nsIAccessible aTarget); */
  NS_IMETHOD HandleEvent(PRUint32 aEvent, nsIAccessible *aTarget) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIACCESSIBLEEVENTLISTENER \
  NS_IMETHOD HandleEvent(PRUint32 aEvent, nsIAccessible *aTarget); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIACCESSIBLEEVENTLISTENER(_to) \
  NS_IMETHOD HandleEvent(PRUint32 aEvent, nsIAccessible *aTarget) { return _to HandleEvent(aEvent, aTarget); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIACCESSIBLEEVENTLISTENER(_to) \
  NS_IMETHOD HandleEvent(PRUint32 aEvent, nsIAccessible *aTarget) { return !_to ? NS_ERROR_NULL_POINTER : _to->HandleEvent(aEvent, aTarget); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAccessibleEventListener : public nsIAccessibleEventListener
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIACCESSIBLEEVENTLISTENER

  nsAccessibleEventListener();
  virtual ~nsAccessibleEventListener();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAccessibleEventListener, nsIAccessibleEventListener)

nsAccessibleEventListener::nsAccessibleEventListener()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAccessibleEventListener::~nsAccessibleEventListener()
{
  /* destructor code */
}

/* void handleEvent (in unsigned long aEvent, in nsIAccessible aTarget); */
NS_IMETHODIMP nsAccessibleEventListener::HandleEvent(PRUint32 aEvent, nsIAccessible *aTarget)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAccessibleEventListener_h__ */
