/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAccessibleSelectable.idl
 */

#ifndef __gen_nsIAccessibleSelectable_h__
#define __gen_nsIAccessibleSelectable_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIAccessible_h__
#include "nsIAccessible.h"
#endif

#ifndef __gen_nsISupportsArray_h__
#include "nsISupportsArray.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIAccessibleSelectable */
#define NS_IACCESSIBLESELECTABLE_IID_STR "34d268d6-1dd2-11b2-9d63-83a5e0ada290"

#define NS_IACCESSIBLESELECTABLE_IID \
  {0x34d268d6, 0x1dd2, 0x11b2, \
    { 0x9d, 0x63, 0x83, 0xa5, 0xe0, 0xad, 0xa2, 0x90 }}

class NS_NO_VTABLE nsIAccessibleSelectable : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IACCESSIBLESELECTABLE_IID)

  /* nsISupportsArray GetSelectedChildren (); */
  NS_IMETHOD GetSelectedChildren(nsISupportsArray **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIACCESSIBLESELECTABLE \
  NS_IMETHOD GetSelectedChildren(nsISupportsArray **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIACCESSIBLESELECTABLE(_to) \
  NS_IMETHOD GetSelectedChildren(nsISupportsArray **_retval) { return _to GetSelectedChildren(_retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIACCESSIBLESELECTABLE(_to) \
  NS_IMETHOD GetSelectedChildren(nsISupportsArray **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSelectedChildren(_retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAccessibleSelectable : public nsIAccessibleSelectable
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIACCESSIBLESELECTABLE

  nsAccessibleSelectable();
  virtual ~nsAccessibleSelectable();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAccessibleSelectable, nsIAccessibleSelectable)

nsAccessibleSelectable::nsAccessibleSelectable()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAccessibleSelectable::~nsAccessibleSelectable()
{
  /* destructor code */
}

/* nsISupportsArray GetSelectedChildren (); */
NS_IMETHODIMP nsAccessibleSelectable::GetSelectedChildren(nsISupportsArray **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAccessibleSelectable_h__ */
