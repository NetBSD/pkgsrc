/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbUpgrader.idl
 */

#ifndef __gen_nsIAbUpgrader_h__
#define __gen_nsIAbUpgrader_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIFileSpec_h__
#include "nsIFileSpec.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIAbUpgrader */
#define NS_IABUPGRADER_IID_STR "abd6c760-f396-11d3-b9fa-00108335942a"

#define NS_IABUPGRADER_IID \
  {0xabd6c760, 0xf396, 0x11d3, \
    { 0xb9, 0xfa, 0x00, 0x10, 0x83, 0x35, 0x94, 0x2a }}

class NS_NO_VTABLE nsIAbUpgrader : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABUPGRADER_IID)

  /* void StartUpgrade4xAddrBook (in nsIFileSpec sourceAddrBook, in nsIFileSpec destAddrBook); */
  NS_IMETHOD StartUpgrade4xAddrBook(nsIFileSpec *sourceAddrBook, nsIFileSpec *destAddrBook) = 0;

  /* void ContinueExport (out boolean done); */
  NS_IMETHOD ContinueExport(PRBool *done) = 0;

  /* attribute string currentCharset; */
  NS_IMETHOD GetCurrentCharset(char * *aCurrentCharset) = 0;
  NS_IMETHOD SetCurrentCharset(const char * aCurrentCharset) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABUPGRADER \
  NS_IMETHOD StartUpgrade4xAddrBook(nsIFileSpec *sourceAddrBook, nsIFileSpec *destAddrBook); \
  NS_IMETHOD ContinueExport(PRBool *done); \
  NS_IMETHOD GetCurrentCharset(char * *aCurrentCharset); \
  NS_IMETHOD SetCurrentCharset(const char * aCurrentCharset); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABUPGRADER(_to) \
  NS_IMETHOD StartUpgrade4xAddrBook(nsIFileSpec *sourceAddrBook, nsIFileSpec *destAddrBook) { return _to StartUpgrade4xAddrBook(sourceAddrBook, destAddrBook); } \
  NS_IMETHOD ContinueExport(PRBool *done) { return _to ContinueExport(done); } \
  NS_IMETHOD GetCurrentCharset(char * *aCurrentCharset) { return _to GetCurrentCharset(aCurrentCharset); } \
  NS_IMETHOD SetCurrentCharset(const char * aCurrentCharset) { return _to SetCurrentCharset(aCurrentCharset); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABUPGRADER(_to) \
  NS_IMETHOD StartUpgrade4xAddrBook(nsIFileSpec *sourceAddrBook, nsIFileSpec *destAddrBook) { return !_to ? NS_ERROR_NULL_POINTER : _to->StartUpgrade4xAddrBook(sourceAddrBook, destAddrBook); } \
  NS_IMETHOD ContinueExport(PRBool *done) { return !_to ? NS_ERROR_NULL_POINTER : _to->ContinueExport(done); } \
  NS_IMETHOD GetCurrentCharset(char * *aCurrentCharset) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCurrentCharset(aCurrentCharset); } \
  NS_IMETHOD SetCurrentCharset(const char * aCurrentCharset) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCurrentCharset(aCurrentCharset); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbUpgrader : public nsIAbUpgrader
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABUPGRADER

  nsAbUpgrader();
  virtual ~nsAbUpgrader();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbUpgrader, nsIAbUpgrader)

nsAbUpgrader::nsAbUpgrader()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAbUpgrader::~nsAbUpgrader()
{
  /* destructor code */
}

/* void StartUpgrade4xAddrBook (in nsIFileSpec sourceAddrBook, in nsIFileSpec destAddrBook); */
NS_IMETHODIMP nsAbUpgrader::StartUpgrade4xAddrBook(nsIFileSpec *sourceAddrBook, nsIFileSpec *destAddrBook)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void ContinueExport (out boolean done); */
NS_IMETHODIMP nsAbUpgrader::ContinueExport(PRBool *done)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute string currentCharset; */
NS_IMETHODIMP nsAbUpgrader::GetCurrentCharset(char * *aCurrentCharset)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbUpgrader::SetCurrentCharset(const char * aCurrentCharset)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbUpgrader_h__ */
