/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbMDBCard.idl
 */

#ifndef __gen_nsIAbMDBCard_h__
#define __gen_nsIAbMDBCard_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIAddrDatabase; /* forward declaration */

#include "nsVoidArray.h"

/* starting interface:    nsIAbMDBCard */
#define NS_IABMDBCARD_IID_STR "5f414a80-1dd2-11b2-aad0-aa4a15d5a1e8"

#define NS_IABMDBCARD_IID \
  {0x5f414a80, 0x1dd2, 0x11b2, \
    { 0xaa, 0xd0, 0xaa, 0x4a, 0x15, 0xd5, 0xa1, 0xe8 }}

class NS_NO_VTABLE nsIAbMDBCard : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABMDBCARD_IID)

  /* readonly attribute unsigned long key; */
  NS_IMETHOD GetKey(PRUint32 *aKey) = 0;

  /* void setRecordKey (in unsigned long key); */
  NS_IMETHOD SetRecordKey(PRUint32 key) = 0;

  /* attribute unsigned long dbTableID; */
  NS_IMETHOD GetDbTableID(PRUint32 *aDbTableID) = 0;
  NS_IMETHOD SetDbTableID(PRUint32 aDbTableID) = 0;

  /* attribute unsigned long dbRowID; */
  NS_IMETHOD GetDbRowID(PRUint32 *aDbRowID) = 0;
  NS_IMETHOD SetDbRowID(PRUint32 aDbRowID) = 0;

  /* void setAbDatabase (in nsIAddrDatabase database); */
  NS_IMETHOD SetAbDatabase(nsIAddrDatabase *database) = 0;

  /* void copyCard (in nsIAbMDBCard srcCardDB); */
  NS_IMETHOD CopyCard(nsIAbMDBCard *srcCardDB) = 0;

  /* readonly attribute string cardURI; */
  NS_IMETHOD GetCardURI(char * *aCardURI) = 0;

  /* [noscript] readonly attribute nsVoidArray anonymousStrAttrubutesList; */
  NS_IMETHOD GetAnonymousStrAttrubutesList(nsVoidArray * *aAnonymousStrAttrubutesList) = 0;

  /* [noscript] readonly attribute nsVoidArray anonymousStrValuesList; */
  NS_IMETHOD GetAnonymousStrValuesList(nsVoidArray * *aAnonymousStrValuesList) = 0;

  /* [noscript] readonly attribute nsVoidArray anonymousIntAttrubutesList; */
  NS_IMETHOD GetAnonymousIntAttrubutesList(nsVoidArray * *aAnonymousIntAttrubutesList) = 0;

  /* [noscript] readonly attribute nsVoidArray anonymousIntValuesList; */
  NS_IMETHOD GetAnonymousIntValuesList(nsVoidArray * *aAnonymousIntValuesList) = 0;

  /* [noscript] readonly attribute nsVoidArray anonymousBoolAttrubutesList; */
  NS_IMETHOD GetAnonymousBoolAttrubutesList(nsVoidArray * *aAnonymousBoolAttrubutesList) = 0;

  /* [noscript] readonly attribute nsVoidArray anonymousBoolValuesList; */
  NS_IMETHOD GetAnonymousBoolValuesList(nsVoidArray * *aAnonymousBoolValuesList) = 0;

  /* void setAnonymousStringAttribute (in string attrname, in string value); */
  NS_IMETHOD SetAnonymousStringAttribute(const char *attrname, const char *value) = 0;

  /* void setAnonymousIntAttribute (in string attrname, in unsigned long value); */
  NS_IMETHOD SetAnonymousIntAttribute(const char *attrname, PRUint32 value) = 0;

  /* void setAnonymousBoolAttribute (in string attrname, in boolean value); */
  NS_IMETHOD SetAnonymousBoolAttribute(const char *attrname, PRBool value) = 0;

  /* void addAnonymousAttributesToDB (); */
  NS_IMETHOD AddAnonymousAttributesToDB(void) = 0;

  /* void editAnonymousAttributesInDB (); */
  NS_IMETHOD EditAnonymousAttributesInDB(void) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABMDBCARD \
  NS_IMETHOD GetKey(PRUint32 *aKey); \
  NS_IMETHOD SetRecordKey(PRUint32 key); \
  NS_IMETHOD GetDbTableID(PRUint32 *aDbTableID); \
  NS_IMETHOD SetDbTableID(PRUint32 aDbTableID); \
  NS_IMETHOD GetDbRowID(PRUint32 *aDbRowID); \
  NS_IMETHOD SetDbRowID(PRUint32 aDbRowID); \
  NS_IMETHOD SetAbDatabase(nsIAddrDatabase *database); \
  NS_IMETHOD CopyCard(nsIAbMDBCard *srcCardDB); \
  NS_IMETHOD GetCardURI(char * *aCardURI); \
  NS_IMETHOD GetAnonymousStrAttrubutesList(nsVoidArray * *aAnonymousStrAttrubutesList); \
  NS_IMETHOD GetAnonymousStrValuesList(nsVoidArray * *aAnonymousStrValuesList); \
  NS_IMETHOD GetAnonymousIntAttrubutesList(nsVoidArray * *aAnonymousIntAttrubutesList); \
  NS_IMETHOD GetAnonymousIntValuesList(nsVoidArray * *aAnonymousIntValuesList); \
  NS_IMETHOD GetAnonymousBoolAttrubutesList(nsVoidArray * *aAnonymousBoolAttrubutesList); \
  NS_IMETHOD GetAnonymousBoolValuesList(nsVoidArray * *aAnonymousBoolValuesList); \
  NS_IMETHOD SetAnonymousStringAttribute(const char *attrname, const char *value); \
  NS_IMETHOD SetAnonymousIntAttribute(const char *attrname, PRUint32 value); \
  NS_IMETHOD SetAnonymousBoolAttribute(const char *attrname, PRBool value); \
  NS_IMETHOD AddAnonymousAttributesToDB(void); \
  NS_IMETHOD EditAnonymousAttributesInDB(void); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABMDBCARD(_to) \
  NS_IMETHOD GetKey(PRUint32 *aKey) { return _to GetKey(aKey); } \
  NS_IMETHOD SetRecordKey(PRUint32 key) { return _to SetRecordKey(key); } \
  NS_IMETHOD GetDbTableID(PRUint32 *aDbTableID) { return _to GetDbTableID(aDbTableID); } \
  NS_IMETHOD SetDbTableID(PRUint32 aDbTableID) { return _to SetDbTableID(aDbTableID); } \
  NS_IMETHOD GetDbRowID(PRUint32 *aDbRowID) { return _to GetDbRowID(aDbRowID); } \
  NS_IMETHOD SetDbRowID(PRUint32 aDbRowID) { return _to SetDbRowID(aDbRowID); } \
  NS_IMETHOD SetAbDatabase(nsIAddrDatabase *database) { return _to SetAbDatabase(database); } \
  NS_IMETHOD CopyCard(nsIAbMDBCard *srcCardDB) { return _to CopyCard(srcCardDB); } \
  NS_IMETHOD GetCardURI(char * *aCardURI) { return _to GetCardURI(aCardURI); } \
  NS_IMETHOD GetAnonymousStrAttrubutesList(nsVoidArray * *aAnonymousStrAttrubutesList) { return _to GetAnonymousStrAttrubutesList(aAnonymousStrAttrubutesList); } \
  NS_IMETHOD GetAnonymousStrValuesList(nsVoidArray * *aAnonymousStrValuesList) { return _to GetAnonymousStrValuesList(aAnonymousStrValuesList); } \
  NS_IMETHOD GetAnonymousIntAttrubutesList(nsVoidArray * *aAnonymousIntAttrubutesList) { return _to GetAnonymousIntAttrubutesList(aAnonymousIntAttrubutesList); } \
  NS_IMETHOD GetAnonymousIntValuesList(nsVoidArray * *aAnonymousIntValuesList) { return _to GetAnonymousIntValuesList(aAnonymousIntValuesList); } \
  NS_IMETHOD GetAnonymousBoolAttrubutesList(nsVoidArray * *aAnonymousBoolAttrubutesList) { return _to GetAnonymousBoolAttrubutesList(aAnonymousBoolAttrubutesList); } \
  NS_IMETHOD GetAnonymousBoolValuesList(nsVoidArray * *aAnonymousBoolValuesList) { return _to GetAnonymousBoolValuesList(aAnonymousBoolValuesList); } \
  NS_IMETHOD SetAnonymousStringAttribute(const char *attrname, const char *value) { return _to SetAnonymousStringAttribute(attrname, value); } \
  NS_IMETHOD SetAnonymousIntAttribute(const char *attrname, PRUint32 value) { return _to SetAnonymousIntAttribute(attrname, value); } \
  NS_IMETHOD SetAnonymousBoolAttribute(const char *attrname, PRBool value) { return _to SetAnonymousBoolAttribute(attrname, value); } \
  NS_IMETHOD AddAnonymousAttributesToDB(void) { return _to AddAnonymousAttributesToDB(); } \
  NS_IMETHOD EditAnonymousAttributesInDB(void) { return _to EditAnonymousAttributesInDB(); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABMDBCARD(_to) \
  NS_IMETHOD GetKey(PRUint32 *aKey) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetKey(aKey); } \
  NS_IMETHOD SetRecordKey(PRUint32 key) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetRecordKey(key); } \
  NS_IMETHOD GetDbTableID(PRUint32 *aDbTableID) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDbTableID(aDbTableID); } \
  NS_IMETHOD SetDbTableID(PRUint32 aDbTableID) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDbTableID(aDbTableID); } \
  NS_IMETHOD GetDbRowID(PRUint32 *aDbRowID) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDbRowID(aDbRowID); } \
  NS_IMETHOD SetDbRowID(PRUint32 aDbRowID) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDbRowID(aDbRowID); } \
  NS_IMETHOD SetAbDatabase(nsIAddrDatabase *database) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetAbDatabase(database); } \
  NS_IMETHOD CopyCard(nsIAbMDBCard *srcCardDB) { return !_to ? NS_ERROR_NULL_POINTER : _to->CopyCard(srcCardDB); } \
  NS_IMETHOD GetCardURI(char * *aCardURI) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCardURI(aCardURI); } \
  NS_IMETHOD GetAnonymousStrAttrubutesList(nsVoidArray * *aAnonymousStrAttrubutesList) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAnonymousStrAttrubutesList(aAnonymousStrAttrubutesList); } \
  NS_IMETHOD GetAnonymousStrValuesList(nsVoidArray * *aAnonymousStrValuesList) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAnonymousStrValuesList(aAnonymousStrValuesList); } \
  NS_IMETHOD GetAnonymousIntAttrubutesList(nsVoidArray * *aAnonymousIntAttrubutesList) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAnonymousIntAttrubutesList(aAnonymousIntAttrubutesList); } \
  NS_IMETHOD GetAnonymousIntValuesList(nsVoidArray * *aAnonymousIntValuesList) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAnonymousIntValuesList(aAnonymousIntValuesList); } \
  NS_IMETHOD GetAnonymousBoolAttrubutesList(nsVoidArray * *aAnonymousBoolAttrubutesList) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAnonymousBoolAttrubutesList(aAnonymousBoolAttrubutesList); } \
  NS_IMETHOD GetAnonymousBoolValuesList(nsVoidArray * *aAnonymousBoolValuesList) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAnonymousBoolValuesList(aAnonymousBoolValuesList); } \
  NS_IMETHOD SetAnonymousStringAttribute(const char *attrname, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetAnonymousStringAttribute(attrname, value); } \
  NS_IMETHOD SetAnonymousIntAttribute(const char *attrname, PRUint32 value) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetAnonymousIntAttribute(attrname, value); } \
  NS_IMETHOD SetAnonymousBoolAttribute(const char *attrname, PRBool value) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetAnonymousBoolAttribute(attrname, value); } \
  NS_IMETHOD AddAnonymousAttributesToDB(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddAnonymousAttributesToDB(); } \
  NS_IMETHOD EditAnonymousAttributesInDB(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->EditAnonymousAttributesInDB(); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbMDBCard : public nsIAbMDBCard
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABMDBCARD

  nsAbMDBCard();
  virtual ~nsAbMDBCard();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbMDBCard, nsIAbMDBCard)

nsAbMDBCard::nsAbMDBCard()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAbMDBCard::~nsAbMDBCard()
{
  /* destructor code */
}

/* readonly attribute unsigned long key; */
NS_IMETHODIMP nsAbMDBCard::GetKey(PRUint32 *aKey)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setRecordKey (in unsigned long key); */
NS_IMETHODIMP nsAbMDBCard::SetRecordKey(PRUint32 key)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute unsigned long dbTableID; */
NS_IMETHODIMP nsAbMDBCard::GetDbTableID(PRUint32 *aDbTableID)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbMDBCard::SetDbTableID(PRUint32 aDbTableID)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute unsigned long dbRowID; */
NS_IMETHODIMP nsAbMDBCard::GetDbRowID(PRUint32 *aDbRowID)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbMDBCard::SetDbRowID(PRUint32 aDbRowID)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setAbDatabase (in nsIAddrDatabase database); */
NS_IMETHODIMP nsAbMDBCard::SetAbDatabase(nsIAddrDatabase *database)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void copyCard (in nsIAbMDBCard srcCardDB); */
NS_IMETHODIMP nsAbMDBCard::CopyCard(nsIAbMDBCard *srcCardDB)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute string cardURI; */
NS_IMETHODIMP nsAbMDBCard::GetCardURI(char * *aCardURI)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] readonly attribute nsVoidArray anonymousStrAttrubutesList; */
NS_IMETHODIMP nsAbMDBCard::GetAnonymousStrAttrubutesList(nsVoidArray * *aAnonymousStrAttrubutesList)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] readonly attribute nsVoidArray anonymousStrValuesList; */
NS_IMETHODIMP nsAbMDBCard::GetAnonymousStrValuesList(nsVoidArray * *aAnonymousStrValuesList)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] readonly attribute nsVoidArray anonymousIntAttrubutesList; */
NS_IMETHODIMP nsAbMDBCard::GetAnonymousIntAttrubutesList(nsVoidArray * *aAnonymousIntAttrubutesList)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] readonly attribute nsVoidArray anonymousIntValuesList; */
NS_IMETHODIMP nsAbMDBCard::GetAnonymousIntValuesList(nsVoidArray * *aAnonymousIntValuesList)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] readonly attribute nsVoidArray anonymousBoolAttrubutesList; */
NS_IMETHODIMP nsAbMDBCard::GetAnonymousBoolAttrubutesList(nsVoidArray * *aAnonymousBoolAttrubutesList)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] readonly attribute nsVoidArray anonymousBoolValuesList; */
NS_IMETHODIMP nsAbMDBCard::GetAnonymousBoolValuesList(nsVoidArray * *aAnonymousBoolValuesList)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setAnonymousStringAttribute (in string attrname, in string value); */
NS_IMETHODIMP nsAbMDBCard::SetAnonymousStringAttribute(const char *attrname, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setAnonymousIntAttribute (in string attrname, in unsigned long value); */
NS_IMETHODIMP nsAbMDBCard::SetAnonymousIntAttribute(const char *attrname, PRUint32 value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setAnonymousBoolAttribute (in string attrname, in boolean value); */
NS_IMETHODIMP nsAbMDBCard::SetAnonymousBoolAttribute(const char *attrname, PRBool value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void addAnonymousAttributesToDB (); */
NS_IMETHODIMP nsAbMDBCard::AddAnonymousAttributesToDB()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void editAnonymousAttributesInDB (); */
NS_IMETHODIMP nsAbMDBCard::EditAnonymousAttributesInDB()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbMDBCard_h__ */
