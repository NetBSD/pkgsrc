/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbDirectory.idl
 */

#ifndef __gen_nsIAbDirectory_h__
#define __gen_nsIAbDirectory_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIAbCard_h__
#include "nsIAbCard.h"
#endif

#ifndef __gen_nsISupportsArray_h__
#include "nsISupportsArray.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
#include "nsFileSpec.h"
#include "nsDirPrefs.h"

/* starting interface:    nsIAbDirectory */
#define NS_IABDIRECTORY_IID_STR "aa920c90-1dd1-11b2-96d3-aa81268adafc"

#define NS_IABDIRECTORY_IID \
  {0xaa920c90, 0x1dd1, 0x11b2, \
    { 0x96, 0xd3, 0xaa, 0x81, 0x26, 0x8a, 0xda, 0xfc }}

class NS_NO_VTABLE nsIAbDirectory : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABDIRECTORY_IID)

  enum { opRead = 1 };

  enum { opWrite = 2 };

  enum { opSearch = 4 };

  /* readonly attribute long operations; */
  NS_IMETHOD GetOperations(PRInt32 *aOperations) = 0;

  /* attribute wstring dirName; */
  NS_IMETHOD GetDirName(PRUnichar * *aDirName) = 0;
  NS_IMETHOD SetDirName(const PRUnichar * aDirName) = 0;

  /* attribute unsigned long lastModifiedDate; */
  NS_IMETHOD GetLastModifiedDate(PRUint32 *aLastModifiedDate) = 0;
  NS_IMETHOD SetLastModifiedDate(PRUint32 aLastModifiedDate) = 0;

  /* attribute PRBool isMailList; */
  NS_IMETHOD GetIsMailList(PRBool *aIsMailList) = 0;
  NS_IMETHOD SetIsMailList(PRBool aIsMailList) = 0;

  /* readonly attribute nsIEnumerator childNodes; */
  NS_IMETHOD GetChildNodes(nsIEnumerator * *aChildNodes) = 0;

  /* readonly attribute nsIEnumerator childCards; */
  NS_IMETHOD GetChildCards(nsIEnumerator * *aChildCards) = 0;

  /* void deleteDirectory (in nsIAbDirectory dierctory); */
  NS_IMETHOD DeleteDirectory(nsIAbDirectory *dierctory) = 0;

  /* void deleteCards (in nsISupportsArray cards); */
  NS_IMETHOD DeleteCards(nsISupportsArray *cards) = 0;

  /* boolean hasCard (in nsIAbCard cards); */
  NS_IMETHOD HasCard(nsIAbCard *cards, PRBool *_retval) = 0;

  /* boolean hasDirectory (in nsIAbDirectory dir); */
  NS_IMETHOD HasDirectory(nsIAbDirectory *dir, PRBool *_retval) = 0;

  /* nsIAbCard addCard (in nsIAbCard card); */
  NS_IMETHOD AddCard(nsIAbCard *card, nsIAbCard **_retval) = 0;

  /* nsIAbCard dropCard (in nsIAbCard card); */
  NS_IMETHOD DropCard(nsIAbCard *card, nsIAbCard **_retval) = 0;

  /* attribute nsISupportsArray addressLists; */
  NS_IMETHOD GetAddressLists(nsISupportsArray * *aAddressLists) = 0;
  NS_IMETHOD SetAddressLists(nsISupportsArray * aAddressLists) = 0;

  /* void addMailList (in nsIAbDirectory list); */
  NS_IMETHOD AddMailList(nsIAbDirectory *list) = 0;

  /* attribute wstring listName; */
  NS_IMETHOD GetListName(PRUnichar * *aListName) = 0;
  NS_IMETHOD SetListName(const PRUnichar * aListName) = 0;

  /* attribute wstring listNickName; */
  NS_IMETHOD GetListNickName(PRUnichar * *aListNickName) = 0;
  NS_IMETHOD SetListNickName(const PRUnichar * aListNickName) = 0;

  /* attribute wstring description; */
  NS_IMETHOD GetDescription(PRUnichar * *aDescription) = 0;
  NS_IMETHOD SetDescription(const PRUnichar * aDescription) = 0;

  /* void addMailListToDatabase (in string uri); */
  NS_IMETHOD AddMailListToDatabase(const char *uri) = 0;

  /* void editMailListToDatabase (in string uri); */
  NS_IMETHOD EditMailListToDatabase(const char *uri) = 0;

  /* void copyMailList (in nsIAbDirectory srcList); */
  NS_IMETHOD CopyMailList(nsIAbDirectory *srcList) = 0;

  /* void createNewDirectory (in unsigned long prefCount, [array, size_is (prefCount)] in string prefName, [array, size_is (prefCount)] in wstring prefValue); */
  NS_IMETHOD CreateNewDirectory(PRUint32 prefCount, const char **prefName, const PRUnichar **prefValue) = 0;

  /* void CreateDirectoryByURI (in wstring displayName, in string uri, in boolean migrating); */
  NS_IMETHOD CreateDirectoryByURI(const PRUnichar *displayName, const char *uri, PRBool migrating) = 0;

  /* unsigned long getTotalCards (in boolean subDirectoryCount); */
  NS_IMETHOD GetTotalCards(PRBool subDirectoryCount, PRUint32 *_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABDIRECTORY \
  NS_IMETHOD GetOperations(PRInt32 *aOperations); \
  NS_IMETHOD GetDirName(PRUnichar * *aDirName); \
  NS_IMETHOD SetDirName(const PRUnichar * aDirName); \
  NS_IMETHOD GetLastModifiedDate(PRUint32 *aLastModifiedDate); \
  NS_IMETHOD SetLastModifiedDate(PRUint32 aLastModifiedDate); \
  NS_IMETHOD GetIsMailList(PRBool *aIsMailList); \
  NS_IMETHOD SetIsMailList(PRBool aIsMailList); \
  NS_IMETHOD GetChildNodes(nsIEnumerator * *aChildNodes); \
  NS_IMETHOD GetChildCards(nsIEnumerator * *aChildCards); \
  NS_IMETHOD DeleteDirectory(nsIAbDirectory *dierctory); \
  NS_IMETHOD DeleteCards(nsISupportsArray *cards); \
  NS_IMETHOD HasCard(nsIAbCard *cards, PRBool *_retval); \
  NS_IMETHOD HasDirectory(nsIAbDirectory *dir, PRBool *_retval); \
  NS_IMETHOD AddCard(nsIAbCard *card, nsIAbCard **_retval); \
  NS_IMETHOD DropCard(nsIAbCard *card, nsIAbCard **_retval); \
  NS_IMETHOD GetAddressLists(nsISupportsArray * *aAddressLists); \
  NS_IMETHOD SetAddressLists(nsISupportsArray * aAddressLists); \
  NS_IMETHOD AddMailList(nsIAbDirectory *list); \
  NS_IMETHOD GetListName(PRUnichar * *aListName); \
  NS_IMETHOD SetListName(const PRUnichar * aListName); \
  NS_IMETHOD GetListNickName(PRUnichar * *aListNickName); \
  NS_IMETHOD SetListNickName(const PRUnichar * aListNickName); \
  NS_IMETHOD GetDescription(PRUnichar * *aDescription); \
  NS_IMETHOD SetDescription(const PRUnichar * aDescription); \
  NS_IMETHOD AddMailListToDatabase(const char *uri); \
  NS_IMETHOD EditMailListToDatabase(const char *uri); \
  NS_IMETHOD CopyMailList(nsIAbDirectory *srcList); \
  NS_IMETHOD CreateNewDirectory(PRUint32 prefCount, const char **prefName, const PRUnichar **prefValue); \
  NS_IMETHOD CreateDirectoryByURI(const PRUnichar *displayName, const char *uri, PRBool migrating); \
  NS_IMETHOD GetTotalCards(PRBool subDirectoryCount, PRUint32 *_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABDIRECTORY(_to) \
  NS_IMETHOD GetOperations(PRInt32 *aOperations) { return _to GetOperations(aOperations); } \
  NS_IMETHOD GetDirName(PRUnichar * *aDirName) { return _to GetDirName(aDirName); } \
  NS_IMETHOD SetDirName(const PRUnichar * aDirName) { return _to SetDirName(aDirName); } \
  NS_IMETHOD GetLastModifiedDate(PRUint32 *aLastModifiedDate) { return _to GetLastModifiedDate(aLastModifiedDate); } \
  NS_IMETHOD SetLastModifiedDate(PRUint32 aLastModifiedDate) { return _to SetLastModifiedDate(aLastModifiedDate); } \
  NS_IMETHOD GetIsMailList(PRBool *aIsMailList) { return _to GetIsMailList(aIsMailList); } \
  NS_IMETHOD SetIsMailList(PRBool aIsMailList) { return _to SetIsMailList(aIsMailList); } \
  NS_IMETHOD GetChildNodes(nsIEnumerator * *aChildNodes) { return _to GetChildNodes(aChildNodes); } \
  NS_IMETHOD GetChildCards(nsIEnumerator * *aChildCards) { return _to GetChildCards(aChildCards); } \
  NS_IMETHOD DeleteDirectory(nsIAbDirectory *dierctory) { return _to DeleteDirectory(dierctory); } \
  NS_IMETHOD DeleteCards(nsISupportsArray *cards) { return _to DeleteCards(cards); } \
  NS_IMETHOD HasCard(nsIAbCard *cards, PRBool *_retval) { return _to HasCard(cards, _retval); } \
  NS_IMETHOD HasDirectory(nsIAbDirectory *dir, PRBool *_retval) { return _to HasDirectory(dir, _retval); } \
  NS_IMETHOD AddCard(nsIAbCard *card, nsIAbCard **_retval) { return _to AddCard(card, _retval); } \
  NS_IMETHOD DropCard(nsIAbCard *card, nsIAbCard **_retval) { return _to DropCard(card, _retval); } \
  NS_IMETHOD GetAddressLists(nsISupportsArray * *aAddressLists) { return _to GetAddressLists(aAddressLists); } \
  NS_IMETHOD SetAddressLists(nsISupportsArray * aAddressLists) { return _to SetAddressLists(aAddressLists); } \
  NS_IMETHOD AddMailList(nsIAbDirectory *list) { return _to AddMailList(list); } \
  NS_IMETHOD GetListName(PRUnichar * *aListName) { return _to GetListName(aListName); } \
  NS_IMETHOD SetListName(const PRUnichar * aListName) { return _to SetListName(aListName); } \
  NS_IMETHOD GetListNickName(PRUnichar * *aListNickName) { return _to GetListNickName(aListNickName); } \
  NS_IMETHOD SetListNickName(const PRUnichar * aListNickName) { return _to SetListNickName(aListNickName); } \
  NS_IMETHOD GetDescription(PRUnichar * *aDescription) { return _to GetDescription(aDescription); } \
  NS_IMETHOD SetDescription(const PRUnichar * aDescription) { return _to SetDescription(aDescription); } \
  NS_IMETHOD AddMailListToDatabase(const char *uri) { return _to AddMailListToDatabase(uri); } \
  NS_IMETHOD EditMailListToDatabase(const char *uri) { return _to EditMailListToDatabase(uri); } \
  NS_IMETHOD CopyMailList(nsIAbDirectory *srcList) { return _to CopyMailList(srcList); } \
  NS_IMETHOD CreateNewDirectory(PRUint32 prefCount, const char **prefName, const PRUnichar **prefValue) { return _to CreateNewDirectory(prefCount, prefName, prefValue); } \
  NS_IMETHOD CreateDirectoryByURI(const PRUnichar *displayName, const char *uri, PRBool migrating) { return _to CreateDirectoryByURI(displayName, uri, migrating); } \
  NS_IMETHOD GetTotalCards(PRBool subDirectoryCount, PRUint32 *_retval) { return _to GetTotalCards(subDirectoryCount, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABDIRECTORY(_to) \
  NS_IMETHOD GetOperations(PRInt32 *aOperations) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetOperations(aOperations); } \
  NS_IMETHOD GetDirName(PRUnichar * *aDirName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDirName(aDirName); } \
  NS_IMETHOD SetDirName(const PRUnichar * aDirName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDirName(aDirName); } \
  NS_IMETHOD GetLastModifiedDate(PRUint32 *aLastModifiedDate) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetLastModifiedDate(aLastModifiedDate); } \
  NS_IMETHOD SetLastModifiedDate(PRUint32 aLastModifiedDate) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetLastModifiedDate(aLastModifiedDate); } \
  NS_IMETHOD GetIsMailList(PRBool *aIsMailList) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsMailList(aIsMailList); } \
  NS_IMETHOD SetIsMailList(PRBool aIsMailList) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetIsMailList(aIsMailList); } \
  NS_IMETHOD GetChildNodes(nsIEnumerator * *aChildNodes) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetChildNodes(aChildNodes); } \
  NS_IMETHOD GetChildCards(nsIEnumerator * *aChildCards) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetChildCards(aChildCards); } \
  NS_IMETHOD DeleteDirectory(nsIAbDirectory *dierctory) { return !_to ? NS_ERROR_NULL_POINTER : _to->DeleteDirectory(dierctory); } \
  NS_IMETHOD DeleteCards(nsISupportsArray *cards) { return !_to ? NS_ERROR_NULL_POINTER : _to->DeleteCards(cards); } \
  NS_IMETHOD HasCard(nsIAbCard *cards, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->HasCard(cards, _retval); } \
  NS_IMETHOD HasDirectory(nsIAbDirectory *dir, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->HasDirectory(dir, _retval); } \
  NS_IMETHOD AddCard(nsIAbCard *card, nsIAbCard **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddCard(card, _retval); } \
  NS_IMETHOD DropCard(nsIAbCard *card, nsIAbCard **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->DropCard(card, _retval); } \
  NS_IMETHOD GetAddressLists(nsISupportsArray * *aAddressLists) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAddressLists(aAddressLists); } \
  NS_IMETHOD SetAddressLists(nsISupportsArray * aAddressLists) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetAddressLists(aAddressLists); } \
  NS_IMETHOD AddMailList(nsIAbDirectory *list) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddMailList(list); } \
  NS_IMETHOD GetListName(PRUnichar * *aListName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetListName(aListName); } \
  NS_IMETHOD SetListName(const PRUnichar * aListName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetListName(aListName); } \
  NS_IMETHOD GetListNickName(PRUnichar * *aListNickName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetListNickName(aListNickName); } \
  NS_IMETHOD SetListNickName(const PRUnichar * aListNickName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetListNickName(aListNickName); } \
  NS_IMETHOD GetDescription(PRUnichar * *aDescription) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDescription(aDescription); } \
  NS_IMETHOD SetDescription(const PRUnichar * aDescription) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDescription(aDescription); } \
  NS_IMETHOD AddMailListToDatabase(const char *uri) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddMailListToDatabase(uri); } \
  NS_IMETHOD EditMailListToDatabase(const char *uri) { return !_to ? NS_ERROR_NULL_POINTER : _to->EditMailListToDatabase(uri); } \
  NS_IMETHOD CopyMailList(nsIAbDirectory *srcList) { return !_to ? NS_ERROR_NULL_POINTER : _to->CopyMailList(srcList); } \
  NS_IMETHOD CreateNewDirectory(PRUint32 prefCount, const char **prefName, const PRUnichar **prefValue) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateNewDirectory(prefCount, prefName, prefValue); } \
  NS_IMETHOD CreateDirectoryByURI(const PRUnichar *displayName, const char *uri, PRBool migrating) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateDirectoryByURI(displayName, uri, migrating); } \
  NS_IMETHOD GetTotalCards(PRBool subDirectoryCount, PRUint32 *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetTotalCards(subDirectoryCount, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbDirectory : public nsIAbDirectory
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABDIRECTORY

  nsAbDirectory();
  virtual ~nsAbDirectory();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbDirectory, nsIAbDirectory)

nsAbDirectory::nsAbDirectory()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAbDirectory::~nsAbDirectory()
{
  /* destructor code */
}

/* readonly attribute long operations; */
NS_IMETHODIMP nsAbDirectory::GetOperations(PRInt32 *aOperations)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring dirName; */
NS_IMETHODIMP nsAbDirectory::GetDirName(PRUnichar * *aDirName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectory::SetDirName(const PRUnichar * aDirName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute unsigned long lastModifiedDate; */
NS_IMETHODIMP nsAbDirectory::GetLastModifiedDate(PRUint32 *aLastModifiedDate)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectory::SetLastModifiedDate(PRUint32 aLastModifiedDate)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute PRBool isMailList; */
NS_IMETHODIMP nsAbDirectory::GetIsMailList(PRBool *aIsMailList)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectory::SetIsMailList(PRBool aIsMailList)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute nsIEnumerator childNodes; */
NS_IMETHODIMP nsAbDirectory::GetChildNodes(nsIEnumerator * *aChildNodes)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute nsIEnumerator childCards; */
NS_IMETHODIMP nsAbDirectory::GetChildCards(nsIEnumerator * *aChildCards)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void deleteDirectory (in nsIAbDirectory dierctory); */
NS_IMETHODIMP nsAbDirectory::DeleteDirectory(nsIAbDirectory *dierctory)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void deleteCards (in nsISupportsArray cards); */
NS_IMETHODIMP nsAbDirectory::DeleteCards(nsISupportsArray *cards)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean hasCard (in nsIAbCard cards); */
NS_IMETHODIMP nsAbDirectory::HasCard(nsIAbCard *cards, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean hasDirectory (in nsIAbDirectory dir); */
NS_IMETHODIMP nsAbDirectory::HasDirectory(nsIAbDirectory *dir, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAbCard addCard (in nsIAbCard card); */
NS_IMETHODIMP nsAbDirectory::AddCard(nsIAbCard *card, nsIAbCard **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAbCard dropCard (in nsIAbCard card); */
NS_IMETHODIMP nsAbDirectory::DropCard(nsIAbCard *card, nsIAbCard **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute nsISupportsArray addressLists; */
NS_IMETHODIMP nsAbDirectory::GetAddressLists(nsISupportsArray * *aAddressLists)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectory::SetAddressLists(nsISupportsArray * aAddressLists)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void addMailList (in nsIAbDirectory list); */
NS_IMETHODIMP nsAbDirectory::AddMailList(nsIAbDirectory *list)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring listName; */
NS_IMETHODIMP nsAbDirectory::GetListName(PRUnichar * *aListName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectory::SetListName(const PRUnichar * aListName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring listNickName; */
NS_IMETHODIMP nsAbDirectory::GetListNickName(PRUnichar * *aListNickName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectory::SetListNickName(const PRUnichar * aListNickName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring description; */
NS_IMETHODIMP nsAbDirectory::GetDescription(PRUnichar * *aDescription)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectory::SetDescription(const PRUnichar * aDescription)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void addMailListToDatabase (in string uri); */
NS_IMETHODIMP nsAbDirectory::AddMailListToDatabase(const char *uri)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void editMailListToDatabase (in string uri); */
NS_IMETHODIMP nsAbDirectory::EditMailListToDatabase(const char *uri)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void copyMailList (in nsIAbDirectory srcList); */
NS_IMETHODIMP nsAbDirectory::CopyMailList(nsIAbDirectory *srcList)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void createNewDirectory (in unsigned long prefCount, [array, size_is (prefCount)] in string prefName, [array, size_is (prefCount)] in wstring prefValue); */
NS_IMETHODIMP nsAbDirectory::CreateNewDirectory(PRUint32 prefCount, const char **prefName, const PRUnichar **prefValue)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void CreateDirectoryByURI (in wstring displayName, in string uri, in boolean migrating); */
NS_IMETHODIMP nsAbDirectory::CreateDirectoryByURI(const PRUnichar *displayName, const char *uri, PRBool migrating)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* unsigned long getTotalCards (in boolean subDirectoryCount); */
NS_IMETHODIMP nsAbDirectory::GetTotalCards(PRBool subDirectoryCount, PRUint32 *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbDirectory_h__ */
