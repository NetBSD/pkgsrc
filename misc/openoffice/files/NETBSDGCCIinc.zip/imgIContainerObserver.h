/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM imgIContainerObserver.idl
 */

#ifndef __gen_imgIContainerObserver_h__
#define __gen_imgIContainerObserver_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_gfxtypes_h__
#include "gfxtypes.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
#include "nsRect.h"
class imgIContainer; /* forward declaration */

class gfxIImageFrame; /* forward declaration */


/* starting interface:    imgIContainerObserver */
#define IMGICONTAINEROBSERVER_IID_STR "153f1518-1dd2-11b2-b9cd-b16eb63e0471"

#define IMGICONTAINEROBSERVER_IID \
  {0x153f1518, 0x1dd2, 0x11b2, \
    { 0xb9, 0xcd, 0xb1, 0x6e, 0xb6, 0x3e, 0x04, 0x71 }}

/**
 * imgIContainerObserver interface
 *
 * @author Stuart Parmenter <pavlov@netscape.com>
 * @version 0.1
 */
class NS_NO_VTABLE imgIContainerObserver : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(IMGICONTAINEROBSERVER_IID)

  /* [noscript] void frameChanged (in imgIContainer aContainer, in nsISupports aCX, in gfxIImageFrame aFrame, in nsRect aDirtyRect); */
  NS_IMETHOD FrameChanged(imgIContainer *aContainer, nsISupports *aCX, gfxIImageFrame *aFrame, nsRect * aDirtyRect) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_IMGICONTAINEROBSERVER \
  NS_IMETHOD FrameChanged(imgIContainer *aContainer, nsISupports *aCX, gfxIImageFrame *aFrame, nsRect * aDirtyRect); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_IMGICONTAINEROBSERVER(_to) \
  NS_IMETHOD FrameChanged(imgIContainer *aContainer, nsISupports *aCX, gfxIImageFrame *aFrame, nsRect * aDirtyRect) { return _to FrameChanged(aContainer, aCX, aFrame, aDirtyRect); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_IMGICONTAINEROBSERVER(_to) \
  NS_IMETHOD FrameChanged(imgIContainer *aContainer, nsISupports *aCX, gfxIImageFrame *aFrame, nsRect * aDirtyRect) { return !_to ? NS_ERROR_NULL_POINTER : _to->FrameChanged(aContainer, aCX, aFrame, aDirtyRect); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class _MYCLASS_ : public imgIContainerObserver
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_IMGICONTAINEROBSERVER

  _MYCLASS_();
  virtual ~_MYCLASS_();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(_MYCLASS_, imgIContainerObserver)

_MYCLASS_::_MYCLASS_()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

_MYCLASS_::~_MYCLASS_()
{
  /* destructor code */
}

/* [noscript] void frameChanged (in imgIContainer aContainer, in nsISupports aCX, in gfxIImageFrame aFrame, in nsRect aDirtyRect); */
NS_IMETHODIMP _MYCLASS_::FrameChanged(imgIContainer *aContainer, nsISupports *aCX, gfxIImageFrame *aFrame, nsRect * aDirtyRect)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_imgIContainerObserver_h__ */
