/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM gfxtypes.idl
 */

#ifndef __gen_gfxtypes_h__
#define __gen_gfxtypes_h__


#ifndef __gen_nsrootidl_h__
#include "nsrootidl.h"
#endif

#ifndef __gen_gfx2types_h__
#include "gfx2types.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
typedef PRInt32 nscoord;


#endif /* __gen_gfxtypes_h__ */
