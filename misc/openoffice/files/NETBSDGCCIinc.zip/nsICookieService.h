/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsICookieService.idl
 */

#ifndef __gen_nsICookieService_h__
#define __gen_nsICookieService_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIURI_h__
#include "nsIURI.h"
#endif

#ifndef __gen_nsIPrompt_h__
#include "nsIPrompt.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsICookieService */
#define NS_ICOOKIESERVICE_IID_STR "ab397774-12d3-11d3-8ad1-00105a1b8860"

#define NS_ICOOKIESERVICE_IID \
  {0xab397774, 0x12d3, 0x11d3, \
    { 0x8a, 0xd1, 0x00, 0x10, 0x5a, 0x1b, 0x88, 0x60 }}

class NS_NO_VTABLE nsICookieService : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ICOOKIESERVICE_IID)

  /* string getCookieString (in nsIURI aURL); */
  NS_IMETHOD GetCookieString(nsIURI *aURL, char **_retval) = 0;

  /* string getCookieStringFromHttp (in nsIURI aURL, in nsIURI aFirstURL); */
  NS_IMETHOD GetCookieStringFromHttp(nsIURI *aURL, nsIURI *aFirstURL, char **_retval) = 0;

  /* void setCookieString (in nsIURI aURL, in nsIPrompt aPrompt, in string aCookie); */
  NS_IMETHOD SetCookieString(nsIURI *aURL, nsIPrompt *aPrompt, const char *aCookie) = 0;

  /* void setCookieStringFromHttp (in nsIURI aURL, in nsIURI aFirstURL, in nsIPrompt aPrompter, in string aCookie, in string aExpires); */
  NS_IMETHOD SetCookieStringFromHttp(nsIURI *aURL, nsIURI *aFirstURL, nsIPrompt *aPrompter, const char *aCookie, const char *aExpires) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSICOOKIESERVICE \
  NS_IMETHOD GetCookieString(nsIURI *aURL, char **_retval); \
  NS_IMETHOD GetCookieStringFromHttp(nsIURI *aURL, nsIURI *aFirstURL, char **_retval); \
  NS_IMETHOD SetCookieString(nsIURI *aURL, nsIPrompt *aPrompt, const char *aCookie); \
  NS_IMETHOD SetCookieStringFromHttp(nsIURI *aURL, nsIURI *aFirstURL, nsIPrompt *aPrompter, const char *aCookie, const char *aExpires); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSICOOKIESERVICE(_to) \
  NS_IMETHOD GetCookieString(nsIURI *aURL, char **_retval) { return _to GetCookieString(aURL, _retval); } \
  NS_IMETHOD GetCookieStringFromHttp(nsIURI *aURL, nsIURI *aFirstURL, char **_retval) { return _to GetCookieStringFromHttp(aURL, aFirstURL, _retval); } \
  NS_IMETHOD SetCookieString(nsIURI *aURL, nsIPrompt *aPrompt, const char *aCookie) { return _to SetCookieString(aURL, aPrompt, aCookie); } \
  NS_IMETHOD SetCookieStringFromHttp(nsIURI *aURL, nsIURI *aFirstURL, nsIPrompt *aPrompter, const char *aCookie, const char *aExpires) { return _to SetCookieStringFromHttp(aURL, aFirstURL, aPrompter, aCookie, aExpires); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSICOOKIESERVICE(_to) \
  NS_IMETHOD GetCookieString(nsIURI *aURL, char **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCookieString(aURL, _retval); } \
  NS_IMETHOD GetCookieStringFromHttp(nsIURI *aURL, nsIURI *aFirstURL, char **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCookieStringFromHttp(aURL, aFirstURL, _retval); } \
  NS_IMETHOD SetCookieString(nsIURI *aURL, nsIPrompt *aPrompt, const char *aCookie) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCookieString(aURL, aPrompt, aCookie); } \
  NS_IMETHOD SetCookieStringFromHttp(nsIURI *aURL, nsIURI *aFirstURL, nsIPrompt *aPrompter, const char *aCookie, const char *aExpires) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCookieStringFromHttp(aURL, aFirstURL, aPrompter, aCookie, aExpires); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsCookieService : public nsICookieService
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSICOOKIESERVICE

  nsCookieService();
  virtual ~nsCookieService();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsCookieService, nsICookieService)

nsCookieService::nsCookieService()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsCookieService::~nsCookieService()
{
  /* destructor code */
}

/* string getCookieString (in nsIURI aURL); */
NS_IMETHODIMP nsCookieService::GetCookieString(nsIURI *aURL, char **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* string getCookieStringFromHttp (in nsIURI aURL, in nsIURI aFirstURL); */
NS_IMETHODIMP nsCookieService::GetCookieStringFromHttp(nsIURI *aURL, nsIURI *aFirstURL, char **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setCookieString (in nsIURI aURL, in nsIPrompt aPrompt, in string aCookie); */
NS_IMETHODIMP nsCookieService::SetCookieString(nsIURI *aURL, nsIPrompt *aPrompt, const char *aCookie)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setCookieStringFromHttp (in nsIURI aURL, in nsIURI aFirstURL, in nsIPrompt aPrompter, in string aCookie, in string aExpires); */
NS_IMETHODIMP nsCookieService::SetCookieStringFromHttp(nsIURI *aURL, nsIURI *aFirstURL, nsIPrompt *aPrompter, const char *aCookie, const char *aExpires)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif

// {AB397774-12D3-11d3-8AD1-00105A1B8860}
#define NS_COOKIESERVICE_CID \
{ 0xab397774, 0x12d3, 0x11d3, { 0x8a, 0xd1, 0x0, 0x10, 0x5a, 0x1b, 0x88, 0x60 } }
#define NS_COOKIESERVICE_CONTRACTID "@mozilla.org/cookieService;1"

#endif /* __gen_nsICookieService_h__ */
