/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsICategoryHandler.idl
 */

#ifndef __gen_nsICategoryHandler_h__
#define __gen_nsICategoryHandler_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsICategoryHandler */
#define NS_ICATEGORYHANDLER_IID_STR "9c1af822-1dd1-11b2-b8ce-a1d231c7953f"

#define NS_ICATEGORYHANDLER_IID \
  {0x9c1af822, 0x1dd1, 0x11b2, \
    { 0xb8, 0xce, 0xa1, 0xd2, 0x31, 0xc7, 0x95, 0x3f }}

class NS_NO_VTABLE nsICategoryHandler : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ICATEGORYHANDLER_IID)

  /**
     * Get the entry for the given category's tag.
     * @param category The name of the category ("protocol")
     * @param entry The entry you're looking for ("http")
     */
  /* string getCategoryEntry (in string category, in string entry); */
  NS_IMETHOD GetCategoryEntry(const char *category, const char *entry, char **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSICATEGORYHANDLER \
  NS_IMETHOD GetCategoryEntry(const char *category, const char *entry, char **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSICATEGORYHANDLER(_to) \
  NS_IMETHOD GetCategoryEntry(const char *category, const char *entry, char **_retval) { return _to GetCategoryEntry(category, entry, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSICATEGORYHANDLER(_to) \
  NS_IMETHOD GetCategoryEntry(const char *category, const char *entry, char **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCategoryEntry(category, entry, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsCategoryHandler : public nsICategoryHandler
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSICATEGORYHANDLER

  nsCategoryHandler();
  virtual ~nsCategoryHandler();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsCategoryHandler, nsICategoryHandler)

nsCategoryHandler::nsCategoryHandler()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsCategoryHandler::~nsCategoryHandler()
{
  /* destructor code */
}

/* string getCategoryEntry (in string category, in string entry); */
NS_IMETHODIMP nsCategoryHandler::GetCategoryEntry(const char *category, const char *entry, char **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsICategoryHandler_h__ */
