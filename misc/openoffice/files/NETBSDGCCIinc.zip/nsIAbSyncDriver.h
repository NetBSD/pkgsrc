/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbSyncDriver.idl
 */

#ifndef __gen_nsIAbSyncDriver_h__
#define __gen_nsIAbSyncDriver_h__


#ifndef __gen_nsrootidl_h__
#include "nsrootidl.h"
#endif

#ifndef __gen_nsIAbSyncListener_h__
#include "nsIAbSyncListener.h"
#endif

#ifndef __gen_nsIMsgStatusFeedback_h__
#include "nsIMsgStatusFeedback.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIAbSyncDriver */
#define NS_IABSYNCDRIVER_IID_STR "91fdfee1-efbc-11d3-8f97-000073757374"

#define NS_IABSYNCDRIVER_IID \
  {0x91fdfee1, 0xefbc, 0x11d3, \
    { 0x8f, 0x97, 0x00, 0x00, 0x73, 0x75, 0x73, 0x74 }}

class NS_NO_VTABLE nsIAbSyncDriver : public nsIAbSyncListener {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABSYNCDRIVER_IID)

  /* void KickIt (in nsIMsgStatusFeedback aStatus, in nsIDOMWindowInternal aDOMWindow); */
  NS_IMETHOD KickIt(nsIMsgStatusFeedback *aStatus, nsIDOMWindowInternal *aDOMWindow) = 0;

  /* void CancelIt (); */
  NS_IMETHOD CancelIt(void) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABSYNCDRIVER \
  NS_IMETHOD KickIt(nsIMsgStatusFeedback *aStatus, nsIDOMWindowInternal *aDOMWindow); \
  NS_IMETHOD CancelIt(void); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABSYNCDRIVER(_to) \
  NS_IMETHOD KickIt(nsIMsgStatusFeedback *aStatus, nsIDOMWindowInternal *aDOMWindow) { return _to KickIt(aStatus, aDOMWindow); } \
  NS_IMETHOD CancelIt(void) { return _to CancelIt(); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABSYNCDRIVER(_to) \
  NS_IMETHOD KickIt(nsIMsgStatusFeedback *aStatus, nsIDOMWindowInternal *aDOMWindow) { return !_to ? NS_ERROR_NULL_POINTER : _to->KickIt(aStatus, aDOMWindow); } \
  NS_IMETHOD CancelIt(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->CancelIt(); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbSyncDriver : public nsIAbSyncDriver
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABSYNCDRIVER

  nsAbSyncDriver();
  virtual ~nsAbSyncDriver();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbSyncDriver, nsIAbSyncDriver)

nsAbSyncDriver::nsAbSyncDriver()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsAbSyncDriver::~nsAbSyncDriver()
{
  /* destructor code */
}

/* void KickIt (in nsIMsgStatusFeedback aStatus, in nsIDOMWindowInternal aDOMWindow); */
NS_IMETHODIMP nsAbSyncDriver::KickIt(nsIMsgStatusFeedback *aStatus, nsIDOMWindowInternal *aDOMWindow)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void CancelIt (); */
NS_IMETHODIMP nsAbSyncDriver::CancelIt()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbSyncDriver_h__ */
