/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsICertOutliner.idl
 */

#ifndef __gen_nsICertOutliner_h__
#define __gen_nsICertOutliner_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIOutlinerView_h__
#include "nsIOutlinerView.h"
#endif

#ifndef __gen_nsIX509Cert_h__
#include "nsIX509Cert.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsICertOutliner */
#define NS_ICERTOUTLINER_IID_STR "4ea60761-31d6-491d-9e34-4b53a26c416c"

#define NS_ICERTOUTLINER_IID \
  {0x4ea60761, 0x31d6, 0x491d, \
    { 0x9e, 0x34, 0x4b, 0x53, 0xa2, 0x6c, 0x41, 0x6c }}

class NS_NO_VTABLE nsICertOutliner : public nsIOutlinerView {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ICERTOUTLINER_IID)

  /* void loadCerts (in unsigned long type); */
  NS_IMETHOD LoadCerts(PRUint32 type) = 0;

  /* nsIX509Cert getCert (in unsigned long index); */
  NS_IMETHOD GetCert(PRUint32 index, nsIX509Cert **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSICERTOUTLINER \
  NS_IMETHOD LoadCerts(PRUint32 type); \
  NS_IMETHOD GetCert(PRUint32 index, nsIX509Cert **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSICERTOUTLINER(_to) \
  NS_IMETHOD LoadCerts(PRUint32 type) { return _to LoadCerts(type); } \
  NS_IMETHOD GetCert(PRUint32 index, nsIX509Cert **_retval) { return _to GetCert(index, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSICERTOUTLINER(_to) \
  NS_IMETHOD LoadCerts(PRUint32 type) { return !_to ? NS_ERROR_NULL_POINTER : _to->LoadCerts(type); } \
  NS_IMETHOD GetCert(PRUint32 index, nsIX509Cert **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCert(index, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsCertOutliner : public nsICertOutliner
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSICERTOUTLINER

  nsCertOutliner();
  virtual ~nsCertOutliner();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsCertOutliner, nsICertOutliner)

nsCertOutliner::nsCertOutliner()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsCertOutliner::~nsCertOutliner()
{
  /* destructor code */
}

/* void loadCerts (in unsigned long type); */
NS_IMETHODIMP nsCertOutliner::LoadCerts(PRUint32 type)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIX509Cert getCert (in unsigned long index); */
NS_IMETHODIMP nsCertOutliner::GetCert(PRUint32 index, nsIX509Cert **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif

#define NS_CERTOUTLINER_CID { 0x4ea60761, 0x31d6, 0x491d, \
                         { 0x9e, 0x34, 0x4b, 0x53, 0xa2, 0x6c, 0x41, 0x6c } }
#define NS_CERTOUTLINER_CONTRACTID "@mozilla.org/security/nsCertOutliner;1"

#endif /* __gen_nsICertOutliner_h__ */
