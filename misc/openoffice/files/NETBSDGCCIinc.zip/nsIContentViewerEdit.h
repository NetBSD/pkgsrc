/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIContentViewerEdit.idl
 */

#ifndef __gen_nsIContentViewerEdit_h__
#define __gen_nsIContentViewerEdit_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIContentViewerEdit */
#define NS_ICONTENTVIEWEREDIT_IID_STR "42d5215c-9bc7-11d3-bccc-0060b0fc76bd"

#define NS_ICONTENTVIEWEREDIT_IID \
  {0x42d5215c, 0x9bc7, 0x11d3, \
    { 0xbc, 0xcc, 0x00, 0x60, 0xb0, 0xfc, 0x76, 0xbd }}

class NS_NO_VTABLE nsIContentViewerEdit : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ICONTENTVIEWEREDIT_IID)

  /* void search (); */
  NS_IMETHOD Search(void) = 0;

  /* readonly attribute boolean searchable; */
  NS_IMETHOD GetSearchable(PRBool *aSearchable) = 0;

  /* void clearSelection (); */
  NS_IMETHOD ClearSelection(void) = 0;

  /* void selectAll (); */
  NS_IMETHOD SelectAll(void) = 0;

  /* void copySelection (); */
  NS_IMETHOD CopySelection(void) = 0;

  /* readonly attribute boolean copyable; */
  NS_IMETHOD GetCopyable(PRBool *aCopyable) = 0;

  /* void copyLinkLocation (); */
  NS_IMETHOD CopyLinkLocation(void) = 0;

  /* readonly attribute boolean inLink; */
  NS_IMETHOD GetInLink(PRBool *aInLink) = 0;

  /* void copyImageLocation (); */
  NS_IMETHOD CopyImageLocation(void) = 0;

  /* void copyImageContents (); */
  NS_IMETHOD CopyImageContents(void) = 0;

  /* readonly attribute boolean inImage; */
  NS_IMETHOD GetInImage(PRBool *aInImage) = 0;

  /* void cutSelection (); */
  NS_IMETHOD CutSelection(void) = 0;

  /* readonly attribute boolean cutable; */
  NS_IMETHOD GetCutable(PRBool *aCutable) = 0;

  /* void paste (); */
  NS_IMETHOD Paste(void) = 0;

  /* readonly attribute boolean pasteable; */
  NS_IMETHOD GetPasteable(PRBool *aPasteable) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSICONTENTVIEWEREDIT \
  NS_IMETHOD Search(void); \
  NS_IMETHOD GetSearchable(PRBool *aSearchable); \
  NS_IMETHOD ClearSelection(void); \
  NS_IMETHOD SelectAll(void); \
  NS_IMETHOD CopySelection(void); \
  NS_IMETHOD GetCopyable(PRBool *aCopyable); \
  NS_IMETHOD CopyLinkLocation(void); \
  NS_IMETHOD GetInLink(PRBool *aInLink); \
  NS_IMETHOD CopyImageLocation(void); \
  NS_IMETHOD CopyImageContents(void); \
  NS_IMETHOD GetInImage(PRBool *aInImage); \
  NS_IMETHOD CutSelection(void); \
  NS_IMETHOD GetCutable(PRBool *aCutable); \
  NS_IMETHOD Paste(void); \
  NS_IMETHOD GetPasteable(PRBool *aPasteable); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSICONTENTVIEWEREDIT(_to) \
  NS_IMETHOD Search(void) { return _to Search(); } \
  NS_IMETHOD GetSearchable(PRBool *aSearchable) { return _to GetSearchable(aSearchable); } \
  NS_IMETHOD ClearSelection(void) { return _to ClearSelection(); } \
  NS_IMETHOD SelectAll(void) { return _to SelectAll(); } \
  NS_IMETHOD CopySelection(void) { return _to CopySelection(); } \
  NS_IMETHOD GetCopyable(PRBool *aCopyable) { return _to GetCopyable(aCopyable); } \
  NS_IMETHOD CopyLinkLocation(void) { return _to CopyLinkLocation(); } \
  NS_IMETHOD GetInLink(PRBool *aInLink) { return _to GetInLink(aInLink); } \
  NS_IMETHOD CopyImageLocation(void) { return _to CopyImageLocation(); } \
  NS_IMETHOD CopyImageContents(void) { return _to CopyImageContents(); } \
  NS_IMETHOD GetInImage(PRBool *aInImage) { return _to GetInImage(aInImage); } \
  NS_IMETHOD CutSelection(void) { return _to CutSelection(); } \
  NS_IMETHOD GetCutable(PRBool *aCutable) { return _to GetCutable(aCutable); } \
  NS_IMETHOD Paste(void) { return _to Paste(); } \
  NS_IMETHOD GetPasteable(PRBool *aPasteable) { return _to GetPasteable(aPasteable); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSICONTENTVIEWEREDIT(_to) \
  NS_IMETHOD Search(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->Search(); } \
  NS_IMETHOD GetSearchable(PRBool *aSearchable) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSearchable(aSearchable); } \
  NS_IMETHOD ClearSelection(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->ClearSelection(); } \
  NS_IMETHOD SelectAll(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->SelectAll(); } \
  NS_IMETHOD CopySelection(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->CopySelection(); } \
  NS_IMETHOD GetCopyable(PRBool *aCopyable) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCopyable(aCopyable); } \
  NS_IMETHOD CopyLinkLocation(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->CopyLinkLocation(); } \
  NS_IMETHOD GetInLink(PRBool *aInLink) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetInLink(aInLink); } \
  NS_IMETHOD CopyImageLocation(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->CopyImageLocation(); } \
  NS_IMETHOD CopyImageContents(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->CopyImageContents(); } \
  NS_IMETHOD GetInImage(PRBool *aInImage) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetInImage(aInImage); } \
  NS_IMETHOD CutSelection(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->CutSelection(); } \
  NS_IMETHOD GetCutable(PRBool *aCutable) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCutable(aCutable); } \
  NS_IMETHOD Paste(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->Paste(); } \
  NS_IMETHOD GetPasteable(PRBool *aPasteable) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPasteable(aPasteable); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsContentViewerEdit : public nsIContentViewerEdit
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSICONTENTVIEWEREDIT

  nsContentViewerEdit();
  virtual ~nsContentViewerEdit();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsContentViewerEdit, nsIContentViewerEdit)

nsContentViewerEdit::nsContentViewerEdit()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsContentViewerEdit::~nsContentViewerEdit()
{
  /* destructor code */
}

/* void search (); */
NS_IMETHODIMP nsContentViewerEdit::Search()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute boolean searchable; */
NS_IMETHODIMP nsContentViewerEdit::GetSearchable(PRBool *aSearchable)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void clearSelection (); */
NS_IMETHODIMP nsContentViewerEdit::ClearSelection()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void selectAll (); */
NS_IMETHODIMP nsContentViewerEdit::SelectAll()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void copySelection (); */
NS_IMETHODIMP nsContentViewerEdit::CopySelection()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute boolean copyable; */
NS_IMETHODIMP nsContentViewerEdit::GetCopyable(PRBool *aCopyable)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void copyLinkLocation (); */
NS_IMETHODIMP nsContentViewerEdit::CopyLinkLocation()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute boolean inLink; */
NS_IMETHODIMP nsContentViewerEdit::GetInLink(PRBool *aInLink)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void copyImageLocation (); */
NS_IMETHODIMP nsContentViewerEdit::CopyImageLocation()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void copyImageContents (); */
NS_IMETHODIMP nsContentViewerEdit::CopyImageContents()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute boolean inImage; */
NS_IMETHODIMP nsContentViewerEdit::GetInImage(PRBool *aInImage)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void cutSelection (); */
NS_IMETHODIMP nsContentViewerEdit::CutSelection()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute boolean cutable; */
NS_IMETHODIMP nsContentViewerEdit::GetCutable(PRBool *aCutable)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void paste (); */
NS_IMETHODIMP nsContentViewerEdit::Paste()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute boolean pasteable; */
NS_IMETHODIMP nsContentViewerEdit::GetPasteable(PRBool *aPasteable)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIContentViewerEdit_h__ */
