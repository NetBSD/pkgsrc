/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIDNSService.idl
 */

#ifndef __gen_nsIDNSService_h__
#define __gen_nsIDNSService_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
#define NS_DNSSERVICE_CID                              \
{ /* 718e7c81-f8b8-11d2-b951-c80918051d3c */           \
    0x718e7c81,                                        \
    0xf8b8,                                            \
    0x11d2,                                            \
    { 0xb9, 0x51, 0xc8, 0x09, 0x18, 0x05, 0x1d, 0x3c } \
}
class nsIRequest; /* forward declaration */

class nsIDNSListener; /* forward declaration */


/* starting interface:    nsIDNSService */
#define NS_IDNSSERVICE_IID_STR "598f2f80-206f-11d3-9348-00104ba0fd40"

#define NS_IDNSSERVICE_IID \
  {0x598f2f80, 0x206f, 0x11d3, \
    { 0x93, 0x48, 0x00, 0x10, 0x4b, 0xa0, 0xfd, 0x40 }}

class NS_NO_VTABLE nsIDNSService : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IDNSSERVICE_IID)

  /* nsIRequest lookup (in string hostname, in nsIDNSListener listener, in nsISupports ctxt); */
  NS_IMETHOD Lookup(const char *hostname, nsIDNSListener *listener, nsISupports *ctxt, nsIRequest **_retval) = 0;

  /**
    * Synchronously resolve the hostname to its IP address. 
    */
  /* string resolve (in string hostname); */
  NS_IMETHOD Resolve(const char *hostname, char **_retval) = 0;

  /**
    * returns our own IP address
    */
  /* readonly attribute string myIPAddress; */
  NS_IMETHOD GetMyIPAddress(char * *aMyIPAddress) = 0;

  /**
    * Check if the specified address is in the network of the pattern
    * using the specified mask. This function would probably go away 
    * once an implementation for it in JS exists for nsProxyAutoConfig.
    * See http://www.mozilla.org/docs/netlib/pac.html for more info.
    */
  /* boolean isInNet (in string ipaddr, in string pattern, in string mask); */
  NS_IMETHOD IsInNet(const char *ipaddr, const char *pattern, const char *mask, PRBool *_retval) = 0;

  /* void init (); */
  NS_IMETHOD Init(void) = 0;

  /* void shutdown (); */
  NS_IMETHOD Shutdown(void) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIDNSSERVICE \
  NS_IMETHOD Lookup(const char *hostname, nsIDNSListener *listener, nsISupports *ctxt, nsIRequest **_retval); \
  NS_IMETHOD Resolve(const char *hostname, char **_retval); \
  NS_IMETHOD GetMyIPAddress(char * *aMyIPAddress); \
  NS_IMETHOD IsInNet(const char *ipaddr, const char *pattern, const char *mask, PRBool *_retval); \
  NS_IMETHOD Init(void); \
  NS_IMETHOD Shutdown(void); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIDNSSERVICE(_to) \
  NS_IMETHOD Lookup(const char *hostname, nsIDNSListener *listener, nsISupports *ctxt, nsIRequest **_retval) { return _to Lookup(hostname, listener, ctxt, _retval); } \
  NS_IMETHOD Resolve(const char *hostname, char **_retval) { return _to Resolve(hostname, _retval); } \
  NS_IMETHOD GetMyIPAddress(char * *aMyIPAddress) { return _to GetMyIPAddress(aMyIPAddress); } \
  NS_IMETHOD IsInNet(const char *ipaddr, const char *pattern, const char *mask, PRBool *_retval) { return _to IsInNet(ipaddr, pattern, mask, _retval); } \
  NS_IMETHOD Init(void) { return _to Init(); } \
  NS_IMETHOD Shutdown(void) { return _to Shutdown(); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIDNSSERVICE(_to) \
  NS_IMETHOD Lookup(const char *hostname, nsIDNSListener *listener, nsISupports *ctxt, nsIRequest **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->Lookup(hostname, listener, ctxt, _retval); } \
  NS_IMETHOD Resolve(const char *hostname, char **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->Resolve(hostname, _retval); } \
  NS_IMETHOD GetMyIPAddress(char * *aMyIPAddress) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetMyIPAddress(aMyIPAddress); } \
  NS_IMETHOD IsInNet(const char *ipaddr, const char *pattern, const char *mask, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->IsInNet(ipaddr, pattern, mask, _retval); } \
  NS_IMETHOD Init(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->Init(); } \
  NS_IMETHOD Shutdown(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->Shutdown(); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsDNSService : public nsIDNSService
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIDNSSERVICE

  nsDNSService();
  virtual ~nsDNSService();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsDNSService, nsIDNSService)

nsDNSService::nsDNSService()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsDNSService::~nsDNSService()
{
  /* destructor code */
}

/* nsIRequest lookup (in string hostname, in nsIDNSListener listener, in nsISupports ctxt); */
NS_IMETHODIMP nsDNSService::Lookup(const char *hostname, nsIDNSListener *listener, nsISupports *ctxt, nsIRequest **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* string resolve (in string hostname); */
NS_IMETHODIMP nsDNSService::Resolve(const char *hostname, char **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute string myIPAddress; */
NS_IMETHODIMP nsDNSService::GetMyIPAddress(char * *aMyIPAddress)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean isInNet (in string ipaddr, in string pattern, in string mask); */
NS_IMETHODIMP nsDNSService::IsInNet(const char *ipaddr, const char *pattern, const char *mask, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void init (); */
NS_IMETHODIMP nsDNSService::Init()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void shutdown (); */
NS_IMETHODIMP nsDNSService::Shutdown()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif

#define NS_ERROR_UNKNOWN_HOST  NS_ERROR_GENERATE_FAILURE(NS_ERROR_MODULE_NETWORK, 30)

#endif /* __gen_nsIDNSService_h__ */
