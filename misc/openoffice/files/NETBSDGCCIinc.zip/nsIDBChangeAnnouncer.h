/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIDBChangeAnnouncer.idl
 */

#ifndef __gen_nsIDBChangeAnnouncer_h__
#define __gen_nsIDBChangeAnnouncer_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_MailNewsTypes2_h__
#include "MailNewsTypes2.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIDBChangeListener; /* forward declaration */


/* starting interface:    nsIDBChangeAnnouncer */
#define NS_IDBCHANGEANNOUNCER_IID_STR "2aa6733a-2b36-11d3-a51c-0060b0fc04b7"

#define NS_IDBCHANGEANNOUNCER_IID \
  {0x2aa6733a, 0x2b36, 0x11d3, \
    { 0xa5, 0x1c, 0x00, 0x60, 0xb0, 0xfc, 0x04, 0xb7 }}

class NS_NO_VTABLE nsIDBChangeAnnouncer : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IDBCHANGEANNOUNCER_IID)

  /* void AddListener (in nsIDBChangeListener listener); */
  NS_IMETHOD AddListener(nsIDBChangeListener *listener) = 0;

  /* void RemoveListener (in nsIDBChangeListener listener); */
  NS_IMETHOD RemoveListener(nsIDBChangeListener *listener) = 0;

  /* void NotifyKeyChangeAll (in nsMsgKey keyChanged, in unsigned long aOldFlags, in unsigned long aNewFlags, in nsIDBChangeListener instigator); */
  NS_IMETHOD NotifyKeyChangeAll(nsMsgKey keyChanged, PRUint32 aOldFlags, PRUint32 aNewFlags, nsIDBChangeListener *instigator) = 0;

  /* void NotifyKeyAddedAll (in nsMsgKey keyAdded, in nsMsgKey parentKey, in long flags, in nsIDBChangeListener instigator); */
  NS_IMETHOD NotifyKeyAddedAll(nsMsgKey keyAdded, nsMsgKey parentKey, PRInt32 flags, nsIDBChangeListener *instigator) = 0;

  /* void NotifyKeyDeletedAll (in nsMsgKey keyDeleted, in nsMsgKey parentKey, in long flags, in nsIDBChangeListener instigator); */
  NS_IMETHOD NotifyKeyDeletedAll(nsMsgKey keyDeleted, nsMsgKey parentKey, PRInt32 flags, nsIDBChangeListener *instigator) = 0;

  /* void NotifyParentChangedAll (in nsMsgKey keyReparented, in nsMsgKey oldParent, in nsMsgKey newParent, in nsIDBChangeListener instigator); */
  NS_IMETHOD NotifyParentChangedAll(nsMsgKey keyReparented, nsMsgKey oldParent, nsMsgKey newParent, nsIDBChangeListener *instigator) = 0;

  /* void NotifyReadChanged (in nsIDBChangeListener instigator); */
  NS_IMETHOD NotifyReadChanged(nsIDBChangeListener *instigator) = 0;

  /* void NotifyAnnouncerGoingAway (); */
  NS_IMETHOD NotifyAnnouncerGoingAway(void) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIDBCHANGEANNOUNCER \
  NS_IMETHOD AddListener(nsIDBChangeListener *listener); \
  NS_IMETHOD RemoveListener(nsIDBChangeListener *listener); \
  NS_IMETHOD NotifyKeyChangeAll(nsMsgKey keyChanged, PRUint32 aOldFlags, PRUint32 aNewFlags, nsIDBChangeListener *instigator); \
  NS_IMETHOD NotifyKeyAddedAll(nsMsgKey keyAdded, nsMsgKey parentKey, PRInt32 flags, nsIDBChangeListener *instigator); \
  NS_IMETHOD NotifyKeyDeletedAll(nsMsgKey keyDeleted, nsMsgKey parentKey, PRInt32 flags, nsIDBChangeListener *instigator); \
  NS_IMETHOD NotifyParentChangedAll(nsMsgKey keyReparented, nsMsgKey oldParent, nsMsgKey newParent, nsIDBChangeListener *instigator); \
  NS_IMETHOD NotifyReadChanged(nsIDBChangeListener *instigator); \
  NS_IMETHOD NotifyAnnouncerGoingAway(void); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIDBCHANGEANNOUNCER(_to) \
  NS_IMETHOD AddListener(nsIDBChangeListener *listener) { return _to AddListener(listener); } \
  NS_IMETHOD RemoveListener(nsIDBChangeListener *listener) { return _to RemoveListener(listener); } \
  NS_IMETHOD NotifyKeyChangeAll(nsMsgKey keyChanged, PRUint32 aOldFlags, PRUint32 aNewFlags, nsIDBChangeListener *instigator) { return _to NotifyKeyChangeAll(keyChanged, aOldFlags, aNewFlags, instigator); } \
  NS_IMETHOD NotifyKeyAddedAll(nsMsgKey keyAdded, nsMsgKey parentKey, PRInt32 flags, nsIDBChangeListener *instigator) { return _to NotifyKeyAddedAll(keyAdded, parentKey, flags, instigator); } \
  NS_IMETHOD NotifyKeyDeletedAll(nsMsgKey keyDeleted, nsMsgKey parentKey, PRInt32 flags, nsIDBChangeListener *instigator) { return _to NotifyKeyDeletedAll(keyDeleted, parentKey, flags, instigator); } \
  NS_IMETHOD NotifyParentChangedAll(nsMsgKey keyReparented, nsMsgKey oldParent, nsMsgKey newParent, nsIDBChangeListener *instigator) { return _to NotifyParentChangedAll(keyReparented, oldParent, newParent, instigator); } \
  NS_IMETHOD NotifyReadChanged(nsIDBChangeListener *instigator) { return _to NotifyReadChanged(instigator); } \
  NS_IMETHOD NotifyAnnouncerGoingAway(void) { return _to NotifyAnnouncerGoingAway(); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIDBCHANGEANNOUNCER(_to) \
  NS_IMETHOD AddListener(nsIDBChangeListener *listener) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddListener(listener); } \
  NS_IMETHOD RemoveListener(nsIDBChangeListener *listener) { return !_to ? NS_ERROR_NULL_POINTER : _to->RemoveListener(listener); } \
  NS_IMETHOD NotifyKeyChangeAll(nsMsgKey keyChanged, PRUint32 aOldFlags, PRUint32 aNewFlags, nsIDBChangeListener *instigator) { return !_to ? NS_ERROR_NULL_POINTER : _to->NotifyKeyChangeAll(keyChanged, aOldFlags, aNewFlags, instigator); } \
  NS_IMETHOD NotifyKeyAddedAll(nsMsgKey keyAdded, nsMsgKey parentKey, PRInt32 flags, nsIDBChangeListener *instigator) { return !_to ? NS_ERROR_NULL_POINTER : _to->NotifyKeyAddedAll(keyAdded, parentKey, flags, instigator); } \
  NS_IMETHOD NotifyKeyDeletedAll(nsMsgKey keyDeleted, nsMsgKey parentKey, PRInt32 flags, nsIDBChangeListener *instigator) { return !_to ? NS_ERROR_NULL_POINTER : _to->NotifyKeyDeletedAll(keyDeleted, parentKey, flags, instigator); } \
  NS_IMETHOD NotifyParentChangedAll(nsMsgKey keyReparented, nsMsgKey oldParent, nsMsgKey newParent, nsIDBChangeListener *instigator) { return !_to ? NS_ERROR_NULL_POINTER : _to->NotifyParentChangedAll(keyReparented, oldParent, newParent, instigator); } \
  NS_IMETHOD NotifyReadChanged(nsIDBChangeListener *instigator) { return !_to ? NS_ERROR_NULL_POINTER : _to->NotifyReadChanged(instigator); } \
  NS_IMETHOD NotifyAnnouncerGoingAway(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->NotifyAnnouncerGoingAway(); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsDBChangeAnnouncer : public nsIDBChangeAnnouncer
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIDBCHANGEANNOUNCER

  nsDBChangeAnnouncer();
  virtual ~nsDBChangeAnnouncer();
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsDBChangeAnnouncer, nsIDBChangeAnnouncer)

nsDBChangeAnnouncer::nsDBChangeAnnouncer()
{
  NS_INIT_ISUPPORTS();
  /* member initializers and constructor code */
}

nsDBChangeAnnouncer::~nsDBChangeAnnouncer()
{
  /* destructor code */
}

/* void AddListener (in nsIDBChangeListener listener); */
NS_IMETHODIMP nsDBChangeAnnouncer::AddListener(nsIDBChangeListener *listener)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void RemoveListener (in nsIDBChangeListener listener); */
NS_IMETHODIMP nsDBChangeAnnouncer::RemoveListener(nsIDBChangeListener *listener)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void NotifyKeyChangeAll (in nsMsgKey keyChanged, in unsigned long aOldFlags, in unsigned long aNewFlags, in nsIDBChangeListener instigator); */
NS_IMETHODIMP nsDBChangeAnnouncer::NotifyKeyChangeAll(nsMsgKey keyChanged, PRUint32 aOldFlags, PRUint32 aNewFlags, nsIDBChangeListener *instigator)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void NotifyKeyAddedAll (in nsMsgKey keyAdded, in nsMsgKey parentKey, in long flags, in nsIDBChangeListener instigator); */
NS_IMETHODIMP nsDBChangeAnnouncer::NotifyKeyAddedAll(nsMsgKey keyAdded, nsMsgKey parentKey, PRInt32 flags, nsIDBChangeListener *instigator)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void NotifyKeyDeletedAll (in nsMsgKey keyDeleted, in nsMsgKey parentKey, in long flags, in nsIDBChangeListener instigator); */
NS_IMETHODIMP nsDBChangeAnnouncer::NotifyKeyDeletedAll(nsMsgKey keyDeleted, nsMsgKey parentKey, PRInt32 flags, nsIDBChangeListener *instigator)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void NotifyParentChangedAll (in nsMsgKey keyReparented, in nsMsgKey oldParent, in nsMsgKey newParent, in nsIDBChangeListener instigator); */
NS_IMETHODIMP nsDBChangeAnnouncer::NotifyParentChangedAll(nsMsgKey keyReparented, nsMsgKey oldParent, nsMsgKey newParent, nsIDBChangeListener *instigator)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void NotifyReadChanged (in nsIDBChangeListener instigator); */
NS_IMETHODIMP nsDBChangeAnnouncer::NotifyReadChanged(nsIDBChangeListener *instigator)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void NotifyAnnouncerGoingAway (); */
NS_IMETHODIMP nsDBChangeAnnouncer::NotifyAnnouncerGoingAway()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIDBChangeAnnouncer_h__ */
